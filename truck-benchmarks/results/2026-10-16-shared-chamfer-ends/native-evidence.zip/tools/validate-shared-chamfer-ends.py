from pathlib import Path
import subprocess,os,json,hashlib,re
out=Path('truck-benchmarks/results/2026-10-16-shared-chamfer-ends');env=dict(os.environ,CARGO_BUILD_JOBS='12')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
parent=json.loads((out/'parent.json').read_text())
assert sha('truck-shapeops/tests/two_edge_chamfer_caps.rs')==parent['test_sha256']
assert '0 passed; 2 failed' in (out/'parent-failure.txt').read_text()
assert '2 passed; 0 failed' in (out/'regressions.txt').read_text()
source={str(p):sha(p) for base in ['truck-shapeops/src','truck-shapeops/tests','truck-shapeops/examples'] for p in Path(base).rglob('*.rs')}
m=dict(parent_revision=parent['revision'],source_sha256=source)
(out/'validation-start.json').write_text(json.dumps(m,indent=2)+'\n')
for name,cmd in [
 ('shapeops-tests.txt',['cargo','test','--release','-p','truck-shapeops']),
 ('replay-tests.txt',['cargo','test','--release','-p','truck-shapeops','--example','replay_occt_blend']),
 ('clippy.txt',['cargo','clippy','--release','-p','truck-stepio','-p','truck-shapeops','-p','truck-benchmarks','--all-targets']),
 ('actions-smoke.txt',['cargo','bench','-p','truck-benchmarks','--bench','actions','--','--test']),
 ('replay-build.txt',['cargo','build','--release','-p','truck-shapeops','--example','replay_occt_blend'])]:
 with (out/name).open('w') as log:
  log.write('$ '+' '.join(cmd)+'\n');log.flush();r=subprocess.run(cmd,env=dict(env,RAYON_NUM_THREADS='1') if name=='actions-smoke.txt' else env,stdout=log,stderr=subprocess.STDOUT);log.write(f'exit_code {r.returncode}\n');assert r.returncode==0,name
 print(name,'passed',flush=True)
for p,h in source.items():assert sha(p)==h,p
counts=[tuple(map(int,x)) for x in re.findall(r'test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored',(out/'shapeops-tests.txt').read_text())]
m.update(shapeops_counts=list(map(sum,zip(*counts))),replay_tests=33,replay_sha256=sha('target/release/examples/replay_occt_blend'))
assert '33 passed; 0 failed' in (out/'replay-tests.txt').read_text()
for p in out.glob('*.txt'):p.write_text('\n'.join(line.rstrip() for line in p.read_text().splitlines()).rstrip()+'\n')
m['log_sha256']={p.name:sha(p) for p in out.glob('*.txt')}
(out/'validation.json').write_text(json.dumps(m,indent=2)+'\n')
print('Validation complete',m['shapeops_counts'],flush=True)
