use truck_modeling::*;
use truck_shapeops::SplitClosedEdgesAndFaces;
use truck_stepio::r#in::{Table,step_geometry::Curve3D};
fn main(){
 let path=std::env::args().nth(1).unwrap();let text=std::fs::read_to_string(path).unwrap();let table=Table::from_step(&text).unwrap();
 let entity=table.manifold_solid_brep.values().next().unwrap();let(mut solid,skipped)=table.to_compressed_solid(entity).unwrap();println!("skipped {}",skipped.len());
 solid.split_closed_edges_and_faces(1e-5);
 for (shell,boundary) in solid.boundaries.iter().enumerate(){
  for (index,edge) in boundary.edges.iter().enumerate(){if let Err(error)=Curve::try_from(&edge.curve){
   println!("shell {shell} edge {index}: {error}");
   if let Curve3D::PCurve(c)=&edge.curve {println!("parameter endpoints {:?} {:?}; surface {:?}",c.curve().front(),c.curve().back(),(std::mem::discriminant(c.surface().as_ref()),std::mem::discriminant(c.curve().as_ref())));}
  }}
  for (index,face) in boundary.faces.iter().enumerate(){if let Err(error)=Surface::try_from(&face.surface){println!("shell {shell} face {index}: {error}");}}
 }
 let mapped=solid.try_mapped(|p|Some(*p),|c|{
  Curve::try_from(c).ok().or_else(||{
   let Curve3D::PCurve(p)=c else{return None};
   let truck_stepio::r#in::step_geometry::Curve2D::BSplineCurve(curve)=p.curve().as_ref() else{return None};
   Some(Curve::PCurve(truck_modeling::PCurve::new(curve.clone(),Box::new(Surface::try_from(p.surface().as_ref()).ok()?))))
  })
 },|s|Surface::try_from(s).ok()).unwrap();
 let converted=Solid::extract(mapped).unwrap();println!("exact spline pcurve mapping: geometric consistency {}",converted.is_geometric_consistent());

 for (fi,face) in converted.face_iter().enumerate() {
  let surface=face.surface();
  for (ei,edge) in face.edge_iter().enumerate() {
   let curve=edge.oriented_curve();
   let endpoints=curve.front().distance(edge.front().point()).max(curve.back().distance(edge.back().point()));
   if endpoints<1e-6 && surface.include(&curve) {continue;}
   let (a,b)=curve.range_tuple();let mut worst=0_f64;let mut missing=0;let mut uv_min=(f64::INFINITY,f64::INFINITY);let mut uv_max=(f64::NEG_INFINITY,f64::NEG_INFINITY);
   for i in 0..=32 {let p=curve.subs(a+(b-a)*i as f64/32.);
    if let Some((u,v))=surface.search_nearest_parameter(p,None,100) {worst=worst.max(surface.subs(u,v).distance(p)); uv_min.0=uv_min.0.min(u);uv_min.1=uv_min.1.min(v);uv_max.0=uv_max.0.max(u);uv_max.1=uv_max.1.max(v);} else {missing+=1;}
   }
   if let Curve::BSplineCurve(c)=&curve {
    let (knots,_)=c.knot_vec().to_single_multi();let mut largest=0_f64;let mut worst_t=0.;let mut first_failure=None;
    for w in knots.windows(2) {for j in 0..=c.degree()*6 {
     let x=j as f64/(c.degree()*6) as f64;let t=w[0]*(1.-x)+w[1]*x;let p=c.subs(t);
     let nearest=surface.search_nearest_parameter(p,None,100);
     if let Some((u,v))=nearest {let err=surface.subs(u,v).distance(p);if err>largest {largest=err;worst_t=t;}}
     if first_failure.is_none() && surface.search_parameter(p,None,100).is_none(){first_failure=Some((t,nearest));}
    }}
    println!("knotspan dense max {largest:.12e} at {worst_t} first search failure {first_failure:?}");
   }
   println!("ranges {:?} nearest min {:?} max {:?}",surface.try_range_tuple(),uv_min,uv_max);
   if let Surface::Extruded(e)=&surface {println!("profile {:?}, vector {:?}",e.entity_curve().range_tuple(),e.extruding_vector());}
   println!("face {fi} edge {ei} endpoints {endpoints:.12e} include {} support gap {worst:.12e} missing {missing} surface {:?} curve {:?}",surface.include(&curve),std::mem::discriminant(&surface),std::mem::discriminant(&curve));
  }
 }
}
