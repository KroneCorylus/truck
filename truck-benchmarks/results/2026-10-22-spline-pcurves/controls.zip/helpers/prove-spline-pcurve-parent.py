from pathlib import Path
import subprocess,os,json,hashlib,shutil
root=Path.cwd();parent=root/'target/spline-pcurve-parent-source';out=root/'truck-benchmarks/results/2026-10-22-spline-pcurves';out.mkdir(exist_ok=True)
revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=parent,text=True).strip()==revision
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
files=['truck-stepio/tests/spline_extrusion_pcurves.rs','truck-stepio/tests/spline_pcurve_bounds.rs','truck-stepio/tests/fixtures/spline-extrusion-pcurves/C1-equal-006.step']
for name in files:
 (parent/name).parent.mkdir(exist_ok=True,parents=True);shutil.copyfile(root/name,parent/name)
shutil.copyfile(root/'Cargo.lock',parent/'Cargo.lock')
env=os.environ|{'CARGO_BUILD_JOBS':'12','CARGO_TARGET_DIR':str(root/'target')}
with (out/'parent-clean.txt').open('w') as f:subprocess.run(['cargo','clean','--release','-p','truck-stepio'],cwd=parent,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
for name,test,expected in [('parent-trace-tests.txt','spline_extrusion_pcurves','1 passed; 1 failed'),('parent-bounds-tests.txt','spline_pcurve_bounds','0 passed; 2 failed')]:
 cmd=['cargo','test','--release','-p','truck-stepio','--test',test]
 with (out/name).open('w') as f:
  f.write('$ '+' '.join(cmd)+'\n');f.flush();r=subprocess.run(cmd,cwd=parent,env=env,stdout=f,stderr=subprocess.STDOUT);f.write(f'exit_code {r.returncode}\n')
 assert r.returncode==101,name;assert expected in (out/name).read_text(),name
 print(name,'expected failure confirmed',flush=True)
(out/'parent.json').write_text(json.dumps(dict(revision=revision,test_sha256={name:sha(root/name) for name in files},parent_test_sha256={name:sha(parent/name) for name in files},binding_change=None),indent=2)+'\n');print('Parent proof complete',flush=True)
