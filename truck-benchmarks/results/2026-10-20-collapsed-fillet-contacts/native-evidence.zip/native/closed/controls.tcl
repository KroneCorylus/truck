pload ALL
pload -BlendAudit BLENDAUDIT
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
restore "/home/krone/Development/Pieza_WS/truck/target/native-collapsed-contacts-closed/size10-radius1.brep" bundle0
explode bundle0
audit_blend_output before0 bundle0_1
catch {blend result0 bundle0_1 1.0 bundle0_2} error0
audit_blend_output after0 bundle0_1
exit
