from pathlib import Path
import json,subprocess,os,hashlib
root=Path.cwd();proof=root/'truck-benchmarks/results/2026-10-16-cone-references';raw=root/'target/native-cone-reference-final'
v=json.loads((proof/'validation.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for p,h in v['source_sha256'].items():assert sha(p)==h,p
replay=root/'target/release/examples/replay_occt_blend';assert sha(replay)==v['replay_sha256']
plugin=root/'target/occt-cone-reference-plugin';env=dict(os.environ,LD_LIBRARY_PATH=str(root/'target/occt-sdk/usr/lib64'))
records=json.loads((raw/'summary.json').read_text())
for q in records:
 prefix=Path(q['prefix']);input_hashes={str(p):sha(p) for p in prefix.parent.glob(prefix.name+'.input.*')}
 with Path(str(prefix)+'.truck.log').open('w') as log:subprocess.run([str(replay),str(prefix)],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
 result=json.loads(Path(str(prefix)+'.truck.json').read_text())['result']
 assert result['status']=='operation-succeeded',result
 assert result['selected_edges']==2
 assert all(result[k] for k in ['input_unchanged','geometry_consistent','mesh_closed','step_prepared'])
 with Path(str(prefix)+'.comparison.log').open('w') as log:subprocess.run([str(plugin/'compare_shapes'),str(prefix)+'.result.brep',str(prefix)+'.truck.step',str(prefix)+'.comparison.json'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
 compare=json.loads(Path(str(prefix)+'.comparison.json').read_text())
 assert compare['native_valid'] and compare['truck_step_valid']
 assert compare['native_solids']==compare['truck_solids']==1
 assert max(compare['native_to_truck_max_distance'],compare['truck_to_native_max_distance'])<.001
 assert abs(compare['truck_volume']-q['expected_volume'])<1e-5
 for p,h in input_hashes.items():assert sha(p)==h,p
 q.update(truck=result,comparison=compare,input_sha256=input_hashes)
 print(prefix.name,compare['truck_volume'],max(compare['native_to_truck_max_distance'],compare['truck_to_native_max_distance']),flush=True)
for p,h in v['source_sha256'].items():assert sha(p)==h,p
(raw/'validated-summary.json').write_text(json.dumps(records,indent=2)+'\n')
print('All eight native controls replay as valid single STEP solids with analytic material')
