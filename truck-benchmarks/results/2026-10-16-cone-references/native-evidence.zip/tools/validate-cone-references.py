from pathlib import Path
import subprocess,os,json,hashlib,re
out=Path('truck-benchmarks/results/2026-10-16-cone-references');env=dict(os.environ,CARGO_BUILD_JOBS='12')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
parent=json.loads((out/'parent.json').read_text())
test = Path('truck-shapeops/examples/replay_occt_blend.rs').read_text().split('#[cfg(test)]\nmod conical_reference_tests',1)[1]
assert hashlib.sha256(('#[cfg(test)]\nmod conical_reference_tests'+test).encode()).hexdigest()==parent['test_sha256']
assert '0 passed; 3 failed' in (out/'parent-replay.txt').read_text()
assert 'Missing reference_cone' in (out/'parent-native.txt').read_text()
source={str(p):sha(p) for base in ['truck-shapeops/src','truck-shapeops/tests','truck-shapeops/examples'] for p in Path(base).rglob('*.rs')}
source.update({str(p):sha(p) for p in Path('audits/fillet-chamfer/capture').glob('*') if p.is_file() and p.suffix in ['.cpp','.hpp','.tcl','.py','.sh']})
m=dict(parent_revision=parent['revision'],source_sha256=source)
(out/'validation-start.json').write_text(json.dumps(m,indent=2)+'\n')
for name,cmd in [
 ('replay-tests.txt',['cargo','test','--release','-p','truck-shapeops','--example','replay_occt_blend']),
 ('clippy.txt',['cargo','clippy','--release','-p','truck-stepio','-p','truck-shapeops','-p','truck-benchmarks','--all-targets']),
 ('actions-smoke.txt',['cargo','bench','-p','truck-benchmarks','--bench','actions','--','--test']),
 ('replay-build.txt',['cargo','build','--release','-p','truck-shapeops','--example','replay_occt_blend'])]:
 with (out/name).open('w') as log:
  log.write('$ '+' '.join(cmd)+'\n');log.flush();r=subprocess.run(cmd,env=dict(env,RAYON_NUM_THREADS='1') if name=='actions-smoke.txt' else env,stdout=log,stderr=subprocess.STDOUT);log.write(f'exit_code {r.returncode}\n');assert r.returncode==0,name
 print(name,'passed',flush=True)
for p,h in source.items():assert sha(p)==h,p
m.update(replay_tests=39,replay_sha256=sha('target/release/examples/replay_occt_blend'))
assert '39 passed; 0 failed' in (out/'replay-tests.txt').read_text()
for p in out.glob('*.txt'):p.write_text('\n'.join(line.rstrip() for line in p.read_text().splitlines()).rstrip()+'\n')
m['log_sha256']={p.name:sha(p) for p in out.glob('*.txt')}
(out/'validation.json').write_text(json.dumps(m,indent=2)+'\n')
print('Validation complete: 39 replay tests, Clippy, actions smoke, final replay build',flush=True)
