pload ALL
pload -BlendAudit BLENDAUDIT
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
proc control {name args} {
    set code [catch {uplevel 1 $args} result options]
    puts [list CONTROL $name $code $result]
    set expected [expr {$name eq "rejected" ? 1 : 0}]
    if {$code != $expected} {exit 3}
}
box b 10 20 30
explode b F
renamevar b_1 reference
renamevar b b_edges
explode b_edges E
renamevar b_edges_1 selected
control equal_first chamf equal_result b_edges selected 2 selected 3
control invalid_then_equal chamf gate_result b_edges selected 0 selected 2
control unequal_first chamf unequal_result b_edges selected reference 2 3 selected reference 4 5
control angle_first chamf angle_result b_edges selected reference A 2 30 selected reference A 3 60
control invalid_angle_then_valid chamf angle_gate_result b_edges selected reference A 2 90 selected reference A 2 45
control rejected chamf rejected_result b_edges selected 0
control fillet blend fillet_result b_edges 2 selected
audit_blend_output box_input_after b_edges
source "/home/krone/Development/Pieza_WS/investigations/sequential-holes-2026-10-10/occt/tests/chamfer/begin"
restore "/home/krone/Development/Pieza_WS/truck/target/native-chamfer-contour-controls/A4.input.brep" tangent
explode tangent E
set seed [get_element EDGE -0.34571952701154405 0.1548338023048353 0.5]
set other [get_element EDGE 0.06204501370870732 0.70316976562354375 0.5]
if {$seed eq "" || $other eq "" || $seed eq $other} {exit 4}
puts [list TANGENT_SEEDS $seed $other]
control tangent_first chamf tangent_result tangent $seed 0.03 $other 0.02
audit_blend_output tangent_input_after tangent
exit
