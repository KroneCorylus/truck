from pathlib import Path
import hashlib,json,zipfile,subprocess
out=Path('truck-benchmarks/results/2026-10-15-native-chamfer-contours');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
validation=json.loads((out/'validation.json').read_text())
for group in ['source_sha256','executable_sha256']:
 for p,h in validation[group].items():assert sha(p)==h,p
raw=Path('target/occt-capture-native-chamfer-contour-proof');capture=json.loads((raw/'results.json').read_text());assert capture['test_data_verified']
for group in ['kernel_source_sha256','source_sha256','executable_sha256']:
 for p,h in capture[group].items():assert sha(p)==h,p
case=capture['cases'][0];assert case['id']=='chamfer/equal_dist_sequence/A4' and case['native']['status']=='passed'
q=case['captures'][0];r=q['truck']['result'];c=q['sampled_comparison'];s=q['task']['selection'][0]
assert q['task']['schema_version']==2 and s['native_applied'] and len(s['contour_edges'])==3
assert r['status']=='operation-succeeded' and r['selection_scope']=='native-contours' and r['selected_edges']==3
assert all(r[k] for k in ['input_unchanged','geometry_consistent','mesh_closed','step_prepared'])
assert c['native_valid'] and c['truck_step_valid'] and c['native_solids']==c['truck_solids']==1
assert max(c['native_to_truck_max_distance'],c['truck_to_native_max_distance'])<1e-7
controls=Path('target/native-chamfer-contour-controls');control=json.loads((controls/'results.json').read_text())
assert len(control['controls'])==8 and all(control['input_brep_unchanged'].values())
for p,h in control['source_sha256'].items():assert sha(p)==h,p
parent=Path('target/occt-capture-two-edge-face-trimming/chamfer/equal_dist_sequence/A4/capture/001.input.json')
old=json.loads(parent.read_text());assert old['schema_version']==1 and 'contour_edges' not in old['selection'][0]
(out/'native-parent-scope.txt').write_text(f'Parent clean capture c26b6780, A4/001: schema_version={old["schema_version"]}, selected seed count={len(old["selection"])}; complete native contour scope is absent.\nOriginal metadata SHA256 {sha(parent)}.\nCurrent automatic capture: schema_version=2, one applied seed, three physical contour edges.\nCurrent captured metadata SHA256 {sha(raw/"chamfer/equal_dist_sequence/A4/capture/001.input.json")}.\n')
artifacts={}
for prefix,folder in [('automatic',raw),('controls',controls)]:
 for p in sorted(folder.rglob('*')):
  if p.is_file():artifacts[f'{prefix}/{p.relative_to(folder)}']=(p,sha(p))
artifacts['parent/001.input.json']=(parent,sha(parent))
for path in ['target/prove-native-chamfer-contours.py','target/package-native-chamfer-contours.py']:
 p=Path(path);artifacts['tools/'+p.name]=(p,sha(p))
for i,(path,h) in enumerate(sorted(capture['test_data']['external_files'].items())):
 p=Path(path);assert sha(p)==h;artifacts[f'data/{i:02}-{p.name}']=(p,h)
p=Path('target/chamfer-public-data-provenance.json');artifacts['data/provenance.json']=(p,sha(p))
archive=out/'native-evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for member,(p,h) in sorted(artifacts.items()):assert sha(p)==h,p;z.write(p,member)
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(artifacts)
 for member,(p,h) in artifacts.items():assert hashlib.sha256(z.read(member)).hexdigest()==h==sha(p),p
for p in out.glob('*.txt'):p.write_text('\n'.join(line.rstrip() for line in p.read_text().splitlines()).rstrip()+'\n')
validation.update(artifact_archive='native-evidence.zip',artifact_archive_sha256=sha(archive),artifact_sha256={member:h for member,(_,h) in artifacts.items()},automatic_A4_result=r,automatic_A4_comparison=c,native_controls=control['controls'],native_input_brep_unchanged=control['input_brep_unchanged'])
(out/'metadata.json').write_text(json.dumps(validation,indent=2)+'\n')
(out/'REPORT.md').write_text(f'''# Complete native chamfer contour intent

Parent {validation['parent_revision']}. The native capture previously saved only
seed edges. A4 can construct a valid one-edge chamfer while missing the native
three-edge contour, so construction success alone did not establish equivalent
intent. Historical seed-only records remain unchanged and explicitly limited.

Chamfer schema 2 uses one native builder, mirrors parameter gates and preserves
first-assignment behavior. It retains raw seeds/parameters, applied/ignored state
and all propagated physical contour edges. Replay verifies seed membership,
complete connected scope, ignored-record consistency and assignment conflicts.
Missing scope cannot fall back to a seed; no effective selection is explicit.
Legacy chamfers and fillets remain labeled seed-only. Curved reference-face
propagation is still unsupported by the planar reference mapping.

Nine Rust regressions fail on the parent: eight scope/assignment/label checks
and one explicit complete-contour STEP round trip. A Python summary regression
also fails on the parent. Final validation: 24 Rust replay tests, 22 audit tests,
10 capture tests, all-target release Clippy, action smoke, native plugin build
and the final replay build pass. Kernel sources did not change; their preceding
504-pass/0-failure/1-existing-ignore release validation is linked in metadata.

The initial round-trip test exposed about 6.18e-6 contact drift allowed by the
old replay STEP fit of 5e-5. The exporter documents robust tessellation for such
fits. Replay now requests 1e-7, below kernel consistency tolerance; the original
strict solid and STEP assertions pass without relaxing them. The legacy label
test does not compare a seed-only partial edit to the full-contour material
oracle. Complete three-edge results always run the shared solid/STEP harness.
The general prepare_for_step API and its tolerance contract are unchanged.

Eight real native controls verify first-assignment behavior in equal-distance,
two-distance and distance-angle modes; invalid-parameter gates; no-op rejection;
legacy fillet scope; and ignoring a different seed inside A4's already selected
contour. Seven construct and meet native-valid single-solid STEP and sampled
comparison checks. The invalid-only command is natively rejected and replayed as
unhandled intent. Box volumes use independent section formulas. Box and A4 input
BREP bytes are identical before/after the native control sequence.

Automatic A4/001 now captures and replays three edges. Native-valid single-solid
STEP, immutable input, consistent geometry and closed mesh all pass. Maximum
sampled boundary distance is {max(c['native_to_truck_max_distance'],c['truck_to_native_max_distance']):.17g};
native volume {c['native_volume']:.17g}, Truck STEP volume {c['truck_volume']:.17g}.
This is finite sampled evidence, not a global bound or full-parity verdict.
The remaining seven A4 sequence inputs are retained with their separate results;
they are not counted as successful merely because the native case passes.

Native evidence archive: {len(artifacts)} byte-verified members, SHA256
{sha(archive)}. Raw target/native-chamfer-contour-controls and
target/occt-capture-native-chamfer-contour-proof. Source/executable hashes were
verified after the final replay build. No performance claim.

A clean full corpus capture follows this implementation commit. Its comparison
must distinguish corrected native intent from unchanged intent, preserve all
prior successful checks for unchanged intent, and record numerical changes from
tighter STEP fitting. Remaining work includes unsupported curved reference
faces, solver failures, native shell inputs, C1 input fidelity, missing fixtures,
sampled discrepancies, fillet tangent propagation, editing/continuity evidence
and the previously recorded PCurve precision failure.
''')
print('Verified',len(artifacts),'archive members',sha(archive))
