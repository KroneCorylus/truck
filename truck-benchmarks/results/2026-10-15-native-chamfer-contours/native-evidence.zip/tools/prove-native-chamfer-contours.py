from pathlib import Path
import sys,json,subprocess,shutil,hashlib,math
root=Path.cwd();sys.path.insert(0,str(root/'audits/fillet-chamfer'))
from run_occt import isolated_display,execute,tcl_word
out=root/'target/native-chamfer-contour-controls';out.mkdir(exist_ok=False)
occt=(root/'../investigations/sequential-holes-2026-10-10/occt').resolve();plugin=root/'target/occt-contour-capture-plugin';sdk=root/'target/occt-sdk/usr/lib64';replay=root/'target/release/examples/replay_occt_blend';draw=shutil.which('DRAWEXE')
fixture=root/'target/occt-capture-two-edge-face-trimming/chamfer/equal_dist_sequence/A4/capture/001.input.brep';shutil.copyfile(fixture,out/'A4.input.brep')
script=out/'controls.tcl'
script.write_text(f'''pload ALL
pload -BlendAudit BLENDAUDIT
source {tcl_word(root/'audits/fillet-chamfer/capture/blend_capture.tcl')}
proc control {{name args}} {{
    set code [catch {{uplevel 1 $args}} result options]
    puts [list CONTROL $name $code $result]
    set expected [expr {{$name eq "rejected" ? 1 : 0}}]
    if {{$code != $expected}} {{exit 3}}
}}
box b 10 20 30
explode b F
renamevar b_1 reference
renamevar b b_edges
explode b_edges E
renamevar b_edges_1 selected
control equal_first chamf equal_result b_edges selected 2 selected 3
control invalid_then_equal chamf gate_result b_edges selected 0 selected 2
control unequal_first chamf unequal_result b_edges selected reference 2 3 selected reference 4 5
control angle_first chamf angle_result b_edges selected reference A 2 30 selected reference A 3 60
control invalid_angle_then_valid chamf angle_gate_result b_edges selected reference A 2 90 selected reference A 2 45
control rejected chamf rejected_result b_edges selected 0
control fillet blend fillet_result b_edges 2 selected
audit_blend_output box_input_after b_edges
source {tcl_word(occt/'tests/chamfer/begin')}
restore {tcl_word(out/'A4.input.brep')} tangent
explode tangent E
set seed [get_element EDGE -0.34571952701154405 0.1548338023048353 0.5]
set other [get_element EDGE 0.06204501370870732 0.70316976562354375 0.5]
if {{$seed eq "" || $other eq "" || $seed eq $other}} {{exit 4}}
puts [list TANGENT_SEEDS $seed $other]
control tangent_first chamf tangent_result tangent $seed 0.03 $other 0.02
audit_blend_output tangent_input_after tangent
exit
''')
manifest={'scope':'Native controls for complete chamfer contour capture and first-assignment semantics','controls':[]}
with isolated_display(out) as env:
 env.update(LD_LIBRARY_PATH=f'{plugin}:{sdk}',CASROOT=str(occt),CSF_BlendAuditDefaults=str(plugin),CSF_DrawPluginDefaults=str(occt/'src/DrawResources'),DRAWDEFAULT=str(occt/'src/DrawResources/DrawDefault'),CSF_TestScriptsPath=str(occt/'tests'),CSF_ShadersDirectory=str(occt/'src/Shaders'))
 log,code,timeout,elapsed=execute([draw,'-v','-f',str(script)],out,env,120)
 (out/'controls.log').write_text(log);assert code==0 and not timeout,(code,timeout,log[-4000:])
 captures=sorted((out/'capture').glob('*.input.json'));assert len(captures)==8,len(captures)
 for i,p in enumerate(captures,1):
  prefix=str(p).removesuffix('.input.json');task=json.loads(p.read_text());selection=task['selection']
  assert task['schema_version']==(1 if i==7 else 2),i
  if i!=7:
   expected_applied={1:[True,False],2:[False,True],3:[True,False],4:[True,False],5:[False,True],6:[False],8:[True,False]}[i]
   assert [s['native_applied'] for s in selection]==expected_applied,(i,selection)
   for s in selection:
    assert len(s['contour_edges'])==(3 if i==8 else 1) if s['native_applied'] else not s['contour_edges']
   ignored=selection[1] if i in [1,3,4,8] else selection[0]
   assert ignored['ignored_reason']==('already-selected' if i in [1,3,4,8] else 'invalid-parameters'),i
  log,code,timeout,elapsed=execute([str(replay),prefix],out,env,120)
  Path(prefix+'.truck.log').write_text(log);assert code==0 and not timeout,(i,code,timeout)
  report=json.loads(Path(prefix+'.truck.json').read_text());result=report['result'];assert report['step_fitting_tolerance']==1e-7
  assert result['selection_scope']==('seed-only' if i==7 else 'native-contours')
  comparison=None
  if i==6:
   assert result['status']=='unhandled-intent',result
   assert Path(prefix+'.capture.log').read_text().splitlines()[-1]=='native_return_code 1'
  else:
   assert result['status']=='operation-succeeded',(i,result)
   assert all(result[k] is True for k in ['input_unchanged','geometry_consistent','mesh_closed','step_prepared']),(i,result)
   assert result['selected_edges']==(3 if i==8 else 1),(i,result)
   native=json.loads(Path(prefix+'.result.json').read_text());assert native['native_valid'] and native['solids']==1
   if i==8:expected=.5630665232959563
   else:
    a,b=selection[0]['points'][0],selection[0]['points'][-1];length=math.dist(a,b)
    removed={1:2.,2:2.,3:3.,4:2.*math.tan(math.pi/6),5:2.,7:4.*(1.-math.pi/4)}[i]
    expected=6000.-length*removed
   assert abs(native['volume']-expected)<1e-6,(i,native['volume'],expected)
   log,code,timeout,elapsed=execute([str(plugin/'compare_shapes'),prefix+'.result.brep',prefix+'.truck.step',prefix+'.comparison.json'],out,env,120)
   Path(prefix+'.comparison.log').write_text(log);assert code==0 and not timeout,(i,code,timeout)
   comparison=json.loads(Path(prefix+'.comparison.json').read_text())
   assert comparison['native_valid'] and comparison['truck_step_valid'] and comparison['native_solids']==comparison['truck_solids']==1,(i,comparison)
   assert max(comparison['native_to_truck_max_distance'],comparison['truck_to_native_max_distance'])<=.001,(i,comparison)
  manifest['controls'].append(dict(index=i,selection=selection,result=result,comparison=comparison))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
manifest['source_sha256']={str(p):sha(p) for p in [script,Path(__file__),fixture,occt/'tests/chamfer/begin']}
manifest['input_brep_unchanged']={'box':sha(out/'capture/001.input.brep')==sha(out/'box_input_after.result.brep'),'tangent':sha(out/'capture/008.input.brep')==sha(out/'tangent_input_after.result.brep')}
(out/'results.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Verified',len(manifest['controls']),'native controls',manifest['input_brep_unchanged'])
