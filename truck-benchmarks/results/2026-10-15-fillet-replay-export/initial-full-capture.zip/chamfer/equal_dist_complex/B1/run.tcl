if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-native-chamfer-contours/chamfer/equal_dist_complex/B1/images"
set test_image "B1"
if {[catch {test "chamfer" "equal_dist_complex" "B1" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
