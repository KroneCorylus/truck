#include <BRepTools.hxx>
#include <BRep_Tool.hxx>
#include <BRep_Builder.hxx>
#include <TopoDS.hxx>
#include <TopExp.hxx>
#include <TopTools_IndexedMapOfShape.hxx>
#include <iostream>
#include <iomanip>
int main(int argc,char**argv) {
 std::cout<<std::setprecision(17)<<"[";
 for(int i=1;i<argc;++i) {
  TopoDS_Shape shape;BRep_Builder b;if(!BRepTools::Read(shape,argv[i],b))return 1;
  TopTools_IndexedMapOfShape vertices;TopExp::MapShapes(shape,TopAbs_VERTEX,vertices);
  if(i>1)std::cout<<",";std::cout<<"[";bool first=true;
  for(int j=1;j<=vertices.Extent();++j) {
   auto p=BRep_Tool::Pnt(TopoDS::Vertex(vertices(j)));
   if(std::abs(p.Z())>1e-8)continue;
   if(!first)std::cout<<",";first=false;std::cout<<"["<<p.X()<<","<<p.Y()<<","<<p.Z()<<"]";
  }
  std::cout<<"]";
 }
 std::cout<<"]\n";
}
