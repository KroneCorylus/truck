from pathlib import Path
import sys,json,subprocess,os,shutil,math
root=Path.cwd();sys.path.insert(0,str(root/'audits/fillet-chamfer'))
from run_occt import isolated_display,execute,tcl_word
out=root/'target/native-longitudinal-plane-extra-angles';out.mkdir(exist_ok=False)
occt=(root/'../investigations/sequential-holes-2026-10-10/occt').resolve();plugin=root/'target/occt-cone-reference-plugin';sdk=root/'target/occt-sdk/usr/lib64'
with (out/'inputs.log').open('w') as log:subprocess.run([str(root/'target/longitudinal-offset-inputs'),str(out)],env=dict(os.environ,LD_LIBRARY_PATH=str(sdk)),stdout=log,stderr=subprocess.STDOUT,check=True)
lines=['pload ALL','pload -BlendAudit BLENDAUDIT',f'source {tcl_word(root/"audits/fillet-chamfer/capture/blend_capture.tcl")}']
controls=[]
for source in [1,4]:
 for angle in [15.,60.]:
  i=len(controls);name=f'bundle{i}'
  request=f'{name}_3 A .7 {angle}'
  lines += [f'restore {tcl_word(out/f"input-{source}.brep")} {name}',f'explode {name}',f'audit_blend_output before{i} {name}_1',f'chamf result{i} {name}_1 {name}_2 {request}',f'audit_blend_output after{i} {name}_1']
  controls.append(dict(mode='angle',reference='plane',convex=source<3,offset=0.,angle=angle))
lines.append('exit');script=out/'controls.tcl';script.write_text('\n'.join(lines)+'\n')
with isolated_display(out) as env:
 env.update(LD_LIBRARY_PATH=f'{plugin}:{sdk}',CASROOT=str(occt),CSF_BlendAuditDefaults=str(plugin),CSF_DrawPluginDefaults=str(occt/'src/DrawResources'),DRAWDEFAULT=str(occt/'src/DrawResources/DrawDefault'),CSF_TestScriptsPath=str(occt/'tests'),CSF_ShadersDirectory=str(occt/'src/Shaders'))
 log,code,timeout,elapsed=execute([shutil.which('DRAWEXE'),'-v','-f',str(script)],out,env,120);(out/'controls.log').write_text(log);assert code==0 and not timeout
captures=sorted((out/'capture').glob('*.input.json'));assert len(captures)==4
for i,(p,c) in enumerate(zip(captures,controls)):
 result=json.loads(p.with_name(p.name.replace('.input.','.result.')).read_text());assert result['native_valid'] and result['solids']==1
 radius=5.;height=10.;h=c['offset'];x=math.sqrt(radius**2-h*h)
 sign=-1 if c['convex'] else 1;theta=math.asin(h/radius);alpha=math.radians(c['angle'])
 if c['reference']=='plane':
  a=.7;px=x+sign*a;ux=-sign*math.cos(alpha);uy=math.sin(alpha)
  dot=px*ux+h*uy;disc=dot*dot+radius*radius-px*px-h*h
  roots=[t for t in [-dot-math.sqrt(disc),-dot+math.sqrt(disc)] if t>0]
  t=min(roots);qx=px+t*ux;qy=h+t*uy
  psi=math.atan2(qy,qx)-theta;D=2*radius*math.sin(psi/2)
 else:
  D=1.5;psi=2*math.asin(D/(2*radius));qx=radius*math.cos(theta+psi);qy=radius*math.sin(theta+psi)
  ux=h/radius*math.cos(alpha)+sign*x/radius*math.sin(alpha)
  uy=-x/radius*math.cos(alpha)+sign*h/radius*math.sin(alpha)
  t=(h-qy)/uy;px=qx+t*ux;a=(px-x)*sign
 assert 0<psi<math.pi/2 and a>0,(c,a,psi)
 removed=abs(x*h-h*px+px*qy-h*qx-radius**2*psi)/2
 area=radius**2*math.acos(h/radius)-h*x
 expected=((area if c['convex'] else 16*(8-h)-area)-removed)*height
 assert abs(expected-result['volume'])<1e-7,(c,expected,result)
 assert (out/f'before{i}.result.brep').read_bytes()==(out/f'after{i}.result.brep').read_bytes()
 c.update(prefix=str(p)[:-len('.input.json')],planar_inset=a,cylinder_chord=2*radius*math.sin(psi/2),kernel_tangent=radius*math.tan(psi),expected_volume=expected,native_volume=result['volume'])
 print(c,flush=True)
(out/'summary.json').write_text(json.dumps(controls,indent=2)+'\n')
