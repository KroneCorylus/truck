from pathlib import Path
import math,json,subprocess,os
raw=Path('target/native-longitudinal-offset-angle-controls');records=[]
paths=sorted((raw/'capture').glob('*.result.brep'))
vertices=json.loads(subprocess.check_output(['target/native-section-vertices',*map(str,paths)],env=dict(os.environ,LD_LIBRARY_PATH='target/occt-sdk/usr/lib64')))
for index,(path,points) in enumerate(zip(paths,vertices)):
 source=index//2;convex=source<3;h=[-2.,0.,2.][source%3];reference='plane' if index%2==0 else 'cylinder'
 radius=5.;height=10.;x=math.sqrt(radius**2-h*h);sign=-1 if convex else 1;theta=math.asin(h/radius);alpha=math.pi/6
 if reference=='plane':
  a=.7;px=x+sign*a;ux=-sign*math.cos(alpha);uy=math.sin(alpha)
  dot=px*ux+h*uy;disc=dot*dot+radius*radius-px*px-h*h
  t=min(t for t in [-dot-math.sqrt(disc),-dot+math.sqrt(disc)] if t>0)
  qx=px+t*ux;qy=h+t*uy;psi=math.atan2(qy,qx)-theta;D=2*radius*math.sin(psi/2)
 else:
  D=1.5;psi=2*math.asin(D/(2*radius));qx=radius*math.cos(theta+psi);qy=radius*math.sin(theta+psi)
  ux=h/radius*math.cos(alpha)+sign*x/radius*math.sin(alpha);uy=-x/radius*math.cos(alpha)+sign*h/radius*math.sin(alpha)
  t=(h-qy)/uy;px=qx+t*ux;a=(px-x)*sign
 removed=abs(x*h-h*px+px*qy-h*qx-radius**2*psi)/2
 area=radius**2*math.acos(h/radius)-h*x
 expected=((area if convex else 16*(8-h)-area)-removed)*height
 result=json.loads(path.with_suffix('.json').read_text())
 p=next(p for p in points if 0<p[0]<7.99 and abs(p[1]-h)<1e-8)
 q=next(p for p in points if p[0]>0 and p[1]>h+1e-8 and abs(math.hypot(p[0],p[1])-radius)<1e-8)
 vx,vy=q[0]-p[0],q[1]-p[1]
 angle=math.degrees(math.atan2(abs(vy),abs(vx))) if reference=='plane' else math.degrees(math.acos(min(1,abs((vx*(-h/radius)+vy*x/radius)/math.hypot(vx,vy)))))
 record=dict(capture=path.stem,convex=convex,offset=h,reference=reference,expected_volume=expected,native_volume=result['volume'],volume_error=result['volume']-expected,native_valid=result['native_valid'],expected_planar=a,native_planar=(p[0]-x)*sign,expected_chord=D,native_chord=math.hypot(q[0]-x,q[1]-h),requested_angle=30,measured_angle=angle,plane_contact=p,cylinder_contact=q)
 records.append(record);print(json.dumps(record))
(raw/'analysis.json').write_text(json.dumps(records,indent=2)+'\n')
