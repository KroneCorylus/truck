from pathlib import Path
import json,math,subprocess,os
raw=Path('target/native-longitudinal-offset-angle-controls');paths=[raw/'capture'/f'{i:03}.result.brep' for i in range(1,13,2)]
measured=json.loads(subprocess.check_output(['target/native-plane-angle-oracle',*map(str,paths)],env=dict(os.environ,LD_LIBRARY_PATH='target/occt-sdk/usr/lib64')))
records=json.loads((raw/'analysis.json').read_text())[::2]
for record,planes in zip(records,measured):
 assert len(planes['bevel_planes'])==1
 plane=planes['bevel_planes'][0];n=plane['normal'];o=plane['origin']
 angle=math.degrees(math.atan2(abs(n[0]),abs(n[1])))
 assert abs(angle-record['measured_angle'])<1e-8
 residual=max(abs(sum((p[i]-o[i])*n[i] for i in range(3))) for p in [record['plane_contact'],record['cylinder_contact']])
 assert residual<1e-8
 record.update(analytic_bevel_plane=plane,plane_contact_residual=residual,analytic_plane_angle=angle)
 print(record['capture'],record['convex'],record['offset'],'requested',30,'analytic',angle,'volume_error',record['volume_error'])
assert sum(abs(r['analytic_plane_angle']-30)>1e-6 for r in records)==2
(raw/'plane-angle-proof.json').write_text(json.dumps(records,indent=2)+'\n')
