#include <BRepAdaptor_Curve.hxx>
#include <BRepAdaptor_Surface.hxx>
#include <BRepPrimAPI_MakeCylinder.hxx>
#include <BRepCheck_Analyzer.hxx>
#include <BRepTools.hxx>
#include <BRep_Builder.hxx>
#include <TopExp_Explorer.hxx>
#include <TopoDS.hxx>
#include <TopoDS_Compound.hxx>
#include <cmath>
#include <stdexcept>
int main(int argc,char**argv){
 if(argc!=2)return 1;auto solid=BRepPrimAPI_MakeCylinder(5.,10.,std::acos(-1.)/2).Shape();
 if(!BRepCheck_Analyzer(solid).IsValid())throw std::runtime_error("invalid input");
 TopoDS_Edge top,bottom;TopoDS_Face topFace,bottomFace;
 for(TopExp_Explorer it(solid,TopAbs_FACE);it.More();it.Next()){
  auto f=TopoDS::Face(it.Current());BRepAdaptor_Surface s(f);if(s.GetType()!=GeomAbs_Plane||std::abs(std::abs(s.Plane().Axis().Direction().Z())-1)>1e-8)continue;
  for(TopExp_Explorer e(f,TopAbs_EDGE);e.More();e.Next()){
   auto edge=TopoDS::Edge(e.Current());BRepAdaptor_Curve c(edge);auto mid=c.Value((c.FirstParameter()+c.LastParameter())/2);
   if(std::abs(mid.Z()-10)<1e-8&&c.GetType()==GeomAbs_Circle){top=edge;topFace=f;}
   if(mid.Distance(gp_Pnt(2.5,0,0))<1e-8){bottom=edge;bottomFace=f;}
  }
 }
 if(top.IsNull()||bottom.IsNull())throw std::runtime_error("missing edge");
 TopoDS_Compound bundle;BRep_Builder b;b.MakeCompound(bundle);b.Add(bundle,solid);b.Add(bundle,top);b.Add(bundle,topFace);b.Add(bundle,bottom);b.Add(bundle,bottomFace);
 return BRepTools::Write(bundle,argv[1])?0:1;
}
