pload ALL
pload -BlendAudit BLENDAUDIT
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
restore "/home/krone/Development/Pieza_WS/truck/target/native-conic-section/input.brep" bundle0
explode bundle0
audit_blend_output before0 bundle0_1
catch {chamf result0 bundle0_1 bundle0_4 .2} error0
audit_blend_output after0 bundle0_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-conic-section/input.brep" bundle1
explode bundle1
audit_blend_output before1 bundle1_1
catch {chamf result1 bundle1_1 bundle1_4 bundle1_5 .2 0.1} error1
audit_blend_output after1 bundle1_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-conic-section/input.brep" bundle2
explode bundle2
audit_blend_output before2 bundle2_1
catch {chamf result2 bundle2_1 bundle2_4 bundle2_5 A .2 30} error2
audit_blend_output after2 bundle2_1
exit
