#include <algorithm>
#include <array>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <vector>
using V=std::array<double,3>;
double dist2(V p,V q){double s=0;for(int i=0;i<3;++i)s+=(p[i]-q[i])*(p[i]-q[i]);return s;}
struct Shape {
 double major,minor,height,r;int mode;double inner,cap;
 Shape(double R,double m,double h,double round,int mode):major(R),minor(m),height(h),r(round),mode(mode),inner(m-round),cap(mode==0?round:h-round){}
 double outer(double z)const{return major+std::sqrt(std::max(0.,minor*minor-z*z));}
 double distance(V p)const{
  double best=1e100;
  auto inside=[&](V q){double radial=std::max(0.,std::hypot(q[0],q[1])-major);return radial*radial+q[2]*q[2]<=inner*inner+1e-12;};
  auto consider=[&](V q){if(q[1]<r-1e-12||(mode==0?q[2]<cap-1e-12:q[2]>cap+1e-12)||!inside(q))return;best=std::min(best,dist2(p,q));};
  V planar{p[0],std::max(p[1],r),mode==0?std::max(p[2],cap):std::min(p[2],cap)};
  if(inside(planar))return dist2(p,planar);
  double rho=std::hypot(p[0],p[1]);
  if(rho>major){double d=std::hypot(rho-major,p[2]),R=major+(rho-major)*inner/d;consider({p[0]*R/rho,p[1]*R/rho,p[2]*inner/d});}
  else consider({p[0],p[1],std::copysign(inner,p[2])});
  double base=std::sqrt(major*major-r*r),pi=std::acos(-1.);
  if(p[0]<=base){consider({p[0],r,inner});consider({p[0],r,-inner});}
  else{
   double lo=-pi/2,hi=pi/2;
   for(int i=0;i<40;++i){double theta=(lo+hi)/2,R=major+inner*std::cos(theta),x=std::sqrt(R*R-r*r);double derivative=std::sin(theta)*(-major+R*p[0]/x)-p[2]*std::cos(theta);if(derivative>0)hi=theta;else lo=theta;}
   double theta=(lo+hi)/2,R=major+inner*std::cos(theta);consider({std::sqrt(R*R-r*r),r,inner*std::sin(theta)});
  }
  double R=major+std::sqrt(inner*inner-cap*cap);
  if(rho>0)consider({R*p[0]/rho,R*p[1]/rho,cap});
  if(R>=r)consider({std::sqrt(R*R-r*r),r,cap});
  return best;
 }
};
std::vector<std::pair<double,double>> gauss(int n){
 const double pi=std::acos(-1.);std::vector<std::pair<double,double>> nodes;
 for(int i=0;i<n;i++) {double x=std::cos(pi*(i+.75)/(n+.5)),der=0;for(int j=0;j<30;j++){double p=1,q=0;for(int k=1;k<=n;k++){double next=((2*k-1)*x*p-(k-1)*q)/k;q=p;p=next;}der=n*(x*p-q)/(x*x-1);double d=p/der;x-=d;if(std::abs(d)<2e-15)break;}nodes.emplace_back(x,2/((1-x*x)*der*der));}return nodes;
}
double volume(const Shape&s,int n){
 auto nodes=gauss(n);double total=0,pi=std::acos(-1.);std::vector<double> zs{0,s.height};
 for(double z:{s.cap,s.cap*s.minor/s.inner})if(z>0&&z<s.height)zs.push_back(z);
 std::sort(zs.begin(),zs.end());
 for(size_t k=1;k<zs.size();++k){double za=zs[k-1],zb=zs[k];for(auto[t,w]:nodes){double z=(za+zb+(zb-za)*t)/2,Y=s.outer(z),area=0;
  auto minimum=[&](double y){double upper=std::sqrt(std::max(0.,Y*Y-y*y));return s.distance({s.mode==2?std::min(s.r,upper):0.,y,z});};
  double peak=std::min(s.r,Y);if(minimum(peak)>s.r*s.r)continue;
  double ymin=0,ymax=Y,lo=0,hi=peak;
  if(minimum(0)>s.r*s.r){for(int i=0;i<40;++i){double y=(lo+hi)/2;if(minimum(y)<=s.r*s.r)hi=y;else lo=y;}ymin=(lo+hi)/2;}
  lo=peak;hi=Y;if(minimum(Y)>s.r*s.r){for(int i=0;i<40;++i){double y=(lo+hi)/2;if(minimum(y)<=s.r*s.r)lo=y;else hi=y;}ymax=(lo+hi)/2;}
  std::vector<double> ys{0,pi};for(double y:{s.r,s.r*s.minor/s.inner})if(y>ymin&&y<ymax)ys.push_back(std::acos(1-2*(y-ymin)/(ymax-ymin)));std::sort(ys.begin(),ys.end());
  for(size_t j=1;j<ys.size();++j){double a=ys[j-1],b=ys[j];for(auto[t2,w2]:nodes){double angle=(a+b+(b-a)*t2)/2,y=ymin+(ymax-ymin)*(1-std::cos(angle))/2,upper=std::sqrt(std::max(0.,Y*Y-y*y)),mid=s.mode==2?std::min(s.r,upper):0.;
   if(s.distance({mid,y,z})>s.r*s.r)continue;
   double lo=mid,hi=upper;for(int step=0;step<36;step++){double x=(lo+hi)/2;if(s.distance({x,y,z})<=s.r*s.r)lo=x;else hi=x;}double right=(lo+hi)/2,left=0;
   if(s.mode==2&&s.distance({0,y,z})>s.r*s.r){lo=0;hi=mid;for(int step=0;step<36;step++){double x=(lo+hi)/2;if(s.distance({x,y,z})<=s.r*s.r)hi=x;else lo=x;}left=(lo+hi)/2;}
   area+=(right-left)*(ymax-ymin)*std::sin(angle)/2*w2*(b-a)/2;
  }}total+=area*w*(zb-za)/2;
 }}return total;
}
double cavity(const Shape&s,double cap,int n){
 auto nodes=gauss(n);double pi=std::acos(-1.),total=0;
 std::vector<double> zs{cap,s.inner,s.minor};std::sort(zs.begin(),zs.end());
 for(size_t i=1;i<zs.size();++i){double a=zs[i-1],b=zs[i];for(auto[t,w]:nodes){double z=(a+b+(b-a)*t)/2;
  double cosine=-std::sqrt(std::max(0.,1-z*z/(s.minor*s.minor)));double R=s.major+s.minor*cosine;
  double critical=s.r/(1-s.r*cosine/R),ymin=z>s.inner?s.r-std::sqrt(std::max(0.,s.r*s.r-(z-s.inner)*(z-s.inner))):0;
  double original_strip=(critical*std::sqrt(R*R-critical*critical)+R*R*std::asin(critical/R))/2;
  double strip=0;
  for(auto[t2,w2]:nodes){double angle=pi*(t2+1)/2,y=ymin+(critical-ymin)*(1-std::cos(angle))/2,d=std::sqrt(std::max(0.,s.r*s.r-(y-s.r)*(y-s.r)));
   double lo=pi/2,hi=pi;
   for(int j=0;j<40;++j){double theta=(lo+hi)/2,rho=s.major+s.inner*std::cos(theta);double height=s.inner*std::sin(theta)+d*rho*std::sin(theta)/std::sqrt(rho*rho-s.r*s.r*std::cos(theta)*std::cos(theta));if(height>z)lo=theta;else hi=theta;}
   double theta=(lo+hi)/2,rho=s.major+s.inner*std::cos(theta),x=std::sqrt(rho*rho-s.r*s.r);x+=d*x*std::cos(theta)/std::sqrt(rho*rho-s.r*s.r*std::cos(theta)*std::cos(theta));
   strip+=x*(critical-ymin)*std::sin(angle)/2*w2*pi/2;
  }
  total+=(pi*R*R/4-original_strip+strip)*w*(b-a)/2;
 }}return total;
}
int main(int argc,char**argv){std::cout<<std::setprecision(17);int n=argc>1?std::stoi(argv[1]):128;double r=argc>2?std::stod(argv[2]):.1;
 for(int kind=0;kind<2;++kind){Shape s(1.,1.,1/std::sqrt(2.),r,kind);std::cout<<"kind "<<kind<<" radius "<<r<<" nodes "<<n<<" quarter_volume "<<volume(s,n)<<std::endl;}
 Shape s(2.,.5,.5,r,0);double outer=volume(s,n),inner=cavity(s,.5*std::sin(160*std::acos(-1.)/180),n);
 std::cout<<"kind 2 radius "<<r<<" nodes "<<n<<" quarter_volume "<<outer-inner<<" outer "<<outer<<" cavity "<<inner<<std::endl;
}
