from pathlib import Path
import json,hashlib,zipfile,re
out=Path('truck-benchmarks/results/2026-10-22-torus-corners');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
v=json.loads((out/'validation.json').read_text());parent=json.loads((out/'parent.json').read_text())
for p,h in v['source_sha256'].items():assert sha(p)==h,p
assert parent['test_sha256']==parent['parent_test_sha256']
for p,h in parent['test_sha256'].items():assert sha(p)==h,p
files={};comparisons={}
for name in ['E6','E8','F3']:
 probe=Path('target/torus-corner-verified-replays')/name
 r=json.loads((probe/'001.truck.json').read_text())['result'];c=json.loads((probe/'001.comparison.json').read_text())
 assert r['status']=='operation-succeeded' and r['selected_edges']==3 and r['selection_scope']=='native-contours'
 assert all(r[k] is True for k in ['input_unchanged','geometry_consistent','mesh_closed','step_prepared'])
 assert c['native_valid'] and c['truck_step_valid'] and c['native_solids']==c['truck_solids']==1
 assert max(c['native_to_truck_max_distance'],c['truck_to_native_max_distance'])>.001
 assert max(c['truck_step_tolerances'].values())<.001
 comparisons[name]=c
 for p in probe.iterdir():
  if p.is_file():files[f'probe/{name}/{p.name}']=p
controls=json.loads(Path('target/torus-corner-volume-controls.json').read_text());maximum=controls['maximum_difference'];assert maximum<1e-7
for row in controls['rows'].values():assert max(abs(x-y) for x,y in zip(row['n128'],row['n256']))<1e-7
refined=[float(x) for x in re.findall(r'quarter_volume ([^ \n]+)',Path('target/torus-corner-volume-nonconvex-512.txt').read_text())]
assert len(refined)==3
refinement=max(abs(x-y) for x,y in zip(refined,controls['rows']['0.1']['n256']));assert refinement<5e-9
for p in Path('target').glob('torus-corner-volume-nonconvex-*.txt'):files['volume/'+p.name]=p
files['volume/torus-corner-volume.cpp']=Path('target/torus-corner-volume.cpp')
files['volume/controls.json']=Path('target/torus-corner-volume-controls.json')
for name in ['prove-torus-corner-parent.py','validate-torus-corners.py','verify-torus-corner-replays.py','package-torus-corner-proof.py']:
 files['helpers/'+name]=Path('target')/name
for name in parent['test_sha256']:files['parent/'+name]=Path('target/torus-corner-parent-source')/name
preservation=json.loads(Path('target/torus-cone-preservation/summary.json').read_text())
files['diagnostics/cone-preservation.json']=Path('target/torus-cone-preservation/summary.json')
files['diagnostics/torus-corner-design.txt']=Path('target/torus-corner-design.txt')
for p in Path('target/torus-corner-design').glob('*.truck-surfaces.txt'):files['diagnostics/'+p.name]=p
commands={'volume':['g++','-O3','-std=c++17','torus-corner-volume.cpp','-o','PROGRAM'],'volume_run':'PROGRAM N RADIUS; N is 128, 256 or 512; radii 0.03,0.06,0.1','note':'F3 subtracts the independently integrated nonconvex inner cavity; no CAD builder or mesh is used by the volume oracle. Native comparisons retain their original thresholds.'};p=out/'control-commands.json';p.write_text(json.dumps(commands,indent=2)+'\n');files['helpers/control-commands.json']=p
hashes={k:sha(p) for k,p in files.items()};archive=out/'controls.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(files.items()):z.write(p,name)
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(files)
 for name,p in files.items():assert hashlib.sha256(z.read(name)).hexdigest()==hashes[name]==sha(p),name
summary=dict(procedural_operations=36,oversized_rejections=6,mixed_sign_rejections=1,normalized_imported_selections=6,original_scale_replays=3,independent_material=controls,quadrature_maximum_difference=maximum,quadrature_256_512_difference=refinement,native_comparisons=comparisons,cone_prototype_preservation=preservation,archive_sha256=sha(archive),archive_members=len(files),member_sha256=hashes)
(out/'controls-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(out/'REPORT.md').write_text(f'''# Toroidal support corners with planar terminations

Three convex selected edges on an outward torus and two planes now join an exact
rolling sphere, toroidal cap rounds and fitted torus/radial-plane blends. Offset
torus intersections locate the sphere. Minor-angle rolling centers preserve the
selected meridian branch. Fitted contacts intersect remote caps before shared
trim edges are assembled. Existing validity and trim guards remain.

Both new regressions fail on parent {parent['revision']} with identical sources
and fixtures. Clean package builds avoid shared-worktree Cargo cache reuse.
The 36 procedural operations cover 45/160-degree profiles, three radii, two
placements and both selection orders. Exact radii and center, fitted radius
residual below 1e-5, nine tangent joins with normal dot greater than 1-1e-7,
closed material, STEP and input immutability are checked. Six oversized requests
and one mixed convex/concave selection reject. F1 remains unsupported.

Material is independently integrated by projecting onto the inward outer torus
intersected with selected offset half-spaces and integrating its radius-r dilation.
The nonconvex F3 profile subtracts its inner cavity using the exact rolling-sphere
envelope on its rounded wall strip. This calculation is independent of the builder,
surface fitter and mesh. The 128/256-node controls differ by at most {maximum:.8g};
a separate 512-node radius-0.1 run checks convergence. Six normalized native
selections and three original-scale production replays preserve the three edges.

All three native comparisons remain discrepancies. Their construction checks and
independent material controls pass, but those observations do not establish full
native parity or a global error bound. Native-reader STEP tolerances remain below
0.001. Cone arithmetic is preserved; isolated original-scale cone replays and their
native comparisons match exactly. A fresh full corpus capture remains required.

Validation: 469 release shapeops tests (one existing ignore), 119 STEP tests,
75 replay tests, 13 capture tests, all-target Clippy and single-thread actions
smoke pass. Native reference 8, volume 27 and distance 24 checks pass. Existing
test warnings remain recorded. Geometry, modeling and meshalgo evidence is reused
only with identical source hashes; the known pcurve_derivation precision failure
remains explicit. Replay is built last. No existing assertions, thresholds or
replay fitting budgets were weakened.

Proof archive: {len(files)} members; SHA256 {sha(archive)}.
Implementation is committed before a fresh full 648-operation capture.
No consumer/pin changes, push, PR or performance claim.
''')
print('Proof archive verified',len(files),sha(archive))
