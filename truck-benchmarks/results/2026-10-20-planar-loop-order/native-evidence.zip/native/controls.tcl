pload ALL
pload -BlendAudit BLENDAUDIT
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
restore "/home/krone/Development/Pieza_WS/truck/target/native-reordered-loops/outer.brep" bundle0
explode bundle0
audit_blend_output before0 bundle0_1
catch {chamf result0 bundle0_1 bundle0_2 .2} error0
audit_blend_output after0 bundle0_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-reordered-loops/outer.brep" bundle1
explode bundle1
audit_blend_output before1 bundle1_1
catch {chamf result1 bundle1_1 bundle1_2 bundle1_3 .2 0.1} error1
audit_blend_output after1 bundle1_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-reordered-loops/inner.brep" bundle2
explode bundle2
audit_blend_output before2 bundle2_1
catch {chamf result2 bundle2_1 bundle2_2 .2} error2
audit_blend_output after2 bundle2_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-reordered-loops/inner.brep" bundle3
explode bundle3
audit_blend_output before3 bundle3_1
catch {chamf result3 bundle3_1 bundle3_2 bundle3_3 .2 0.1} error3
audit_blend_output after3 bundle3_1
exit
