#include <BRepAdaptor_Curve.hxx>
#include <BRepAdaptor_Surface.hxx>
#include <BRepPrimAPI_MakeBox.hxx>
#include <BRepAlgoAPI_Cut.hxx>
#include <BRepCheck_Analyzer.hxx>
#include <BRepGProp.hxx>
#include <GProp_GProps.hxx>
#include <BRepTools.hxx>
#include <BRep_Builder.hxx>
#include <TopExp_Explorer.hxx>
#include <TopoDS.hxx>
#include <TopoDS_Compound.hxx>
#include <cmath>
#include <stdexcept>
#include <string>
int main(int argc,char**argv){
 if(argc!=2)return 1;
 auto solid=BRepPrimAPI_MakeBox(10.,10.,5.).Shape();
 for(double v:{2.,6.})solid=BRepAlgoAPI_Cut(solid,BRepPrimAPI_MakeBox(gp_Pnt(v,v,-1.),2.,2.,7.).Shape()).Shape();
 if(!BRepCheck_Analyzer(solid).IsValid())throw std::runtime_error("invalid input");
 GProp_GProps props;BRepGProp::VolumeProperties(solid,props);if(std::abs(props.Mass()-460)>1e-8)throw std::runtime_error("wrong material");
 for(bool inner:{false,true}){
  TopoDS_Edge rim;TopoDS_Face cap;gp_Pnt middle(inner?3.:5.,inner?2.:0.,5.);
  for(TopExp_Explorer it(solid,TopAbs_FACE);it.More();it.Next()){
   auto f=TopoDS::Face(it.Current());BRepAdaptor_Surface s(f);
   if(s.GetType()!=GeomAbs_Plane||std::abs(std::abs(s.Plane().Axis().Direction().Z())-1)>1e-8||std::abs(s.Plane().Location().Z()-5)>1e-8)continue;
   for(TopExp_Explorer e(f,TopAbs_EDGE);e.More();e.Next()){
    auto edge=TopoDS::Edge(e.Current());BRepAdaptor_Curve c(edge);if(c.Value((c.FirstParameter()+c.LastParameter())/2).Distance(middle)<1e-8){rim=edge;cap=f;}
   }
  }
  if(rim.IsNull()||cap.IsNull())throw std::runtime_error("missing rim");
  TopoDS_Compound bundle;BRep_Builder b;b.MakeCompound(bundle);b.Add(bundle,solid);b.Add(bundle,rim);b.Add(bundle,cap);
  if(!BRepTools::Write(bundle,(std::string(argv[1])+(inner?"/inner.brep":"/outer.brep")).c_str()))return 1;
 }
}
