#include <BRepGProp.hxx>
#include <BRepMesh_IncrementalMesh.hxx>
#include <BRep_Tool.hxx>
#include <TopExp_Explorer.hxx>
#include <TopoDS.hxx>
#include <Poly_Triangulation.hxx>
#include <BRepTools.hxx>
#include <BRep_Builder.hxx>
#include <GProp_GProps.hxx>
#include <STEPControl_Reader.hxx>
#include <TopoDS_Shape.hxx>
#include <iomanip>
#include <iostream>
int main(int argc,char**argv){std::cout<<std::setprecision(17);for(int i=1;i<argc;i++){TopoDS_Shape shape;std::string path=argv[i];if(path.ends_with(".brep")){BRep_Builder b;if(!BRepTools::Read(shape,argv[i],b))return 2;}else{STEPControl_Reader r;if(r.ReadFile(argv[i])!=IFSelect_RetDone)return 3;r.TransferRoots();shape=r.OneShape();}std::cout<<path<<"\n";for(double tol:{1e-5,1e-6}){BRepTools::Clean(shape);BRepMesh_IncrementalMesh mesh(shape,tol,false,0.05,false);long double sum=0;for(TopExp_Explorer it(shape,TopAbs_FACE);it.More();it.Next()){auto face=TopoDS::Face(it.Current());TopLoc_Location location;auto triangles=BRep_Tool::Triangulation(face,location);if(triangles.IsNull())return 4;for(int j=1;j<=triangles->NbTriangles();++j){int a,b,c;triangles->Triangle(j).Get(a,b,c);auto p=triangles->Node(a).Transformed(location.Transformation()).XYZ();auto q=triangles->Node(b).Transformed(location.Transformation()).XYZ();auto r=triangles->Node(c).Transformed(location.Transformation()).XYZ();double v=p.Dot(q.Crossed(r))/6.;sum+=(face.Orientation()==TopAbs_REVERSED?-v:v);}}std::cout<<"mesh tol="<<tol<<" volume="<<(double)sum<<"\n";}for(double e:{1e-7,1e-9,1e-11}){GProp_GProps a,b;double x=BRepGProp::VolumeProperties(shape,a,e,true,false);double y=BRepGProp::VolumePropertiesGK(shape,b,e,true,true);std::cout<<e<<" Gauss="<<a.Mass()<<" error="<<x<<" GK="<<b.Mass()<<" error="<<y<<"\n";}}}
