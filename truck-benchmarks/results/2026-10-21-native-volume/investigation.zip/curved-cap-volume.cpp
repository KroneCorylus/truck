#include <BRepGProp.hxx>
#include <BRepTools.hxx>
#include <BRep_Builder.hxx>
#include <GProp_GProps.hxx>
#include <STEPControl_Reader.hxx>
#include <TopoDS_Shape.hxx>
#include <iomanip>
#include <iostream>
int main(int argc,char**argv){std::cout<<std::setprecision(17);for(int i=1;i<argc;i++){TopoDS_Shape shape;std::string path=argv[i];if(path.ends_with(".brep")){BRep_Builder b;if(!BRepTools::Read(shape,argv[i],b))return 2;}else{STEPControl_Reader r;if(r.ReadFile(argv[i])!=IFSelect_RetDone)return 3;r.TransferRoots();shape=r.OneShape();}std::cout<<path<<"\n";for(double e:{1e-7,1e-9,1e-11}){GProp_GProps a,b;double x=BRepGProp::VolumeProperties(shape,a,e,true,false);double y=BRepGProp::VolumePropertiesGK(shape,b,e,true,true);std::cout<<e<<" Gauss="<<a.Mass()<<" error="<<x<<" GK="<<b.Mass()<<" error="<<y<<"\n";}}}
