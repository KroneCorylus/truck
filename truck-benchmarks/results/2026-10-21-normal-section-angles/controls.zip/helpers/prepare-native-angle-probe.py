from pathlib import Path
import json,subprocess
s=Path('target/normal-section-native.cpp').read_text()
a=s.index('  TopoDS_Face reference;');b=s.index('   auto shape=operation.Shape();',a)
s=s[:a]+'''  std::array<TopoDS_Face,2> references;
  for(TopExp_Explorer f(input,TopAbs_FACE);f.More();f.Next()){
   auto face=TopoDS::Face(f.Current());
   for(TopExp_Explorer e(face,TopAbs_EDGE);e.More();e.Next())if(e.Current().IsSame(guide))references[BRepAdaptor_Surface(face).GetType()==GeomAbs_Plane?1:0]=face;
  }
  if(references[0].IsNull()||references[1].IsNull())return 3;
  for(int side:{0,1})for(double degrees:{30.,45.,60.}){
   const double d=.1,angle=degrees*std::acos(-1.)/180.,tangent=std::tan(angle);
   const double x=side?2*d/(1/tangent+std::sqrt(1/(tangent*tangent)-4*k*d)):d*std::sqrt(2/(1+std::sqrt(1+4*k*k*d*d)));
   const double wall=side?d:x*(2*k*x+tangent)/(1-2*k*x*tangent)-k*x*x;
   const double cap=std::sqrt(x*x+k*k*x*x*x*x);
   BRepFilletAPI_MakeChamfer operation(input);operation.AddDA(d,angle,guide,references[side]);operation.Build();if(!operation.IsDone())return 4;
''' +s[b:]
s=s.replace('double x=cap*std::sqrt(2/(1+std::sqrt(1+4*k*k*cap*cap)));double expected=', 'double expected=')
s=s.replace('<<",\\\"cap\\\":"<<cap', '<<",\\\"reference_side\\\":"<<side<<",\\\"angle_degrees\\\":"<<degrees<<",\\\"cap\\\":"<<cap')
Path('target/native-angle-probe.cpp').write_text(s)
cmd=json.load(open('target/normal-section-native-command.json'));cmd=[x.replace('target/normal-section-native','target/native-angle-probe') for x in cmd]
Path('target/native-angle-controls').mkdir(exist_ok=True)
with open('target/native-angle-build.txt','w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
with open('target/native-angle-run.txt','w') as f:subprocess.run(['target/native-angle-probe','target/native-angle-controls'],stdout=f,stderr=subprocess.STDOUT,check=True)
m=json.load(open('target/native-angle-controls/summary.json'))
assert len(m)==12
for row in m:assert row['valid'] and row['input_unchanged'];assert abs(row['volume']-row['expected'])<1e-12,row
print('12 native distance-angle controls passed; maximum material error',max(abs(x['volume']-x['expected']) for x in m))
