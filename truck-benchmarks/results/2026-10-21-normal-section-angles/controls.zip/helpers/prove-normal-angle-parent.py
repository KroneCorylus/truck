from pathlib import Path
import subprocess,os,json,hashlib
root=Path.cwd();parent=root/'target/normal-angle-parent-source';out=root/'truck-benchmarks/results/2026-10-21-normal-section-angles';out.mkdir(exist_ok=True)
revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=parent,text=True).strip()==revision
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=Path('truck-shapeops/tests/normal_section_angle.rs').read_text()
adapter='''
fn try_chamfer_solid_along_wire_angle(
 solid:&Solid,wire:&Wire,reference:FaceID,distance:f64,angle:Rad<f64>,tol:f64,
)->std::result::Result<BlendResult,truck_base::diagnostics::Diagnostic>{
 let face=solid.face_iter().find(|f|f.id()==reference).unwrap();
 let edge=wire.front().unwrap();
 let found=face.edge_iter().find(|e|e.id()==edge.id()).unwrap();
 let side=usize::from(found.front()!=edge.front());
 let mut distances=[distance;2];distances[1-side]=distance*angle.0.tan();
 try_chamfer_solid_along_wire_chord(solid,wire,distances[0],distances[1],tol)
}
'''
test=Path('truck-shapeops/tests/normal_section_angle.rs');(parent/test).write_text(source+adapter)
replay=Path('truck-shapeops/examples/replay_occt_blend.rs');r=subprocess.check_output(['git','show',f'{revision}:{replay}'],text=True);assert r.rstrip().endswith('}')
t=Path('target/angle-replay-test.rs').read_text();(parent/replay).write_text(r.rstrip()[:-1]+t+'}\n')
env=dict(os.environ,CARGO_BUILD_JOBS='12',CARGO_TARGET_DIR=str(root/'target'))
with (out/'parent-clean.txt').open('w') as log:subprocess.run(['cargo','clean','--release','-p','truck-shapeops'],cwd=parent,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
for name,cmd,proof in [
 ('parent-tests.txt',['cargo','test','--release','-p','truck-shapeops','--test','normal_section_angle','normal_section_angles_preserve'],'0 passed; 2 failed'),
 ('parent-replay-tests.txt',['cargo','test','--release','-p','truck-shapeops','--example','replay_occt_blend','sampled_reference_angles_preserve_contacts_and_material'],'0 passed; 1 failed')]:
 with (out/name).open('w') as log:
  log.write('$ '+' '.join(cmd)+'\n');log.flush();r=subprocess.run(cmd,cwd=parent,env=env,stdout=log,stderr=subprocess.STDOUT);log.write(f'exit_code {r.returncode}\n')
 assert r.returncode==101,(name,r.returncode);assert proof in (out/name).read_text(),name
 print(name,'expected failure confirmed',flush=True)
m=dict(revision=revision,test_sha256=sha(root/test),parent_test_sha256=sha(parent/test),binding_change='The new distance-angle API does not exist on the parent. The same geometry assertions use an explicit adapter to the existing chord API with distance and distance*tan(angle), ordered by the reference face. Parent replay assertions are unchanged.',parent_adapter=adapter,replay_test_sha256=sha('target/angle-replay-test.rs'))
(out/'parent.json').write_text(json.dumps(m,indent=2)+'\n');print('Parent proof complete',flush=True)
