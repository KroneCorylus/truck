from pathlib import Path
import json,subprocess,os
s=Path('truck-shapeops/tests/normal_section_angle.rs').read_text().replace('mod common;', '#[path="'+str(Path('truck-shapeops/tests/common/mod.rs').resolve())+'"] mod common;')
s+='''
#[test]
fn export_controls(){
 use truck_stepio::out::*;
 let mut index=0;
 for curvature in [0.8,-0.4]{
  let (solid,edge)=fixture(Matrix4::identity(),curvature);
  for wall_reference in [false,true]{for degrees in [30_f64,45.,60.]{
   let reference=solid.face_iter().find(|face|matches!(face.surface(),Surface::Plane(_))==wall_reference&&face.edge_iter().any(|e|e.id()==edge.id())).unwrap().id();
   let wire:Wire=vec![edge.clone()].into();
   let result=try_chamfer_solid_along_wire_angle(&solid,&wire,reference,0.1,Rad(degrees.to_radians()),0.001).unwrap();
   for (label,shape) in [("input",&solid),("result",&result.solid)]{
    let prepared=prepare_for_step(&shape.compress(),1e-7).unwrap();
    let step=StepDisplay::new(Default::default(),StepDesign::from_model(StepModel::from(&prepared))).to_string();
    std::fs::write(format!("target/truck-normal-angle/{index}.{label}.step"),step).unwrap();
   }
   index+=1;
  }}
 }
}
'''
Path('target/normal-angle-export.rs').write_text(s);Path('target/truck-normal-angle').mkdir(exist_ok=True)
cmd=json.loads(Path('target/normal-section-export-command.json').read_text());cmd=[q.replace('normal-section-export','normal-angle-export') for q in cmd]
Path('target/normal-angle-export-command.json').write_text(json.dumps(cmd)+'\n')
with Path('target/normal-angle-export-build.txt').open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
with Path('target/normal-angle-export.txt').open('w') as f:subprocess.run(['target/normal-angle-export','--exact','export_controls'],stdout=f,stderr=subprocess.STDOUT,check=True)
rows=[]
for n in json.loads(Path('target/native-angle-controls/summary.json').read_text()):
 i=n['index'];assert n['valid'] and n['input_unchanged'];assert abs(n['volume']-n['expected'])<1e-12
 row={'index':i,'native':n}
 for label in ['input','result']:
  path=Path(f'target/truck-normal-angle/{i}.{label}.comparison.json')
  with path.with_suffix('.log').open('w') as f:subprocess.run(['target/occt-distance-tree-plugin/compare_shapes',f'target/native-angle-controls/{i}.{label}.brep',f'target/truck-normal-angle/{i}.{label}.step',str(path)],stdout=f,stderr=subprocess.STDOUT,env=os.environ|{'LD_LIBRARY_PATH':str(Path('target/occt-sdk/usr/lib64').resolve())},check=True,timeout=120)
  c=json.loads(path.read_text());assert c['native_valid'] and c['truck_step_valid'] and c['native_solids']==c['truck_solids']==1
  assert max(c['native_to_truck_max_distance'],c['truck_to_native_max_distance'])<1e-6
  expected=n['expected'] if label=='result' else 1+n['curvature']/3
  assert abs(c['truck_volume']-expected)<1e-8
  row[label]=c
 rows.append(row);print(i,max(row['result'][k] for k in ['native_to_truck_max_distance','truck_to_native_max_distance']),flush=True)
Path('target/normal-angle-comparisons.json').write_text(json.dumps(rows,indent=2)+'\n')
