    #[test]
    fn sampled_reference_angles_preserve_contacts_and_material() {
        for index in 0..4 {
            let (step, task) = fixture(index);
            let matrix = if index % 2 == 0 {
                Matrix4::identity()
            } else {
                Matrix4::from_translation(Vector3::new(0.3, -0.2, 0.1))
                    * Matrix4::from_axis_angle(Vector3::new(1., 2., 3.).normalize(), Rad(0.7))
            };
            let inverse = matrix.invert().unwrap();
            let curvature: f64 = if index < 2 { 0.8 } else { -0.4 };
            for wall_reference in [false, true] {
                for reverse in [false, true] {
                    for degrees in [30_f64, 45., 60.] {
                        let d = 0.1_f64;
                        let tangent = degrees.to_radians().tan();
                        let x = if wall_reference {
                            2. * d
                                / (1. / tangent
                                    + (1. / (tangent * tangent) - 4. * curvature * d).sqrt())
                        } else {
                            d * (2. / (1. + (1. + 4. * curvature * curvature * d * d).sqrt()))
                                .sqrt()
                        };
                        let wall = if wall_reference {
                            d
                        } else {
                            x * (2. * curvature * x + tangent) / (1. - 2. * curvature * x * tangent)
                                - curvature * x * x
                        };
                        let cap = (x * x + curvature * curvature * x.powi(4)).sqrt();
                        let dir = std::env::temp_dir().join(format!(
                            "truck-normal-angle-{}-{index}-{wall_reference}-{reverse}-{cap}-{wall}",
                            std::process::id()
                        ));
                        std::fs::create_dir_all(&dir).unwrap();
                        let prefix = dir.join("001");
                        let prefix = prefix.to_str().unwrap();
                        std::fs::write(format!("{prefix}.input.step"), step).unwrap();
                        let mut task = task.clone();
                        let chosen = &mut task["selection"][0];
                        chosen["mode"] = json!("distance-angle");
                        chosen["distance"] = json!(d);
                        chosen["angle_degrees"] = json!(degrees);
                        chosen.as_object_mut().unwrap().remove("distances");
                        if wall_reference {
                            chosen.as_object_mut().unwrap().remove("reference_sample");
                            let p = matrix.transform_point(Point3::origin());
                            let n = matrix.transform_vector(Vector3::unit_x());
                            chosen["reference_plane"] =
                                json!({"origin":[p.x,p.y,p.z],"normal":[n.x,n.y,n.z]});
                        }
                        if reverse {
                            chosen["points"].as_array_mut().unwrap().reverse();
                            for edge in chosen["contour_edges"].as_array_mut().unwrap() {
                                edge["points"].as_array_mut().unwrap().reverse();
                            }
                            if !chosen["reference_sample"].is_null() {
                                for q in
                                    chosen["reference_sample"]["normal"].as_array_mut().unwrap()
                                {
                                    *q = json!(-q.as_f64().unwrap());
                                }
                            }
                        }
                        std::fs::write(format!("{prefix}.input.json"), task.to_string()).unwrap();
                        let result = replay(prefix, &Cell::new("start")).unwrap();
                        assert_eq!(result["status"], "operation-succeeded", "{result}");
                        assert_eq!(result["selected_edges"], 1);
                        for field in [
                            "input_unchanged",
                            "geometry_consistent",
                            "mesh_closed",
                            "step_prepared",
                        ] {
                            assert_eq!(result[field], true, "{field}: {result}");
                        }
                        let output = import(&format!("{prefix}.truck.step")).unwrap();
                        let x = cap
                            * (2. / (1. + (1. + 4. * curvature * curvature * cap * cap).sqrt()))
                                .sqrt();
                        let expected =
                            1. + curvature / 3. - wall * x / 2. + curvature * x.powi(3) / 6.;
                        replay_common::assert_solid(&output, expected, &[0], 1e-6);
                        replay_common::blend::assert_step(&output, expected, 2e-6);
                        let mut seen = HashSet::new();
                        let mut counts = [0; 2];
                        for edge in output.edge_iter().filter(|e| seen.insert(e.id())) {
                            let c = edge.oriented_curve();
                            let (a, b) = c.range_tuple();
                            let mid = inverse.transform_point(c.subs((a + b) / 2.));
                            let side = if mid.x.abs() < 1e-6 && (mid.z - (1. - wall)).abs() < 1e-6 {
                                0
                            } else if (mid.x - x).abs() < 1e-6
                                && (mid.z - (1. + curvature * x * x)).abs() < 1e-6
                            {
                                1
                            } else {
                                continue;
                            };
                            for i in 0..=32 {
                                let p =
                                    inverse.transform_point(c.subs(a + (b - a) * i as f64 / 32.));
                                let distance = p.distance(Point3::new(0., p.y, 1.));
                                assert!(
                                    (distance - if side == 0 { wall } else { cap }).abs() < 1e-6
                                );
                                assert!((p.x - if side == 0 { 0. } else { x }).abs() < 1e-6);
                                assert!(
                                    (p.z - if side == 0 {
                                        1. - wall
                                    } else {
                                        1. + curvature * x * x
                                    })
                                    .abs()
                                        < 1e-6
                                );
                                counts[side] += 1;
                            }
                        }
                        assert_eq!(counts, [33, 33]);
                        assert_eq!(
                            std::fs::read_to_string(format!("{prefix}.input.step")).unwrap(),
                            step
                        );
                        std::fs::remove_dir_all(dir).unwrap();
                    }
                }
            }
        }
    }
