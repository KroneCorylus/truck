#include <BRepAdaptor_Curve.hxx>
#include <BRepAdaptor_Surface.hxx>
#include <BRepBuilderAPI_MakeEdge.hxx>
#include <BRepBuilderAPI_MakeFace.hxx>
#include <BRepBuilderAPI_MakeWire.hxx>
#include <BRepPrimAPI_MakePrism.hxx>
#include <BRepPrimAPI_MakeBox.hxx>
#include <BRepPrimAPI_MakeCylinder.hxx>
#include <BRepAlgoAPI_Cut.hxx>
#include <BRepCheck_Analyzer.hxx>
#include <BRepGProp.hxx>
#include <BRepTools.hxx>
#include <BRep_Builder.hxx>
#include <GProp_GProps.hxx>
#include <TopExp.hxx>
#include <TopExp_Explorer.hxx>
#include <TopoDS.hxx>
#include <TopoDS_Compound.hxx>
#include <gp_Circ.hxx>
#include <cmath>
#include <iostream>
#include <iomanip>
#include <stdexcept>
#include <string>
#include <BRepAlgoAPI_Common.hxx>
#include <BRepAlgoAPI_Fuse.hxx>
int main(int argc,char**argv) {
 if(argc!=2)return 1;
 const double radius=5.,halfwidth=2.,level=5.,height=10.;
 auto lower=BRepPrimAPI_MakeCylinder(radius,level).Shape();
 auto upper=BRepPrimAPI_MakeCylinder(gp_Ax2(gp_Pnt(0,0,level),gp_Dir(0,0,1)),radius,height-level).Shape();
 auto box=BRepPrimAPI_MakeBox(gp_Pnt(0,-halfwidth,-1),8,2*halfwidth,level+1).Shape();
 auto notch=BRepAlgoAPI_Cut(lower,box).Shape();
 auto solid=BRepAlgoAPI_Cut(BRepPrimAPI_MakeCylinder(radius,height).Shape(),box).Shape();
 if(!BRepCheck_Analyzer(solid).IsValid())throw std::runtime_error("invalid solid");
 TopoDS_Edge first,second;TopoDS_Face top;
 for(TopExp_Explorer it(solid,TopAbs_FACE);it.More();it.Next()) {
  auto face=TopoDS::Face(it.Current());BRepAdaptor_Surface surface(face);
  if(surface.GetType()!=GeomAbs_Plane||std::abs(std::abs(surface.Plane().Axis().Direction().Z())-1)>1e-8||std::abs(surface.Plane().Location().Z()-level)>1e-8)continue;
  top=face;
  for(TopExp_Explorer edges(face,TopAbs_EDGE);edges.More();edges.Next()) {
   auto edge=TopoDS::Edge(edges.Current());BRepAdaptor_Curve curve(edge);auto p=curve.Value((curve.FirstParameter()+curve.LastParameter())/2);
   if(curve.GetType()!=GeomAbs_Line||p.X()<1e-8)continue;
   if(std::abs(p.Y()-halfwidth)<1e-8)first=edge;
   if(std::abs(p.Y()+halfwidth)<1e-8)second=edge;
  }
 }
 if(top.IsNull()||first.IsNull()||second.IsNull())throw std::runtime_error("missing selection");
 const double removed=level*(halfwidth*std::sqrt(radius*radius-halfwidth*halfwidth)+radius*radius*std::asin(halfwidth/radius));
 const double expected=std::acos(-1.)*radius*radius*height-removed;
 GProp_GProps props;BRepGProp::VolumeProperties(solid,props);
 if(std::abs(props.Mass()-expected)>1e-7)throw std::runtime_error("volume mismatch");
 TopoDS_Compound bundle;BRep_Builder builder;builder.MakeCompound(bundle);builder.Add(bundle,solid);builder.Add(bundle,first);builder.Add(bundle,top);builder.Add(bundle,second);
 if(!BRepTools::Write(bundle,(std::string(argv[1])+"/input.brep").c_str()))return 1;
 std::cout<<std::setprecision(17)<<"volume "<<props.Mass()<<" expected "<<expected<<std::endl;
}
