#![allow(clippy::many_single_char_names)]

use super::*;
use crate::Point2;
use array_macro::array;
use handles::FixedVertexHandle;
use itertools::Itertools;
use polygon_mesh::PolygonMeshEditor;
use rustc_hash::FxHashMap as HashMap;

#[cfg(not(target_arch = "wasm32"))]
use rayon::prelude::*;

type SPoint2 = spade::Point2<f64>;
#[derive(Clone, Copy)]
struct MeshVertex {
    uv: SPoint2,
    metric: SPoint2,
}
impl HasPosition for MeshVertex {
    type Scalar = f64;
    fn position(&self) -> SPoint2 { self.metric }
}
struct MeshMetric {
    origin: Point2,
    scale: Vector2,
}
impl MeshMetric {
    fn new(surface: &impl PreMeshableSurface, bounds: BoundingBox<Point2>, refine: bool) -> Self {
        if !refine {
            return Self {
                origin: Point2::origin(),
                scale: Vector2::new(1., 1.),
            };
        }
        let origin = bounds.min().midpoint(bounds.max());
        let lengths = Vector2::new(
            surface.uder(origin.x, origin.y).magnitude(),
            surface.vder(origin.x, origin.y).magnitude(),
        );
        let mut scale = lengths / lengths.x.max(lengths.y);
        if !scale.x.is_finite() || !scale.y.is_finite() || scale.x <= 0. || scale.y <= 0. {
            scale = Vector2::new(1., 1.);
        }
        Self { origin, scale }
    }
    fn vertex(&self, u: f64, v: f64) -> MeshVertex {
        MeshVertex {
            uv: SPoint2::new(u, v),
            metric: SPoint2::new(
                (u - self.origin.x) * self.scale.x,
                (v - self.origin.y) * self.scale.y,
            ),
        }
    }
}
type Cdt = ConstrainedDelaunayTriangulation<MeshVertex>;
type MeshedShell = Shell<Point3, PolylineCurve, Option<PolygonMesh>>;
type MeshedCShell = CompressedShell<Point3, PolylineCurve, Option<PolygonMesh>>;

pub(super) trait SP<S>:
    Fn(&S, Point3, Option<(f64, f64)>) -> Option<(f64, f64)> + Parallelizable {
}
impl<S, F> SP<S> for F where F: Fn(&S, Point3, Option<(f64, f64)>) -> Option<(f64, f64)> + Parallelizable {}

pub(super) fn by_search_parameter<S>(
    surface: &S,
    point: Point3,
    hint: Option<(f64, f64)>,
) -> Option<(f64, f64)>
where
    S: MeshableSurface,
{
    surface
        .search_parameter(point, hint, 100)
        .or_else(|| surface.search_parameter(point, None, 100))
}

pub(super) fn by_search_nearest_parameter<S>(
    surface: &S,
    point: Point3,
    hint: Option<(f64, f64)>,
) -> Option<(f64, f64)>
where
    S: RobustMeshableSurface,
{
    surface
        .search_parameter(point, hint, 100)
        .or_else(|| surface.search_parameter(point, None, 100))
        .or_else(|| surface.search_nearest_parameter(point, hint, 100))
        .or_else(|| surface.search_nearest_parameter(point, None, 100))
}

fn edge_polyline<C: PolylineableCurve>(
    curve: &C,
    front: Point3,
    back: Point3,
    tol: f64,
) -> PolylineCurve {
    let mut poly = PolylineCurve::from_curve(curve, curve.range_tuple(), tol);
    // Close fitted-curve seams with shared vertices, preserving roundoff at singular poles.
    if let Some(point) = poly.first_mut().filter(|p| p.distance(front) > TOLERANCE2) {
        *point = front;
    }
    if let Some(point) = poly.last_mut().filter(|p| p.distance(back) > TOLERANCE2) {
        *point = back;
    }
    poly
}

/// Tessellates faces
#[cfg(not(target_arch = "wasm32"))]
pub(super) fn shell_tessellation<'a, C, S>(
    shell: &'a Shell<Point3, C, S>,
    tol: f64,
    sp: impl SP<S>,
) -> MeshedShell
where
    C: PolylineableCurve + 'a,
    S: PreMeshableSurface + 'a,
{
    if rayon::current_num_threads() == 1 {
        return shell_tessellation_single_thread(shell, tol, sp);
    }
    refine_winding(
        tol,
        |tol| shell_tessellation_once(shell, tol, &sp),
        |mesh, tol| repair_and_check_shell(shell, mesh, tol, &sp),
    )
}

#[cfg(not(target_arch = "wasm32"))]
fn shell_tessellation_once<'a, C, S>(
    shell: &'a Shell<Point3, C, S>,
    tol: f64,
    sp: impl SP<S>,
) -> MeshedShell
where
    C: PolylineableCurve + 'a,
    S: PreMeshableSurface + 'a,
{
    let vmap: HashMap<_, _> = shell
        .vertex_par_iter()
        .map(|v| (v.id(), v.mapped(Point3::clone)))
        .collect();
    let eset: HashMap<_, _> = shell.edge_par_iter().map(move |e| (e.id(), e)).collect();
    let edge_map: HashMap<_, _> = eset
        .into_par_iter()
        .map(move |(id, edge)| {
            let v0 = vmap.get(&edge.absolute_front().id()).unwrap();
            let v1 = vmap.get(&edge.absolute_back().id()).unwrap();
            let curve = edge.curve();
            let poly = edge_polyline(&curve, v0.point(), v1.point(), tol);
            (id, Edge::debug_new(v0, v1, poly))
        })
        .collect();
    let create_edge = |edge: &Edge<Point3, C>| -> Edge<_, _> {
        let new_edge = edge_map.get(&edge.id()).unwrap();
        match edge.orientation() {
            true => new_edge.clone(),
            false => new_edge.inverse(),
        }
    };
    let create_boundary =
        |wire: &Wire<Point3, C>| -> Wire<_, _> { wire.edge_iter().map(create_edge).collect() };
    let create_face = move |face: &Face<Point3, C, S>| -> Face<_, _, _> {
        let wires: Vec<_> = face
            .absolute_boundaries()
            .iter()
            .map(create_boundary)
            .collect();
        shell_create_polygon(&face.surface(), wires, face.orientation(), tol, &sp)
    };
    shell.face_par_iter().map(create_face).collect()
}

/// Tessellates faces
pub(super) fn shell_tessellation_single_thread<'a, C, S>(
    shell: &'a Shell<Point3, C, S>,
    tol: f64,
    sp: impl SP<S>,
) -> MeshedShell
where
    C: PolylineableCurve + 'a,
    S: PreMeshableSurface + 'a,
{
    refine_winding(
        tol,
        |tol| shell_tessellation_single_thread_once(shell, tol, &sp),
        |mesh, tol| repair_and_check_shell(shell, mesh, tol, &sp),
    )
}

fn shell_tessellation_single_thread_once<'a, C, S>(
    shell: &'a Shell<Point3, C, S>,
    tol: f64,
    sp: impl SP<S>,
) -> MeshedShell
where
    C: PolylineableCurve + 'a,
    S: PreMeshableSurface + 'a,
{
    use truck_base::entry_map::FxEntryMap as EntryMap;
    use truck_topology::Vertex as TVertex;
    let mut vmap = EntryMap::new(
        move |v: &TVertex<Point3>| v.id(),
        move |v| v.mapped(Point3::clone),
    );
    let mut edge_map = EntryMap::new(
        move |edge: &'a Edge<Point3, C>| edge.id(),
        move |edge| {
            let vf = edge.absolute_front();
            let v0 = vmap.entry_or_insert(vf).clone();
            let vb = edge.absolute_back();
            let v1 = vmap.entry_or_insert(vb).clone();
            let curve = edge.curve();
            let poly = edge_polyline(&curve, v0.point(), v1.point(), tol);
            Edge::debug_new(&v0, &v1, poly)
        },
    );
    let mut create_edge = move |edge: &'a Edge<Point3, C>| -> Edge<_, _> {
        let new_edge = edge_map.entry_or_insert(edge);
        match edge.orientation() {
            true => new_edge.clone(),
            false => new_edge.inverse(),
        }
    };
    let mut create_boundary = move |wire: &'a Wire<Point3, C>| -> Wire<_, _> {
        wire.edge_iter().map(&mut create_edge).collect()
    };
    let create_face = move |face: &'a Face<Point3, C, S>| -> Face<_, _, _> {
        let wires: Vec<_> = face
            .absolute_boundaries()
            .iter()
            .map(&mut create_boundary)
            .collect();
        shell_create_polygon(&face.surface(), wires, face.orientation(), tol, &sp)
    };
    shell.face_iter().map(create_face).collect()
}

/// Tessellates faces
pub(super) fn cshell_tessellation<'a, C, S>(
    shell: &CompressedShell<Point3, C, S>,
    tol: f64,
    sp: impl SP<S>,
) -> MeshedCShell
where
    C: PolylineableCurve + 'a,
    S: PreMeshableSurface + 'a,
{
    refine_winding(
        tol,
        |tol| {
            let mut mesh = cshell_tessellation_once(shell, tol, &sp);
            repair_compressed_trims(shell, &mut mesh, tol, &sp);
            mesh
        },
        |shell, _| {
            shell
                .faces
                .iter()
                .all(|f| f.surface.as_ref().is_none_or(consistent_winding))
        },
    )
}

fn cshell_tessellation_once<'a, C, S>(
    shell: &CompressedShell<Point3, C, S>,
    tol: f64,
    sp: impl SP<S>,
) -> MeshedCShell
where
    C: PolylineableCurve + 'a,
    S: PreMeshableSurface + 'a,
{
    let vertices = shell.vertices.clone();
    let tessellate_edge = |edge: &CompressedEdge<C>| {
        let curve = &edge.curve;
        CompressedEdge {
            vertices: edge.vertices,
            curve: edge_polyline(
                curve,
                vertices[edge.vertices.0],
                vertices[edge.vertices.1],
                tol,
            ),
        }
    };
    #[cfg(not(target_arch = "wasm32"))]
    let edges: Vec<_> = shell.edges.par_iter().map(tessellate_edge).collect();
    #[cfg(target_arch = "wasm32")]
    let edges: Vec<_> = shell.edges.iter().map(tessellate_edge).collect();
    let tessellate_face = |face: &CompressedFace<S>| CompressedFace {
        boundaries: face.boundaries.clone(),
        orientation: face.orientation,
        surface: compressed_face_polygon(face, &edges, tol, &sp),
    };
    #[cfg(not(target_arch = "wasm32"))]
    let faces = shell.faces.par_iter().map(tessellate_face).collect();
    #[cfg(target_arch = "wasm32")]
    let faces = shell.faces.iter().map(tessellate_face).collect();
    MeshedCShell {
        vertices,
        edges,
        faces,
    }
}

fn compressed_boundary<S: PreMeshableSurface>(
    surface: &S,
    wire: &[CompressedEdgeIndex],
    edges: &[CompressedEdge<PolylineCurve>],
    sp: impl SP<S>,
) -> Option<PolyBoundaryPiece> {
    let curves = wire
        .iter()
        .map(|edge| {
            let curve = edges.get(edge.index)?.curve.clone();
            Some(if edge.orientation {
                curve
            } else {
                curve.inverse()
            })
        })
        .collect::<Option<Vec<_>>>()?;
    PolyBoundaryPiece::try_new(surface, curves.into_iter(), sp)
}

fn compressed_face_polygon<S: PreMeshableSurface>(
    face: &CompressedFace<S>,
    edges: &[CompressedEdge<PolylineCurve>],
    tol: f64,
    sp: impl SP<S>,
) -> Option<PolygonMesh> {
    let pieces = face
        .boundaries
        .iter()
        .map(|wire| compressed_boundary(&face.surface, wire, edges, &sp))
        .collect::<Option<Vec<_>>>()?;
    let boundary = PolyBoundary::new(pieces, &face.surface, tol)?;
    Some(trimming_tessellation(&face.surface, &boundary, tol))
}

fn repair_and_check_shell<C: PolylineableCurve, S: PreMeshableSurface>(
    source: &Shell<Point3, C, S>,
    mesh: &mut MeshedShell,
    tol: f64,
    sp: impl SP<S>,
) -> bool {
    let mut missing = false;
    let consistent = mesh.iter().all(|face| match face.surface() {
        Some(surface) => consistent_winding(&surface),
        None => {
            missing = true;
            true
        }
    });
    if !consistent || !missing {
        return consistent;
    }
    let mut compressed = mesh.compress();
    repair_compressed_trims(&source.compress(), &mut compressed, tol, sp);
    for (face, repaired) in mesh.iter().zip(&compressed.faces) {
        face.set_surface(repaired.surface.clone());
        for (wire, indices) in face.absolute_boundaries().iter().zip(&repaired.boundaries) {
            for (edge, index) in wire.iter().zip(indices) {
                edge.set_curve(compressed.edges[index.index].curve.clone());
            }
        }
    }
    mesh.iter()
        .all(|face| face.surface().as_ref().is_none_or(consistent_winding))
}

fn repair_compressed_trims<C: PolylineableCurve, S: PreMeshableSurface>(
    source: &CompressedShell<Point3, C, S>,
    mesh: &mut MeshedCShell,
    tol: f64,
    sp: impl SP<S>,
) {
    if mesh.faces.iter().all(|face| face.surface.is_some()) {
        return;
    }
    let mut parameters = HashMap::<usize, Vec<f64>>::default();
    loop {
        let mut requested = vec![false; mesh.edges.len()];
        for (face, meshed) in source.faces.iter().zip(&mesh.faces) {
            if meshed.surface.is_some() {
                continue;
            }
            for wire in &face.boundaries {
                let Some(piece) = compressed_boundary(&face.surface, wire, &mesh.edges, &sp) else {
                    continue;
                };
                if piece.is_collapsed() {
                    for edge in wire {
                        requested[edge.index] = true;
                    }
                }
            }
        }
        let mut changed = vec![false; mesh.edges.len()];
        for (index, requested) in requested.into_iter().enumerate() {
            if !requested {
                continue;
            }
            let curve = &source.edges[index].curve;
            let params = parameters
                .entry(index)
                .or_insert_with(|| curve.parameter_division(curve.range_tuple(), tol).0);
            // Bound work on invalid trims; exhaustion leaves a reported missing face.
            if params.len() > 2048 {
                continue;
            }
            let mut refined = Vec::with_capacity(2 * params.len() - 1);
            for pair in params.windows(2) {
                refined.push(pair[0]);
                let middle = pair[0] + (pair[1] - pair[0]) / 2.0;
                if middle != pair[0] && middle != pair[1] {
                    refined.push(middle);
                }
            }
            if let Some(last) = params.last() {
                refined.push(*last);
            }
            if refined.len() == params.len() {
                continue;
            }
            // Keep the existing shared vertices, including fitted-curve endpoint corrections.
            let old = &mesh.edges[index].curve;
            let mut points: PolylineCurve = refined.iter().map(|t| curve.subs(*t)).collect();
            points[0] = old[0];
            let last = points.len() - 1;
            points[last] = old[old.len() - 1];
            mesh.edges[index].curve = points;
            *params = refined;
            changed[index] = true;
        }
        if !changed.iter().any(|changed| *changed) {
            break;
        }
        for (face, meshed) in source.faces.iter().zip(&mut mesh.faces) {
            if face
                .boundaries
                .iter()
                .flatten()
                .any(|edge| changed[edge.index])
            {
                meshed.surface = compressed_face_polygon(face, &mesh.edges, tol, &sp);
            }
        }
    }
}

// Spatial normal correction reverses a triangle's UV winding when its chords fold.
fn consistent_winding(mesh: &PolygonMesh) -> bool {
    mesh.tri_faces().iter().all(|tri| {
        let [a, b, c] = tri.map(|vertex| mesh.uv_coords()[vertex.uv.unwrap()]);
        (b - a).perp_dot(c - a) >= 0.
    })
}

fn refine_winding<T>(
    mut tol: f64,
    tessellate: impl Fn(f64) -> T,
    consistent: impl Fn(&mut T, f64) -> bool,
) -> T {
    // Refine folded triangles with shared samples on adjacent faces.
    let mut result = tessellate(tol);
    for _ in 0..7 {
        if consistent(&mut result, tol) {
            return result;
        }
        tol /= 2.;
        result = tessellate(tol);
    }
    consistent(&mut result, tol);
    result
}

fn shell_create_polygon<S: PreMeshableSurface>(
    surface: &S,
    wires: Vec<Wire<Point3, PolylineCurve>>,
    orientation: bool,
    tol: f64,
    sp: impl SP<S>,
) -> Face<Point3, PolylineCurve, Option<PolygonMesh>> {
    let preboundary = wires
        .iter()
        .map(|wire: &Wire<_, _>| {
            let wire_iter = wire.iter().map(Edge::oriented_curve);
            PolyBoundaryPiece::try_new(surface, wire_iter, &sp)
        })
        .collect::<Option<Vec<_>>>();
    let polygon: Option<PolygonMesh> = preboundary.and_then(|preboundary| {
        let boundary = PolyBoundary::new(preboundary, &surface, tol)?;
        Some(trimming_tessellation(surface, &boundary, tol))
    });
    let mut new_face = Face::debug_new(wires, polygon);
    if !orientation {
        new_face.invert();
    }
    new_face
}

#[derive(Clone, Copy, Debug, derive_more::Deref, derive_more::DerefMut)]
struct SurfacePoint {
    point: Point3,
    #[deref]
    #[deref_mut]
    uv: Point2,
}

impl From<(Point2, Point3)> for SurfacePoint {
    fn from((uv, point): (Point2, Point3)) -> Self { Self { point, uv } }
}

#[derive(Debug, Default, Clone)]
struct PolyBoundaryPiece(Vec<SurfacePoint>);

impl PolyBoundaryPiece {
    fn is_collapsed(&self) -> bool {
        let Some((first, last)) = self.0.first().zip(self.0.last()) else {
            return true;
        };
        first.uv.distance(last.uv) < 1.0e-3 && loop_orientation(&self.0).is_none()
    }

    fn try_new<S: PreMeshableSurface>(
        surface: &S,
        wire: impl Iterator<Item = PolylineCurve>,
        sp: impl SP<S>,
    ) -> Option<Self> {
        let (up, vp) = (surface.u_period(), surface.v_period());
        let (urange, vrange) = surface.try_range_tuple();
        let mut bdry3d: Vec<Point3> = wire
            .flat_map(|poly_edge| {
                let n = poly_edge.len() - 1;
                poly_edge.into_iter().take(n)
            })
            .collect();
        bdry3d.push(bdry3d[0]);
        let mut previous =
            algo::surface::boundary_search_hint(surface, bdry3d.iter().copied(), &sp);
        let mut vec = bdry3d
            .into_iter()
            .flat_map(|pt| {
                // A pole has no unique parameter along its collapsed direction.
                // Reusing that hint can jump into an extension of the trimmed surface.
                let hint = previous.filter(|&(u, v)| {
                    !surface.uder(u, v).so_small() && !surface.vder(u, v).so_small()
                });
                let (mut u, mut v) = match sp(surface, pt, hint) {
                    Some(hint) => hint,
                    None => return vec![None],
                };
                if let (Some(up), Some((u0, _))) = (up, previous) {
                    u = get_mindiff(u, u0, up);
                }
                if let (Some(vp), Some((_, v0))) = (vp, previous) {
                    v = get_mindiff(v, v0, vp);
                }
                let res = (|| {
                    if let Some((u0, v0)) = previous {
                        if !u0.near(&u) && surface.uder(u0, v0).so_small() {
                            return vec![
                                Some((Point2::new(u, v0), surface.subs(u, v0)).into()),
                                Some((Point2::new(u, v), pt).into()),
                            ];
                        } else if !v0.near(&v) && surface.vder(u0, v0).so_small() {
                            return vec![
                                Some((Point2::new(u0, v), surface.subs(u0, v)).into()),
                                Some((Point2::new(u, v), pt).into()),
                            ];
                        }
                    }
                    vec![Some((Point2::new(u, v), pt).into())]
                })();
                previous = Some((u, v));
                res
            })
            .collect::<Option<Vec<SurfacePoint>>>()?;
        for (axis, period) in [(0, up), (1, vp)] {
            let Some(period) = period else { continue };
            let delta = vec.last()?.uv[axis] - vec.first()?.uv[axis];
            let shift = (delta / period).round() * period;
            if shift == 0. || !delta.near(&shift) {
                continue;
            }
            let collapsed = |p: &SurfacePoint| {
                if axis == 0 {
                    surface.uder(p.x, p.y)
                } else {
                    surface.vder(p.x, p.y)
                }
                .so_small()
            };
            let mut bridges = vec.windows(2).enumerate().filter_map(|(i, points)| {
                let [a, b] = [points[0], points[1]];
                (a.point.near(&b.point)
                    && !a.uv[axis].near(&b.uv[axis])
                    && a.uv[1 - axis].near(&b.uv[1 - axis])
                    && collapsed(&a)
                    && collapsed(&b))
                .then_some(i + 1)
            });
            if let (Some(index), None) = (bridges.next(), bridges.next()) {
                // Close a single polar bridge using the loop's winding. The shortest
                // angular jump would replace a 270-degree sector by its 90-degree complement.
                for point in &mut vec[index..] {
                    point.uv[axis] -= shift;
                }
            }
        }
        let grav = vec.iter().fold(Point2::origin(), |g, p| g + p.uv.to_vec()) / vec.len() as f64;
        if let (Some(up), Some((u0, _))) = (up, urange) {
            let quot = f64::floor((grav.x - u0) / up);
            vec.iter_mut().for_each(|p| p.x -= quot * up);
        }
        if let (Some(vp), Some((v0, _))) = (vp, vrange) {
            let quot = f64::floor((grav.y - v0) / vp);
            vec.iter_mut().for_each(|p| p.y -= quot * vp);
        }
        let last = *vec.last().unwrap();
        if !vec[0].near(&last) {
            let Point2 { x: u0, y: v0 } = last.uv;
            if surface.uder(u0, v0).so_small() || surface.vder(u0, v0).so_small() {
                vec.push(vec[0]);
            }
        }
        Some(Self(vec))
    }
}

/// Gives every pole on a boundary — a run that stays at one spatial point while its parameter
/// moves, like the tip of a revolved cone — a vertex at each parameter division it crosses.
/// With the run's two ends alone, the triangles fanning into the pole are inverted in
/// parameter space relative to space, and no finer tolerance repairs that.
fn subdivide_poles(
    loops: Vec<Vec<SurfacePoint>>,
    surface: &impl PreMeshableSurface,
    tol: f64,
) -> Vec<Vec<SurfacePoint>> {
    let bounds: BoundingBox<Point2> = loops.iter().flatten().map(|p| p.uv).collect();
    let range = (
        (bounds.min()[0], bounds.max()[0]),
        (bounds.min()[1], bounds.max()[1]),
    );
    let mut division = None;
    let mut result = Vec::with_capacity(loops.len());
    for points in loops {
        let mut subdivided = Vec::with_capacity(points.len());
        for (a, b) in points.iter().circular_tuple_windows() {
            subdivided.push(*a);
            if !a.point.near(&b.point) {
                continue;
            }
            let axis = match (a.uv.x.near(&b.uv.x), a.uv.y.near(&b.uv.y)) {
                (true, false) => 1,
                (false, true) => 0,
                _ => continue,
            };
            let (udiv, vdiv) =
                division.get_or_insert_with(|| surface.parameter_division(range, tol));
            let (from, to) = (a.uv[axis], b.uv[axis]);
            let at = |t: f64| {
                let mut uv = a.uv;
                uv[axis] = t;
                uv
            };
            let stays = (1..4).all(|i| {
                let uv = at(from + (to - from) * i as f64 / 4.0);
                surface.subs(uv.x, uv.y).near(&a.point)
            });
            if !stays {
                continue;
            }
            let mut crossed: Vec<f64> = [&*udiv, &*vdiv][axis]
                .iter()
                .copied()
                .filter(|t| (t - from) * (t - to) < 0.0 && !t.near(&from) && !t.near(&to))
                .collect();
            crossed.sort_by(|s, t| (s - from).abs().total_cmp(&(t - from).abs()));
            subdivided.extend(crossed.into_iter().map(|t| SurfacePoint {
                point: a.point,
                uv: at(t),
            }));
        }
        result.push(subdivided);
    }
    result
}

fn abs_diff(previous: f64) -> impl Fn(&f64, &f64) -> std::cmp::Ordering {
    let f = move |x: &f64| f64::abs(x - previous);
    move |x: &f64, y: &f64| f(x).partial_cmp(&f(y)).unwrap()
}
fn get_mindiff(u: f64, u0: f64, up: f64) -> f64 {
    let closure = |i| u + i as f64 * up;
    (-2..=2).map(closure).min_by(abs_diff(u0)).unwrap()
}

#[derive(Debug, Default, Clone)]
struct PolyBoundary {
    loops: Vec<Vec<SurfacePoint>>,
    bounds: Vec<BoundingBox<Point2>>,
}

fn normalize_range(curve: &mut Vec<SurfacePoint>, compidx: usize, (u0, u1): (f64, f64)) {
    let p = curve[0];
    let q = curve[curve.len() - 1];
    let tmp = f64::min(p[compidx], q[compidx]) + TOLERANCE;
    let del = f64::floor((tmp - u0) / (u1 - u0)) * (u1 - u0);
    curve.iter_mut().for_each(|p| p[compidx] -= del);
    let Some(i) = curve
        .iter()
        .position(|p| (curve[0][compidx] - u1) * (p[compidx] - u1) < 0.0)
    else {
        return;
    };
    let mut curve1 = curve.split_off(i + 1);
    curve1.pop();
    curve1.insert(0, curve[i]);
    match curve[0][compidx] < curve[curve.len() - 1][compidx] {
        true => curve1.iter_mut(),
        false => curve.iter_mut(),
    }
    .for_each(|p| p[compidx] -= u1 - u0);
    curve1.append(curve);
    *curve = curve1;
}

fn loop_orientation(curve: &[SurfacePoint]) -> Option<bool> {
    let origin = curve.first()?.uv;
    let (area, scale) =
        curve
            .iter()
            .circular_tuple_windows()
            .fold((0.0, 0.0), |(area, scale), (p, q)| {
                let (p, q) = (p.uv - origin, q.uv - origin);
                let (a, b) = (p.x * q.y, p.y * q.x);
                (area + a - b, scale + a.abs() + b.abs())
            });
    let roundoff = f64::EPSILON * (curve.len() + 2) as f64 * scale;
    (area.abs() > roundoff).then_some(area > 0.0)
}

impl PolyBoundary {
    fn new(
        pieces: Vec<PolyBoundaryPiece>,
        surface: &impl PreMeshableSurface,
        tol: f64,
    ) -> Option<Self> {
        let (mut closed, mut open) = (Vec::new(), Vec::new());
        pieces.into_iter().for_each(|PolyBoundaryPiece(mut vec)| {
            match vec[0].uv.distance(vec[vec.len() - 1].uv) < 1.0e-3 {
                true => {
                    vec.pop();
                    closed.push(vec)
                }
                false => open.push(vec),
            }
        });
        fn connect_edges<P>(vecs: impl IntoIterator<Item = Vec<P>>) -> Vec<P> {
            let closure = |vec: Vec<P>| {
                let len = vec.len();
                vec.into_iter().take(len - 1)
            };
            vecs.into_iter().flat_map(closure).collect()
        }
        match open.len() {
            1 => {
                let mut curve = open.pop().unwrap();
                if let (Some(urange), Some(vrange)) = surface.try_range_tuple() {
                    let mut ranges = [urange, vrange];
                    let (p, q) = (curve[0], *curve.last()?);
                    let axis = usize::from((p.x - q.x).abs() <= TOLERANCE);
                    let delta = q.uv[axis] - p.uv[axis];
                    let forward = delta > 0.;
                    let pole = if (axis == 0) == forward {
                        ranges[1 - axis].1
                    } else {
                        ranges[1 - axis].0
                    };
                    let mut at_pole = p.uv;
                    at_pole[1 - axis] = pole;
                    let tangent = if axis == 0 {
                        surface.uder(at_pole.x, at_pole.y)
                    } else {
                        surface.vder(at_pole.x, at_pole.y)
                    };
                    let period = [surface.u_period(), surface.v_period()][axis];
                    let mut polar_seam = false;
                    if tangent.so_small() && period.is_some_and(|period| delta.abs().near(&period))
                    {
                        let index = curve.windows(3).position(|points| {
                            (points[1].uv[axis] - points[0].uv[axis]) * delta.signum() > TOLERANCE
                                && (points[2].uv[axis] - points[1].uv[axis]) * delta.signum()
                                    > TOLERANCE
                                && !points[0].point.near(&points[1].point)
                                && !points[1].point.near(&points[2].point)
                        });
                        if let Some(index) = index.map(|i| i + 1) {
                            // Cross the boundary away from existing meridians, whose shared
                            // samples must not be replaced by an artificial polar seam.
                            let mut prefix = curve[..=index].to_vec();
                            for point in &mut prefix {
                                point.uv[axis] += delta;
                            }
                            curve = curve[index..curve.len() - 1].to_vec();
                            curve.extend(prefix);
                            let (p, q) = (curve[0].uv[axis], curve.last()?.uv[axis]);
                            ranges[axis] = (p.min(q), p.max(q));
                            polar_seam = true;
                        }
                    }
                    normalize_range(&mut curve, axis, ranges[axis]);
                    let (p, q) = (curve[0], *curve.last()?);
                    let mut x = p.uv;
                    let mut y = q.uv;
                    x[axis] = if forward {
                        ranges[axis].0
                    } else {
                        ranges[axis].1
                    };
                    y[axis] = if forward {
                        ranges[axis].1
                    } else {
                        ranges[axis].0
                    };
                    x[1 - axis] = pole;
                    y[1 - axis] = pole;
                    let x = (x, surface.subs(x.x, x.y)).into();
                    let y = (y, surface.subs(y.x, y.y)).into();
                    let vec0 = polyline_on_surface(surface, q, y, tol);
                    let vec1 = polyline_on_surface(surface, y, x, tol);
                    let vec2 = if polar_seam {
                        // Both copies of a periodic seam need identical spatial samples.
                        vec0.iter()
                            .rev()
                            .map(|point| SurfacePoint {
                                uv: point.uv + (p.uv - q.uv),
                                point: point.point,
                            })
                            .collect()
                    } else {
                        polyline_on_surface(surface, x, p, tol)
                    };
                    closed.push(connect_edges([vec0, vec1, vec2, curve]));
                }
            }
            2 => {
                let mut curve1 = open.pop().unwrap();
                let mut curve0 = open.pop().unwrap();
                fn end_pts<T: Copy>(vec: &[T]) -> (T, T) { (vec[0], vec[vec.len() - 1]) }
                let ((p0, p1), (q0, q1)) = (end_pts(&curve0), end_pts(&curve1));
                if !p0.x.near(&p1.x) && !q0.x.near(&q1.x) {
                    if let (Some(urange), _) = surface.try_range_tuple() {
                        normalize_range(&mut curve0, 0, urange);
                        normalize_range(&mut curve1, 0, urange);
                    }
                } else if !p0.y.near(&p1.y) && !q0.y.near(&q1.y) {
                    if let (_, Some(vrange)) = surface.try_range_tuple() {
                        normalize_range(&mut curve0, 1, vrange);
                        normalize_range(&mut curve1, 1, vrange);
                    }
                }
                let ((p0, p1), (q0, q1)) = (end_pts(&curve0), end_pts(&curve1));
                let vec0 = polyline_on_surface(surface, p1, q0, tol);
                let vec1 = polyline_on_surface(surface, q1, p0, tol);
                closed.push(connect_edges([curve0, vec0, curve1, vec1]));
            }
            _ => {}
        }
        // A collapsed trim needs finer shared edges, not the full surface domain.
        let has_outer = closed.iter().try_fold(false, |has_outer, curve| {
            Some(loop_orientation(curve)? || has_outer)
        })?;
        if !has_outer {
            if surface.u_period().is_none() && surface.v_period().is_none() {
                return None;
            }
            if let (Some((u0, u1)), Some((v0, v1))) = surface.try_range_tuple() {
                let p = [
                    (Point2::new(u0, v0), surface.subs(u0, v0)).into(),
                    (Point2::new(u1, v0), surface.subs(u1, v0)).into(),
                    (Point2::new(u1, v1), surface.subs(u1, v1)).into(),
                    (Point2::new(u0, v1), surface.subs(u0, v1)).into(),
                ];
                let vec0 = polyline_on_surface(surface, p[0], p[1], tol);
                let vec1 = polyline_on_surface(surface, p[1], p[2], tol);
                let vec2 = polyline_on_surface(surface, p[2], p[3], tol);
                let vec3 = polyline_on_surface(surface, p[3], p[0], tol);
                closed.push(connect_edges([vec0, vec1, vec2, vec3]));
            }
        }
        Some(Self::from_loops(subdivide_poles(closed, surface, tol)))
    }

    fn from_loops(loops: Vec<Vec<SurfacePoint>>) -> Self {
        let padding = Vector2::new(TOLERANCE, TOLERANCE);
        let bounds = loops
            .iter()
            .map(|points| {
                let bounds: BoundingBox<Point2> = points.iter().map(|p| p.uv).collect();
                // A nearby edge must still run the tolerance-sensitive boundary test.
                BoundingBox::from_iter([bounds.min() - padding, bounds.max() + padding])
            })
            .collect();
        Self { loops, bounds }
    }

    /// whether `c` is included in the domain with boundary = `self`.
    fn include(&self, c: Point2) -> bool { self.include_with_tolerance(c, TOLERANCE) }

    fn include_with_tolerance(&self, c: Point2, tolerance: f64) -> bool {
        let t = 2.0 * std::f64::consts::PI * HashGen::hash1(c);
        let r = Vector2::new(f64::cos(t), f64::sin(t));
        self.loops
            .iter()
            .zip(&self.bounds)
            // A closed loop has zero winding outside its bounding box.
            .filter(|(_, bounds)| bounds.contains(c))
            .flat_map(|(vec, _)| vec.iter().circular_tuple_windows())
            .try_fold(0_i32, move |counter, (p0, p1)| {
                let a = **p0 - c;
                let b = **p1 - c;
                let s0 = r.x * a.y - r.y * a.x; // v times a
                let s1 = r.x * b.y - r.y * b.x; // v times b
                let s2 = a.x * b.y - a.y * b.x; // a times b
                let x = s2 / (s1 - s0);
                if x.abs() <= tolerance && s0 * s1 < 0.0 {
                    None
                } else if x > 0.0 && s0 <= 0.0 && s1 > 0.0 {
                    Some(counter + 1)
                } else if x > 0.0 && s0 >= 0.0 && s1 < 0.0 {
                    Some(counter - 1)
                } else {
                    Some(counter)
                }
            })
            .map(|counter| counter > 0)
            .unwrap_or(false)
    }

    /// Inserts points and adds constraint into triangulation.
    fn insert_to(
        &self,
        triangulation: &mut Cdt,
        boundary_map: &mut HashMap<FixedVertexHandle, Point3>,
        metric: &MeshMetric,
    ) {
        let poly2tri: Vec<_> = self
            .loops
            .iter()
            .flatten()
            .map(|pt| {
                let p = [spade_round(pt.x), spade_round(pt.y)];
                match triangulation.insert(metric.vertex(p[0], p[1])) {
                    Err(_) => None,
                    Ok(idx) => {
                        boundary_map.insert(idx, pt.point);
                        Some(idx)
                    }
                }
            })
            .collect();
        let mut prev: Option<usize> = None;
        let mut counter = 0;
        self.loops
            .iter()
            .map(Vec::len)
            .flat_map(|len| {
                let range = counter..counter + len;
                counter += len;
                range.circular_tuple_windows()
            })
            .for_each(|(i, j)| {
                let Some(vj) = poly2tri[j] else { return };
                if let Some(p) = prev {
                    let Some(v) = poly2tri[p] else { return };
                    if triangulation.can_add_constraint(v, vj) {
                        triangulation.add_constraint(v, vj);
                        prev = None;
                    }
                } else {
                    let Some(vi) = poly2tri[i] else { return };
                    if triangulation.can_add_constraint(vi, vj) {
                        triangulation.add_constraint(vi, vj);
                    } else {
                        prev = Some(i);
                    }
                }
            });
    }
}

fn spade_round(x: f64) -> f64 {
    match f64::abs(x) < MIN_ALLOWED_VALUE {
        true => 0.0,
        false => x,
    }
}

/// Tessellates one surface trimmed by polyline.
fn trimming_tessellation<S>(surface: &S, polyboundary: &PolyBoundary, tol: f64) -> PolygonMesh
where S: PreMeshableSurface {
    let mut triangulation = Cdt::new();
    let mut boundary_map = HashMap::<FixedVertexHandle, Point3>::default();
    let bounds: BoundingBox<Point2> = polyboundary.loops.iter().flatten().map(|p| p.uv).collect();
    let mut divisions = surface.parameter_division(
        (
            (bounds.min().x, bounds.max().x),
            (bounds.min().y, bounds.max().y),
        ),
        tol,
    );
    let (udiv, vdiv) = (&divisions.0, &divisions.1);
    let single_direction =
        (udiv.len() > 2 && vdiv.len() == 2) || (udiv.len() == 2 && vdiv.len() > 2);
    // Oblique trims can discard the curved grid's end rulings. Seed an interior one.
    let trimmed_grid = single_direction
        && polyboundary.loops.iter().any(|boundary| {
            boundary.iter().circular_tuple_windows().any(|(a, b)| {
                let delta = b.uv - a.uv;
                delta.x.abs() > TOLERANCE && delta.y.abs() > TOLERANCE
            })
        });
    if trimmed_grid && udiv.len() > 2 {
        divisions.1.insert(1, (vdiv[0] + vdiv[1]) / 2.);
    } else if trimmed_grid {
        divisions.0.insert(1, (udiv[0] + udiv[1]) / 2.);
    }
    // Trims on a grid curved in only one direction still need free refinement.
    // Balance those triangles in physical space to avoid repeated UV slivers.
    let metric = MeshMetric::new(surface, bounds, single_direction);
    polyboundary.insert_to(&mut triangulation, &mut boundary_map, &metric);
    insert_surface(
        &mut triangulation,
        surface,
        polyboundary,
        tol,
        &metric,
        divisions,
    );
    if single_direction {
        refine_interior(
            &mut triangulation,
            surface,
            polyboundary,
            tol,
            &metric,
            &boundary_map,
        );
    }
    let mut mesh = triangulation_into_polymesh(
        triangulation.vertices(),
        triangulation.inner_faces(),
        surface,
        polyboundary,
        &boundary_map,
    );
    orient_to_normals(&mut mesh);
    mesh
}

/// A grid subdivided in only one direction can lose whole rulings to trimming,
/// leaving long diagonals across curved patches.
/// Refine those diagonals while preserving the shared, already sampled boundary edges.
fn refine_interior(
    triangulation: &mut Cdt,
    surface: &impl PreMeshableSurface,
    boundary: &PolyBoundary,
    tol: f64,
    metric: &MeshMetric,
    boundary_map: &HashMap<FixedVertexHandle, Point3>,
) {
    for _ in 0..20 {
        let mut positions = vec![Point3::origin(); triangulation.num_vertices()];
        for vertex in triangulation.vertices() {
            let uv = vertex.as_ref().uv;
            positions[vertex.index()] = boundary_map
                .get(&vertex.fix())
                .copied()
                .unwrap_or_else(|| surface.subs(uv.x, uv.y));
        }
        let points: Vec<_> = triangulation
            .undirected_edges()
            .filter(|edge| {
                !edge.is_constraint_edge() && !edge.as_directed().is_part_of_convex_hull()
            })
            .filter_map(|edge| {
                let [a, b] = edge.vertices().map(|v| v.as_ref().uv);
                let uv = Point2::new((a.x + b.x) / 2.0, (a.y + b.y) / 2.0);
                let point = surface.subs(uv.x, uv.y);
                let directed = edge.as_directed();
                // Parameter speed can vary even on a plane (e.g. polar caps).
                // Measure departure from the adjacent facets, not the chord midpoint.
                let curved = [directed, directed.rev()].into_iter().any(|edge| {
                    let Some(face) = edge.face().as_inner() else {
                        return false;
                    };
                    let [p, q, r] = face.vertices().map(|v| positions[v.index()]);
                    // A facet collapsed by shared-vertex welding has no reliable plane.
                    if p.near(&q) || q.near(&r) || r.near(&p) {
                        return false;
                    }
                    let normal = (q - p).cross(r - p);
                    let distance = (point - p).dot(normal);
                    distance * distance > tol * tol * normal.magnitude2()
                });
                (curved && boundary.include(uv)).then_some(metric.vertex(uv.x, uv.y))
            })
            .collect();
        if points.is_empty() {
            break;
        }
        let previous_len = triangulation.num_vertices();
        for point in points {
            let _ = triangulation.insert(point);
        }
        if triangulation.num_vertices() == previous_len {
            break;
        }
    }
}

/// Inserts the surface parameter grid.
fn insert_surface(
    triangulation: &mut Cdt,
    surface: impl PreMeshableSurface,
    polyline: &PolyBoundary,
    tol: f64,
    metric: &MeshMetric,
    (udiv, vdiv): (Vec<f64>, Vec<f64>),
) {
    let crosses_boundary_chord = |uv: Point2| {
        let point = surface.subs(uv.x, uv.y);
        polyline.loops.iter().any(|boundary| {
            boundary.iter().circular_tuple_windows().any(|(a, b)| {
                let axis = b.point - a.point;
                let parameter = ((point - a.point).dot(axis) / axis.magnitude2()).clamp(0., 1.);
                if point.distance2(a.point + parameter * axis) >= tol * tol {
                    return false;
                }
                let side_uv = (b.uv - a.uv).perp_dot(uv - a.uv);
                let side_space = axis.cross(point - a.point).dot(surface.normal(uv.x, uv.y));
                side_uv * side_space < 0.
            })
        })
    };
    let insert_res: Vec<Vec<Option<_>>> = udiv
        .into_iter()
        .map(|u| {
            vdiv.iter()
                // Near a trim chord, a valid UV point can map across the spatial chord.
                // Excluding these points prevents inverted slivers without changing shared edges.
                .map(|v| {
                    match polyline.include(Point2::new(u, *v))
                        && !crosses_boundary_chord(Point2::new(u, *v))
                    {
                        true => triangulation.insert(metric.vertex(u, *v)).ok(),
                        false => None,
                    }
                })
                .collect()
        })
        .collect();
    insert_res.windows(2).for_each(|vec| {
        vec[0].windows(2).zip(&vec[1]).for_each(|(a, z)| {
            if let Some(x) = a[0] {
                if let Some(y) = a[1] {
                    if triangulation.can_add_constraint(x, y) {
                        triangulation.add_constraint(x, y);
                    }
                }
                if let Some(z) = z {
                    if triangulation.can_add_constraint(x, *z) {
                        triangulation.add_constraint(x, *z);
                    }
                }
            }
        });
        let idx = vec[0].len() - 1;
        if let (Some(x), Some(y)) = (vec[0][idx], vec[1][idx]) {
            if triangulation.can_add_constraint(x, y) {
                triangulation.add_constraint(x, y);
            }
        }
    });
}

/// Turns each triangle to face the way the surface normals at its corners point. A triangle
/// without area, or perpendicular to the corner normals, has an uncertain orientation
/// from rounding noise. Keep the parameter-space winding in those cases.
fn orient_to_normals(mesh: &mut PolygonMesh) {
    let mut editor = mesh.debug_editor();
    let PolygonMeshEditor {
        attributes: StandardAttributes {
            positions, normals, ..
        },
        faces,
        ..
    } = &mut editor;
    for face in faces.face_iter_mut() {
        let corners: Vec<Point3> = face.iter().map(|v| positions[v.pos]).collect();
        let area = (corners[1] - corners[0]).cross(corners[2] - corners[0]);
        let longest = corners
            .iter()
            .circular_tuple_windows()
            .map(|(a, b)| a.distance(*b))
            .fold(0.0, f64::max);
        if area.magnitude() <= TOLERANCE * longest {
            continue;
        }
        let normal = face.iter().fold(Vector3::zero(), |normal, v| {
            normal + v.nor.map(|i| normals[i]).unwrap_or_else(Vector3::zero)
        });
        if normal.dot(area) < -TOLERANCE * normal.magnitude() * area.magnitude() {
            face.reverse();
        }
    }
}

/// Converts triangulation into `PolygonMesh`.
fn triangulation_into_polymesh<'a>(
    vertices: VertexIterator<'a, MeshVertex, (), CdtEdge<()>, ()>,
    triangles: InnerFaceIterator<'a, MeshVertex, (), CdtEdge<()>, ()>,
    surface: &impl ParametricSurface3D,
    polyline: &PolyBoundary,
    boundary_map: &HashMap<FixedVertexHandle, Point3>,
) -> PolygonMesh {
    let mut positions = Vec::<Point3>::new();
    let mut uv_coords = Vec::<Vector2>::new();
    let mut normals = Vec::<Vector3>::new();
    let vmap: HashMap<_, _> = vertices
        .enumerate()
        .map(|(i, v)| {
            let p = v.as_ref().uv;
            let idx = v.fix();
            let point = match boundary_map.get(&idx) {
                Some(point) => *point,
                None => surface.subs(p.x, p.y),
            };
            positions.push(point);
            uv_coords.push(Vector2::new(p.x, p.y));
            normals.push(surface.normal(p.x, p.y));
            (idx, i)
        })
        .collect();
    let tri_faces: Vec<[StandardVertex; 3]> = triangles
        .map(|tri| tri.vertices())
        .filter(|tri| {
            fn sp2cg(p: SPoint2) -> Point2 { Point2::new(p.x, p.y) }
            let tri = array![i => sp2cg(tri[i].as_ref().uv); 3];
            let (a, b) = (tri[1] - tri[0], tri[2] - tri[0]);
            let c = tri[0] + (a + b) / 3.0;
            let area = a.x * b.y - a.y * b.x;
            let scale = tri
                .iter()
                .flat_map(|p| [p.x.abs(), p.y.abs()])
                .fold(0.0, f64::max);
            // Scale the parameter-search error into area units to remove seam slivers
            // without imposing an absolute minimum size on valid triangles.
            let roundoff = TOLERANCE2 * scale * (a.magnitude() + b.magnitude());
            // Constraints already separate inside from outside. A tolerance band here
            // deletes valid triangles on narrow faces, including entire small faces.
            polyline.include_with_tolerance(c, 0.0) && area > roundoff
        })
        .map(|tri| {
            let idcs = array![i => vmap[&tri[i].fix()]; 3];
            array![i => [idcs[i], idcs[i], idcs[i]].into(); 3]
        })
        .collect();
    PolygonMesh::debug_new(
        StandardAttributes {
            positions,
            uv_coords,
            normals,
        },
        Faces::from_tri_and_quad_faces(tri_faces, Vec::new()),
    )
}

fn polyline_on_surface(
    surface: impl PreMeshableSurface,
    p: SurfacePoint,
    q: SurfacePoint,
    tol: f64,
) -> Vec<SurfacePoint> {
    use truck_geometry::prelude::*;
    let line = Line(p.uv, q.uv);
    let pcurve = PCurve::new(line, &surface);
    let (vec, _) = pcurve.parameter_division(pcurve.range_tuple(), tol);
    let mut points: Vec<_> = vec
        .into_iter()
        .map(|t| {
            let uv = line.subs(t);
            (uv, surface.subs(uv.x, uv.y)).into()
        })
        .collect();
    // Fitted trim points can differ from their surface projection; keep their shared positions.
    if let Some(first) = points.first_mut() {
        *first = p;
    }
    if let Some(last) = points.last_mut() {
        *last = q;
    }
    points
}

#[test]
#[ignore]
#[cfg(not(target_arch = "wasm32"))]
fn par_bench() {
    use std::time::Instant;
    use truck_modeling::*;
    const JSON: &str = include_str!(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/../resources/shape/bottle.json"
    ));
    let solid: Solid = serde_json::from_str(JSON).unwrap();
    let shell = solid.into_boundaries().pop().unwrap();

    let instant = Instant::now();
    (0..100).for_each(|_| {
        let _shell = shell_tessellation(&shell, 0.01, by_search_parameter);
    });
    println!("{}ms", instant.elapsed().as_millis());

    let instant = Instant::now();
    (0..100).for_each(|_| {
        let _shell = shell_tessellation_single_thread(&shell, 0.01, by_search_parameter);
    });
    println!("{}ms", instant.elapsed().as_millis());
}

#[cfg(test)]
mod tests;
