pload ALL
pload -BlendAudit BLENDAUDIT
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
restore "/home/krone/Development/Pieza_WS/truck/target/native-cylindrical-terminal-fan/input.brep" bundle0
explode bundle0
audit_blend_output before0 bundle0_1
catch {chamf result0 bundle0_1 bundle0_2 .7} error0
audit_blend_output after0 bundle0_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-cylindrical-terminal-fan/input.brep" bundle1
explode bundle1
audit_blend_output before1 bundle1_1
catch {chamf result1 bundle1_1 bundle1_2 .7 bundle1_4 .7} error1
audit_blend_output after1 bundle1_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-cylindrical-terminal-fan/input.brep" bundle2
explode bundle2
audit_blend_output before2 bundle2_1
catch {chamf result2 bundle2_1 bundle2_2 bundle2_3 .7 .5} error2
audit_blend_output after2 bundle2_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-cylindrical-terminal-fan/input.brep" bundle3
explode bundle3
audit_blend_output before3 bundle3_1
catch {chamf result3 bundle3_1 bundle3_2 bundle3_3 .7 .5 bundle3_4 bundle3_3 .7 .5} error3
audit_blend_output after3 bundle3_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-cylindrical-terminal-fan/input.brep" bundle4
explode bundle4
audit_blend_output before4 bundle4_1
catch {chamf result4 bundle4_1 bundle4_2 bundle4_3 A .7 30} error4
audit_blend_output after4 bundle4_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-cylindrical-terminal-fan/input.brep" bundle5
explode bundle5
audit_blend_output before5 bundle5_1
catch {chamf result5 bundle5_1 bundle5_2 bundle5_3 A .7 30 bundle5_4 bundle5_3 A .7 30} error5
audit_blend_output after5 bundle5_1
exit
