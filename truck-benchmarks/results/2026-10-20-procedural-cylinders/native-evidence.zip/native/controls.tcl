pload ALL
pload -BlendAudit BLENDAUDIT
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
restore "/home/krone/Development/Pieza_WS/truck/target/native-procedural-cylinders/size70-radius1.brep" bundle0
explode bundle0
audit_blend_output before0 bundle0_1
catch {blend result0 bundle0_1 1.0 bundle0_2} error0
audit_blend_output after0 bundle0_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-procedural-cylinders/size12-radius0.5.brep" bundle1
explode bundle1
audit_blend_output before1 bundle1_1
catch {blend result1 bundle1_1 0.5 bundle1_2} error1
audit_blend_output after1 bundle1_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-procedural-cylinders/size12-radius1.brep" bundle2
explode bundle2
audit_blend_output before2 bundle2_1
catch {blend result2 bundle2_1 1.0 bundle2_2} error2
audit_blend_output after2 bundle2_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-procedural-cylinders/size12-radius2.brep" bundle3
explode bundle3
audit_blend_output before3 bundle3_1
catch {blend result3 bundle3_1 2.0 bundle3_2} error3
audit_blend_output after3 bundle3_1
exit
