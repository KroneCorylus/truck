from pathlib import Path
import subprocess,os,json,hashlib,re
out=Path('truck-benchmarks/results/2026-10-20-procedural-cylinders');env=dict(os.environ,CARGO_BUILD_JOBS='12');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
parent=json.loads((out/'parent.json').read_text())
for p,h in parent['sha256'].items():
 if '/tests/' in p or p.endswith('/tests.rs'):assert sha(p)==h,p
assert '1 passed; 1 failed' in (out/'parent-modeling.txt').read_text()
assert '6 passed; 2 failed' in (out/'parent-shapeops.txt').read_text()
source={str(p):sha(p) for base in ['truck-shapeops/src','truck-shapeops/tests','truck-shapeops/examples','truck-meshalgo/src','truck-meshalgo/tests','truck-geometry/src','truck-geometry/tests','truck-modeling/src','truck-modeling/tests'] for p in Path(base).rglob('*.rs')}
source['truck-shapeops/tests/R10-first-fillet-solid.json']=sha('truck-shapeops/tests/R10-first-fillet-solid.json')
m=dict(parent_revision=parent['revision'],source_sha256=source)
(out/'validation-start.json').write_text(json.dumps(m,indent=2)+'\n')
for name,cmd in [
 ('geometry-tests.txt',['cargo','test','--release','-p','truck-geometry','--no-fail-fast']),
 ('modeling-tests.txt',['cargo','test','--release','-p','truck-modeling']),
 ('meshalgo-tests.txt',['cargo','test','--release','-p','truck-meshalgo']),
 ('stepio-tests.txt',['cargo','test','--release','-p','truck-stepio']),
 ('shapeops-tests.txt',['cargo','test','--release','-p','truck-shapeops']),
 ('replay-tests.txt',['cargo','test','--release','-p','truck-shapeops','--example','replay_occt_blend']),
 ('capture-tests.txt',['python3','-m','unittest','discover','-s','audits/fillet-chamfer/capture','-p','test_*.py']),
 ('clippy.txt',['cargo','clippy','--release','-p','truck-geometry','-p','truck-modeling','-p','truck-meshalgo','-p','truck-stepio','-p','truck-shapeops','-p','truck-benchmarks','--all-targets']),
 ('actions-smoke.txt',['cargo','bench','-p','truck-benchmarks','--bench','actions','--','--test']),
 ('replay-build.txt',['cargo','build','--release','-p','truck-shapeops','--example','replay_occt_blend'])]:
 with (out/name).open('w') as log:
  log.write('$ '+' '.join(cmd)+'\n');log.flush();r=subprocess.run(cmd,env=dict(env,RAYON_NUM_THREADS='1') if name=='actions-smoke.txt' else env,stdout=log,stderr=subprocess.STDOUT);log.write(f'exit_code {r.returncode}\n')
 if name=='geometry-tests.txt':
  text=(out/name).read_text();assert r.returncode==101 and text.count('test result: FAILED.')==1 and '0 passed; 1 failed' in text
  for value in ['pcurve_derivation','-2829663063.761872','-2829663063.7618704']:assert value in text
  m['baseline_failure']=dict(test='pcurve_derivation',parent_evidence='parent-pcurve-baseline.txt',left=-2829663063.761872,right=-2829663063.7618704,unchanged=True)
 else:assert r.returncode==0,name
 print(name,'known parent failure retained' if name=='geometry-tests.txt' else 'passed',flush=True)
for p,h in source.items():assert sha(p)==h,p
counts=[tuple(map(int,c)) for c in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',(out/'shapeops-tests.txt').read_text())];m['shapeops_counts']=list(map(sum,zip(*counts)))
assert m['shapeops_counts']==[435,0,1],m['shapeops_counts']
for name in ['geometry','modeling','meshalgo','stepio']:
 counts=[tuple(map(int,c)) for c in re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored',(out/f'{name}-tests.txt').read_text())]
 m[name+'_counts']=list(map(sum,zip(*counts)));assert m[name+'_counts'][1]==(1 if name=='geometry' else 0)
m.update(replay_tests=59,replay_sha256=sha('target/release/examples/replay_occt_blend'))
assert '59 passed; 0 failed' in (out/'replay-tests.txt').read_text()
for p in out.glob('*.txt'):p.write_text('\n'.join(line.rstrip() for line in p.read_text().splitlines()).rstrip()+'\n')
m['log_sha256']={p.name:sha(p) for p in out.glob('*.txt')}
(out/'validation.json').write_text(json.dumps(m,indent=2)+'\n')
print('Validation complete',{k:v for k,v in m.items() if k.endswith('_counts')},flush=True)
