#![cfg(feature = "step-test")]
#[path="/home/krone/Development/Pieza_WS/truck/truck-shapeops/tests/common/mod.rs"] mod common;
use std::collections::HashSet;
use truck_modeling::*;
use truck_shapeops::{fillet::*, SplitClosedEdgesAndFaces};
use truck_stepio::r#in::Table;

fn check(matrix: Matrix4) {
    let table = Table::from_step(include_str!(
        "/home/krone/Development/Pieza_WS/truck/truck-shapeops/tests/fixtures/adaptive-chamfer-contacts/001.input.step"
    ))
    .unwrap();
    let entity = table.manifold_solid_brep.values().next().unwrap();
    let (mut compressed, skipped) = table.to_compressed_solid(entity).unwrap();
    assert!(skipped.is_empty());
    compressed.split_closed_edges_and_faces(1e-5);
    let compressed = compressed
        .try_mapped(
            |p| Some(*p),
            |c| Curve::try_from(c).ok(),
            |s| Surface::try_from(s).ok(),
        )
        .unwrap();
    let solid = builder::transformed(&Solid::extract(compressed).unwrap(), matrix);
    let task: serde_json::Value = serde_json::from_str(include_str!(
        "/home/krone/Development/Pieza_WS/truck/truck-shapeops/tests/fixtures/adaptive-chamfer-contacts/001.input.json"
    ))
    .unwrap();
    let points = task["selection"][0]["points"].as_array().unwrap();
    let point = |p: &serde_json::Value| {
        matrix.transform_point(Point3::new(
            p[0].as_f64().unwrap(),
            p[1].as_f64().unwrap(),
            p[2].as_f64().unwrap(),
        ))
    };
    let (a, b) = (point(&points[0]), point(points.last().unwrap()));
    let mut seen = HashSet::new();
    let selected: Vec<_> = solid
        .edge_iter()
        .filter(|e| seen.insert(e.id()))
        .filter_map(|e| {
            if e.front().point().near(&a) && e.back().point().near(&b) {
                Some(e.clone())
            } else if e.front().point().near(&b) && e.back().point().near(&a) {
                Some(e.inverse())
            } else {
                None
            }
        })
        .collect();
    assert_eq!(selected.len(), 1);
    let before = serde_json::to_string(&solid.compress()).unwrap();
    for edge in [selected[0].clone(), selected[0].inverse()] {
        let wire: Wire = vec![edge].into();
        let result = try_chamfer_solid_along_wire_chord(&solid, &wire, 0.01, 0.01, 0.001)
            .expect("curved-cap contacts retain their boundary trims");
        assert!(result.solid.is_geometric_consistent());
        assert_eq!(result.generated_faces.len(), 1);
        assert_eq!(
            result.solid.face_iter().count(),
            solid.face_iter().count() + 1
        );
        for input in solid.face_iter() {
            let replacement: Vec<_> = result
                .modified_faces
                .iter()
                .filter(|(id, _)| *id == input.id())
                .collect();
            assert!(replacement.len() <= 1);
            let face = replacement.first().map_or(input, |(_, face)| face);
            assert!(result.solid.face_iter().any(|f| f.id() == face.id()));
        }
        use truck_stepio::out::*;
        let prepared=prepare_for_step(&result.solid.compress(),1e-7).unwrap();
        let step=StepDisplay::new(Default::default(),StepDesign::from_model(StepModel::from(&prepared))).to_string();
        std::fs::write("target/normal-section-c1.step",step).unwrap();
        assert_eq!(before, serde_json::to_string(&solid.compress()).unwrap());
    }
}

#[test]
fn curved_cap_chamfers_retain_trimmed_contacts_and_material() { check(Matrix4::identity()); }

#[test]
fn transformed_curved_cap_chamfers_retain_trimmed_contacts_and_material() {
    check(
        Matrix4::from_translation(Vector3::new(0.3, -0.2, 0.1))
            * Matrix4::from_axis_angle(Vector3::new(1., 2., 3.).normalize(), Rad(0.7)),
    );
}
