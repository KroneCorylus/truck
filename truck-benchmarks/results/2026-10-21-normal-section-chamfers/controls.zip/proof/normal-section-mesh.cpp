#include "shape_tolerances.hpp"
#include <BRepMesh_IncrementalMesh.hxx>
#include <BRep_Tool.hxx>
#include <Poly_Triangulation.hxx>
#include <array>
#include <vector>
#include "shape_volume.hpp"
#include <BRepAdaptor_Curve.hxx>
#include <BRepAdaptor_Surface.hxx>
#include <BRepBuilderAPI_MakeVertex.hxx>
#include <BRepCheck_Analyzer.hxx>
#include <BRepClass_FaceClassifier.hxx>
#include <BRepExtrema_DistShapeShape.hxx>
#include <BRepGProp.hxx>
#include <BRepTools.hxx>
#include <BRep_Builder.hxx>
#include <GProp_GProps.hxx>
#include <STEPControl_Reader.hxx>
#include <TopExp_Explorer.hxx>
#include <TopoDS.hxx>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>

namespace {
double triangle_distance(const gp_XYZ& p,const std::array<gp_XYZ,3>& t){
 const auto a=t[0],b=t[1],c=t[2],ab=b-a,ac=c-a,ap=p-a;
 const double d1=ab.Dot(ap),d2=ac.Dot(ap);
 if(d1<=0&&d2<=0)return ap.SquareModulus();
 const auto bp=p-b; const double d3=ab.Dot(bp),d4=ac.Dot(bp);
 if(d3>=0&&d4<=d3)return bp.SquareModulus();
 const double vc=d1*d4-d3*d2;
 if(vc<=0&&d1>=0&&d3<=0)return (p-(a+ab*(d1/(d1-d3)))).SquareModulus();
 const auto cp=p-c;const double d5=ab.Dot(cp),d6=ac.Dot(cp);
 if(d6>=0&&d5<=d6)return cp.SquareModulus();
 const double vb=d5*d2-d1*d6;
 if(vb<=0&&d2>=0&&d6<=0)return (p-(a+ac*(d2/(d2-d6)))).SquareModulus();
 const double va=d3*d6-d5*d4;
 if(va<=0&&(d4-d3)>=0&&(d5-d6)>=0)return (p-(b+(c-b)*((d4-d3)/((d4-d3)+(d5-d6))))).SquareModulus();
 const double inv=1/(va+vb+vc);
 return (p-(a+ab*(vb*inv)+ac*(vc*inv))).SquareModulus();
}

struct Residual {
  double maximum = 0.;
  int samples = 0;
};

Residual distance(const TopoDS_Shape& source, const TopoDS_Shape& target) {
  Residual result; double local=0.; int faceindex=0;
  BRepMesh_IncrementalMesh mesh(target,1e-5,false,.05,false);
  std::vector<std::array<gp_XYZ,3>> triangles;
  for(TopExp_Explorer it(target,TopAbs_FACE);it.More();it.Next()){
   const auto f=TopoDS::Face(it.Current());TopLoc_Location location;auto tri=BRep_Tool::Triangulation(f,location);
   if(tri.IsNull())throw std::runtime_error("missing mesh");
   for(int j=1;j<=tri->NbTriangles();++j){int a,b,c;tri->Triangle(j).Get(a,b,c);
    std::array<gp_XYZ,3> t={tri->Node(a).Transformed(location.Transformation()).XYZ(),tri->Node(b).Transformed(location.Transformation()).XYZ(),tri->Node(c).Transformed(location.Transformation()).XYZ()};
    if((t[1]-t[0]).Crossed(t[2]-t[0]).SquareModulus()>1e-30)triangles.push_back(t);
   }
  }
  std::cerr<<"triangles="<<triangles.size()<<"\n";
  auto measure = [&](const gp_Pnt& point) {
    double minimum=1e100;
    for(const auto& t:triangles)minimum=std::min(minimum,triangle_distance(point.XYZ(),t));
    minimum=std::sqrt(minimum);
    result.maximum=std::max(result.maximum,minimum);local=std::max(local,minimum);
    ++result.samples;
  };
  for (TopExp_Explorer it(source, TopAbs_EDGE); it.More(); it.Next()) {
    const BRepAdaptor_Curve curve(TopoDS::Edge(it.Current()));
    const double a = curve.FirstParameter(), b = curve.LastParameter();
    for (int i = 0; i <= 24; ++i) measure(curve.Value(a + (b - a) * i / 24.));
  }
  std::cerr<<"edges max="<<std::setprecision(17)<<local<<"\n";
  for (TopExp_Explorer it(source, TopAbs_FACE); it.More(); it.Next()) {
    local=0.; ++faceindex;
    const auto face = TopoDS::Face(it.Current());
    const BRepAdaptor_Surface surface(face);
    double u0, u1, v0, v1;
    BRepTools::UVBounds(face, u0, u1, v0, v1);
    if (!std::isfinite(u0) || !std::isfinite(u1) || !std::isfinite(v0) || !std::isfinite(v1))
      throw std::runtime_error("unbounded sample domain");
    for (int i = 0; i <= 10; ++i) {
      for (int j = 0; j <= 10; ++j) {
        const double u = u0 + (u1 - u0) * i / 10., v = v0 + (v1 - v0) * j / 10.;
        const auto state = BRepClass_FaceClassifier(face, gp_Pnt2d(u, v), 1e-8).State();
        if (state == TopAbs_IN || state == TopAbs_ON) measure(surface.Value(u, v));
      }
    }
    std::cerr<<"face "<<faceindex<<" type="<<surface.GetType()<<" max="<<local<<"\n";
  }
    std::cerr<<"boundary max="<<result.maximum<<"\n";
  if (!result.samples) throw std::runtime_error("empty sample set");
  return result;
}

int solids(const TopoDS_Shape& shape) {
  int count = 0;
  for (TopExp_Explorer it(shape, TopAbs_SOLID); it.More(); it.Next()) ++count;
  return count;
}

double volume(const TopoDS_Shape& shape) {
  return blend_audit::shape_volume(shape);
}
}

int main(int argc, char** argv) {
  if (argc != 4) {
    std::cerr << "usage: compare_shapes native.brep truck.step output.json\n";
    return 2;
  }
  try {
    TopoDS_Shape native;
    BRep_Builder builder;
    if (!BRepTools::Read(native, argv[1], builder)) throw std::runtime_error("BREP read failed");
    STEPControl_Reader reader;
    if (reader.ReadFile(argv[2]) != IFSelect_RetDone || !reader.TransferRoots())
      throw std::runtime_error("STEP read failed");
    const auto truck = reader.OneShape();
    if (native.IsNull() || truck.IsNull()) throw std::runtime_error("empty imported shape");
    const auto forward = distance(native, truck), reverse = distance(truck, native);
    std::ofstream out(argv[3]);
    out.exceptions(std::ios::failbit | std::ios::badbit);
    out << std::setprecision(17)
        << "{\"schema_version\":1,\"comparison\":\"sampled-only\","
        << "\"native_valid\":" << (BRepCheck_Analyzer(native).IsValid() ? "true" : "false")
        << ",\"truck_step_valid\":" << (BRepCheck_Analyzer(truck).IsValid() ? "true" : "false")
        << ",\"native_solids\":" << solids(native) << ",\"truck_solids\":" << solids(truck)
        << ",\"native_volume\":" << volume(native) << ",\"truck_volume\":" << volume(truck)
        << ",\"native_to_truck_max_distance\":" << forward.maximum
        << ",\"native_to_truck_samples\":" << forward.samples
        << ",\"truck_to_native_max_distance\":" << reverse.maximum
        << ",\"truck_to_native_samples\":" << reverse.samples;
    blend_audit::write_shape_tolerances(out, native, "native_tolerances");
    blend_audit::write_shape_tolerances(out, truck, "truck_step_tolerances");
    out << "}\n";
    return 0;
  } catch (const Standard_Failure& error) {
    std::cerr << error.GetMessageString() << '\n';
  } catch (const std::exception& error) {
    std::cerr << error.what() << '\n';
  }
  return 1;
}
