from pathlib import Path
import json,subprocess
s=Path('target/curved-cap-chamfer-tests.rs').read_text().replace('mod common;', '#[path="'+str(Path('truck-shapeops/tests/common/mod.rs').resolve())+'"] mod common;')
s=s.replace('"fixtures/adaptive-chamfer-contacts/', '"'+str(Path('truck-shapeops/tests/fixtures/adaptive-chamfer-contacts').resolve())+'/')
s=s.replace('try_chamfer_solid_along_wire(', 'try_chamfer_solid_along_wire_chord(')
a=s.index('        let volume =');b=s.index('        assert_eq!(before',a)
s=s[:a]+'''        use truck_stepio::out::*;
        let prepared=prepare_for_step(&result.solid.compress(),1e-7).unwrap();
        let step=StepDisplay::new(Default::default(),StepDesign::from_model(StepModel::from(&prepared))).to_string();
        std::fs::write("target/normal-section-c1.step",step).unwrap();
'''+s[b:]
Path('target/normal-section-c1.rs').write_text(s)
cmd=json.loads(Path('target/parabolic-chamfer-export-command.json').read_text());cmd=[q.replace('parabolic-chamfer-export','normal-section-c1') for q in cmd]
with Path('target/normal-section-c1-build.txt').open('w') as f: subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
with Path('target/normal-section-c1.txt').open('w') as f: subprocess.run(['target/normal-section-c1','--exact','curved_cap_chamfers_retain_trimmed_contacts_and_material','--nocapture'],stdout=f,stderr=subprocess.STDOUT,check=True)
