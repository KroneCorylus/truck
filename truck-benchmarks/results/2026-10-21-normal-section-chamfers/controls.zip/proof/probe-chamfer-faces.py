from pathlib import Path
import json,subprocess,os
s=Path('audits/fillet-chamfer/capture/compare_shapes.cpp').read_text()
s=s.replace('  Residual result;','  Residual result; double local=0.; int faceindex=0;')
s=s.replace('    result.maximum = std::max(result.maximum, query.Value());','    result.maximum = std::max(result.maximum, query.Value()); local=std::max(local,query.Value());')
s=s.replace('  for (TopExp_Explorer it(source, TopAbs_FACE); it.More(); it.Next()) {','  std::cerr<<"edges max="<<std::setprecision(17)<<local<<"\\n";\n  for (TopExp_Explorer it(source, TopAbs_FACE); it.More(); it.Next()) {\n    local=0.; ++faceindex;')
s=s.replace('  if (!result.samples)', '    std::cerr<<"boundary max="<<result.maximum<<"\\n";\n  if (!result.samples)')
s=s.replace('''    }
  }
  if (!result.samples)''','''    }
  }
  if (!result.samples)''')
needle='''    }
  }
    std::cerr<<"boundary max="'''
s=s.replace(needle,'''    }
    std::cerr<<"face "<<faceindex<<" type="<<surface.GetType()<<" max="<<local<<"\\n";
  }
    std::cerr<<"boundary max="''')
Path('target/normal-section-faces.cpp').write_text(s)
cmd=json.loads(Path('target/normal-section-native-command.json').read_text());cmd=[x.replace('normal-section-native','normal-section-faces') for x in cmd]
with Path('target/normal-section-faces-build.txt').open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
with Path('target/normal-section-faces.txt').open('w') as f:subprocess.run(['target/normal-section-faces','target/occt-capture-clipped-chamfer-contacts/chamfer/equal_dist_sequence/C1/capture/001.result.brep','target/normal-section-c1.step','target/normal-section-faces.json'],stdout=f,stderr=subprocess.STDOUT,check=True)
