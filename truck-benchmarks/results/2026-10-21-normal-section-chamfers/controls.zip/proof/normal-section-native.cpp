#include "shape_volume.hpp"
#include <BRepAdaptor_Surface.hxx>
#include <BRepBuilderAPI_MakeEdge.hxx>
#include <BRepBuilderAPI_MakeWire.hxx>
#include <BRepBuilderAPI_MakeFace.hxx>
#include <BRepCheck_Analyzer.hxx>
#include <BRepFilletAPI_MakeChamfer.hxx>
#include <BRepPrimAPI_MakePrism.hxx>
#include <BRepTools.hxx>
#include <Geom_BezierCurve.hxx>
#include <STEPControl_Writer.hxx>
#include <TopExp_Explorer.hxx>
#include <TopoDS.hxx>
#include <TopExp.hxx>
#include <BRep_Tool.hxx>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <array>
void save(const TopoDS_Shape& shape,const std::string& path){BRepTools::Write(shape,(path+".brep").c_str());STEPControl_Writer w;if(w.Transfer(shape,STEPControl_AsIs)!=IFSelect_RetDone||w.Write((path+".step").c_str())!=IFSelect_RetDone)throw std::runtime_error("STEP export failed");}

int main(int argc,char**argv){
 if(argc!=2)return 2;
 std::ofstream out(std::string(argv[1])+"/summary.json");out<<std::setprecision(17)<<"[";
 int index=0;
 for(double k:{.8,-.4}){
  TColgp_Array1OfPnt p(1,3);p(1)=gp_Pnt(0,0,1);p(2)=gp_Pnt(.5,0,1);p(3)=gp_Pnt(1,0,1+k);
  Handle(Geom_BezierCurve) curve=new Geom_BezierCurve(p);
  BRepBuilderAPI_MakeWire w;w.Add(BRepBuilderAPI_MakeEdge(gp_Pnt(0,0,0),p(1)));w.Add(BRepBuilderAPI_MakeEdge(curve));w.Add(BRepBuilderAPI_MakeEdge(p(3),gp_Pnt(1,0,0)));w.Add(BRepBuilderAPI_MakeEdge(gp_Pnt(1,0,0),gp_Pnt(0,0,0)));
  auto input=BRepPrimAPI_MakePrism(BRepBuilderAPI_MakeFace(w.Wire()).Face(),gp_Vec(0,1,0)).Shape();
  std::ostringstream before;BRepTools::Write(input,before);
  TopoDS_Edge guide;
  for(TopExp_Explorer e(input,TopAbs_EDGE);e.More();e.Next()){
   auto edge=TopoDS::Edge(e.Current());TopoDS_Vertex a,b;TopExp::Vertices(edge,a,b);
   auto pa=BRep_Tool::Pnt(a),pb=BRep_Tool::Pnt(b);gp_Pnt start(0,0,1),end(0,1,1);
   if((pa.Distance(start)<1e-8&&pb.Distance(end)<1e-8)||(pb.Distance(start)<1e-8&&pa.Distance(end)<1e-8)){guide=edge;break;}
  }
  if(guide.IsNull())return 2;
  TopoDS_Face reference;
  for(TopExp_Explorer f(input,TopAbs_FACE);f.More();f.Next()){
   auto face=TopoDS::Face(f.Current());if(BRepAdaptor_Surface(face).GetType()!=GeomAbs_Plane)continue;
   for(TopExp_Explorer e(face,TopAbs_EDGE);e.More();e.Next())if(e.Current().IsSame(guide))reference=face;
  }
  if(reference.IsNull())return 3;
  for(auto values:std::array<std::array<double,2>,3>{{{{.3,.2}},{{.2,.3}},{{.2,.2}}}}){
   double cap=values[0],wall=values[1];
   BRepFilletAPI_MakeChamfer operation(input);operation.Add(wall,cap,guide,reference);operation.Build();if(!operation.IsDone())return 4;
   auto shape=operation.Shape();std::string prefix=std::string(argv[1])+"/"+std::to_string(index);save(input,prefix+".input");save(shape,prefix+".result");
   std::ostringstream after;BRepTools::Write(input,after);
   double x=cap*std::sqrt(2/(1+std::sqrt(1+4*k*k*cap*cap)));double expected=1+k/3-wall*x/2+k*x*x*x/6;
   if(index)out<<",";
   out<<"{\"index\":"<<index<<",\"curvature\":"<<k<<",\"cap\":"<<cap<<",\"wall\":"<<wall<<",\"expected\":"<<expected<<",\"input_volume\":"<<blend_audit::shape_volume(input)<<",\"volume\":"<<blend_audit::shape_volume(shape)<<",\"valid\":"<<(BRepCheck_Analyzer(shape).IsValid()?"true":"false")<<",\"input_unchanged\":"<<(before.str()==after.str()?"true":"false")<<"}";
   ++index;
  }
 }
 out<<"]\n";
}
