from pathlib import Path
import subprocess,json
s=Path('target/normal-section-faces.cpp').read_text().replace('#include "shape_tolerances.hpp"','#include "shape_tolerances.hpp"\n#include <BRepMesh_IncrementalMesh.hxx>\n#include <BRep_Tool.hxx>\n#include <Poly_Triangulation.hxx>\n#include <array>\n#include <vector>')
s=s.replace('namespace {','''namespace {
double triangle_distance(const gp_XYZ& p,const std::array<gp_XYZ,3>& t){
 const auto a=t[0],b=t[1],c=t[2],ab=b-a,ac=c-a,ap=p-a;
 const double d1=ab.Dot(ap),d2=ac.Dot(ap);
 if(d1<=0&&d2<=0)return ap.SquareModulus();
 const auto bp=p-b; const double d3=ab.Dot(bp),d4=ac.Dot(bp);
 if(d3>=0&&d4<=d3)return bp.SquareModulus();
 const double vc=d1*d4-d3*d2;
 if(vc<=0&&d1>=0&&d3<=0)return (p-(a+ab*(d1/(d1-d3)))).SquareModulus();
 const auto cp=p-c;const double d5=ab.Dot(cp),d6=ac.Dot(cp);
 if(d6>=0&&d5<=d6)return cp.SquareModulus();
 const double vb=d5*d2-d1*d6;
 if(vb<=0&&d2>=0&&d6<=0)return (p-(a+ac*(d2/(d2-d6)))).SquareModulus();
 const double va=d3*d6-d5*d4;
 if(va<=0&&(d4-d3)>=0&&(d5-d6)>=0)return (p-(b+(c-b)*((d4-d3)/((d4-d3)+(d5-d6))))).SquareModulus();
 const double inv=1/(va+vb+vc);
 return (p-(a+ab*(vb*inv)+ac*(vc*inv))).SquareModulus();
}
''',1)
a=s.index('  TopoDS_Compound boundary;');b=s.index('  auto measure',a)
s=s[:a]+'''  BRepMesh_IncrementalMesh mesh(target,1e-5,false,.05,false);
  std::vector<std::array<gp_XYZ,3>> triangles;
  for(TopExp_Explorer it(target,TopAbs_FACE);it.More();it.Next()){
   const auto f=TopoDS::Face(it.Current());TopLoc_Location location;auto tri=BRep_Tool::Triangulation(f,location);
   if(tri.IsNull())throw std::runtime_error("missing mesh");
   for(int j=1;j<=tri->NbTriangles();++j){int a,b,c;tri->Triangle(j).Get(a,b,c);
    std::array<gp_XYZ,3> t={tri->Node(a).Transformed(location.Transformation()).XYZ(),tri->Node(b).Transformed(location.Transformation()).XYZ(),tri->Node(c).Transformed(location.Transformation()).XYZ()};
    if((t[1]-t[0]).Crossed(t[2]-t[0]).SquareModulus()>1e-30)triangles.push_back(t);
   }
  }
  std::cerr<<"triangles="<<triangles.size()<<"\\n";
'''+s[b:]
a=s.index('    const BRepExtrema_DistShapeShape query');b=s.index('    ++result.samples;',a)
s=s[:a]+'''    double minimum=1e100;
    for(const auto& t:triangles)minimum=std::min(minimum,triangle_distance(point.XYZ(),t));
    minimum=std::sqrt(minimum);
    result.maximum=std::max(result.maximum,minimum);local=std::max(local,minimum);
'''+s[b:]
Path('target/normal-section-mesh.cpp').write_text(s)
cmd=json.loads(Path('target/normal-section-native-command.json').read_text());cmd=[x.replace('normal-section-native','normal-section-mesh') for x in cmd]+['-lTKMesh']
with Path('target/normal-section-mesh-build.txt').open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
with Path('target/normal-section-mesh.txt').open('w') as f:subprocess.run(['target/normal-section-mesh','target/occt-capture-clipped-chamfer-contacts/chamfer/equal_dist_sequence/C1/capture/001.result.brep','target/normal-section-c1.step','target/normal-section-mesh.json'],stdout=f,stderr=subprocess.STDOUT,check=True)
