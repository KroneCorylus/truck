#include <algorithm>
#include <array>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <vector>
using V=std::array<double,3>;
double dist2(V p,V q){double s=0;for(int i=0;i<3;++i)s+=(p[i]-q[i])*(p[i]-q[i]);return s;}
struct Shape {
 double bottom,top,height,r;int mode;
 double slope,apex,shift,cap;
 Shape(double b,double t,double h,double round,int m):bottom(b),top(t),height(h),r(round),mode(m),slope((b-t)/h),apex(b/slope),shift(apex-r*std::sqrt(1+slope*slope)/slope),cap(m==0?r:h-r){}
 // Enumerate active faces of the inward cone intersected with two selected offset half-spaces.
 double distance(V p) const {
  double best=1e100;
  auto consider=[&](V q){if(q[1]<r-1e-12 || (mode==2 ? q[0]<r-1e-12 : (mode==0?q[2]<cap-1e-12:q[2]>cap+1e-12)) || std::hypot(q[0],q[1])>slope*(shift-q[2])+1e-12)return;best=std::min(best,dist2(p,q));};
  consider(p);consider({p[0],r,p[2]});
  if(mode==2){consider({r,p[1],p[2]});consider({r,r,p[2]});}
  else {consider({p[0],p[1],cap});consider({p[0],r,cap});}
  if(best==0)return 0;
  double rho=std::hypot(p[0],p[1]),h=(shift-p[2]+slope*rho)/(1+slope*slope);
  if(h>0&&rho>0)consider({slope*h*p[0]/rho,slope*h*p[1]/rho,shift-h});
  else consider({0,0,shift});
  auto radial=[&](int fixed){int free=1-fixed;double px=std::abs(p[free]),B=(p[2]-shift)/slope,A=1+1/(slope*slope);
   double lo=0,hi=std::max({px,std::abs(B)/A,r})+r;
   for(int i=0;i<36;++i){double x=(lo+hi)/2;double f=x*(A+B/std::hypot(x,r))-px;if(f>0)hi=x;else lo=x;}
   double x=(lo+hi)/2;V q{0,0,shift-std::hypot(x,r)/slope};q[fixed]=r;q[free]=std::copysign(x,p[free]);consider(q);
  };
  radial(1);
  if(mode==2){radial(0);consider({r,r,shift-std::sqrt(2.)*r/slope});}
  else {double R=slope*(shift-cap);if(R>0){if(rho>0)consider({R*p[0]/rho,R*p[1]/rho,cap});if(R>=r)consider({std::copysign(std::sqrt(R*R-r*r),p[0]),r,cap});}}
  return best;
 }
};
std::vector<std::pair<double,double>> gauss(int n){
 const double pi=std::acos(-1.);std::vector<std::pair<double,double>> nodes;
 for(int i=0;i<n;i++) {double x=std::cos(pi*(i+.75)/(n+.5)),der=0;for(int j=0;j<30;j++){double p=1,q=0;for(int k=1;k<=n;k++){double next=((2*k-1)*x*p-(k-1)*q)/k;q=p;p=next;}der=n*(x*p-q)/(x*x-1);double d=p/der;x-=d;if(std::abs(d)<2e-15)break;}nodes.emplace_back(x,2/((1-x*x)*der*der));}return nodes;
}
double volume(const Shape&s,int n){
 auto nodes=gauss(n);double total=0,pi=std::acos(-1.);std::vector<double> zs{0,s.height};
 for(double z:{s.cap,s.cap-s.r*s.slope/std::sqrt(1+s.slope*s.slope),s.shift-s.r/s.slope,s.shift-s.r/s.slope+s.r,s.shift-std::sqrt(2.)*s.r/s.slope,s.shift-std::sqrt(2.)*s.r/s.slope+s.r})if(z>0&&z<s.height)zs.push_back(z);
 std::sort(zs.begin(),zs.end());
 for(size_t k=1;k<zs.size();++k){double za=zs[k-1],zb=zs[k];for(auto[t,w]:nodes){double z=(za+zb+(zb-za)*t)/2,Y=s.bottom-s.slope*z,area=0;
  auto minimum=[&](double y){double upper=std::sqrt(std::max(0.,Y*Y-y*y));return s.distance({s.mode==2?std::min(s.r,upper):0.,y,z});};
  double peak=std::min(s.r,Y);if(minimum(peak)>s.r*s.r)continue;
  double ymin=0,ymax=Y,lo=0,hi=peak;
  if(minimum(0)>s.r*s.r){for(int i=0;i<40;++i){double y=(lo+hi)/2;if(minimum(y)<=s.r*s.r)hi=y;else lo=y;}ymin=(lo+hi)/2;}
  lo=peak;hi=Y;if(minimum(Y)>s.r*s.r){for(int i=0;i<40;++i){double y=(lo+hi)/2;if(minimum(y)<=s.r*s.r)lo=y;else hi=y;}ymax=(lo+hi)/2;}
  std::vector<double> ys{0,pi};for(double y:{s.r,s.r*std::sqrt(1+s.slope*s.slope)})if(y>ymin&&y<ymax)ys.push_back(std::acos(1-2*(y-ymin)/(ymax-ymin)));std::sort(ys.begin(),ys.end());
  for(size_t j=1;j<ys.size();++j){double a=ys[j-1],b=ys[j];for(auto[t2,w2]:nodes){double angle=(a+b+(b-a)*t2)/2,y=ymin+(ymax-ymin)*(1-std::cos(angle))/2,upper=std::sqrt(std::max(0.,Y*Y-y*y)),mid=s.mode==2?std::min(s.r,upper):0.;
   if(s.distance({mid,y,z})>s.r*s.r)continue;
   double lo=mid,hi=upper;for(int step=0;step<36;step++){double x=(lo+hi)/2;if(s.distance({x,y,z})<=s.r*s.r)lo=x;else hi=x;}double right=(lo+hi)/2,left=0;
   if(s.mode==2&&s.distance({0,y,z})>s.r*s.r){lo=0;hi=mid;for(int step=0;step<36;step++){double x=(lo+hi)/2;if(s.distance({x,y,z})<=s.r*s.r)hi=x;else lo=x;}left=(lo+hi)/2;}
   area+=(right-left)*(ymax-ymin)*std::sin(angle)/2*w2*(b-a)/2;
  }}total+=area*w*(zb-za)/2;
 }}return total;
}
int main(int argc,char**argv){std::cout<<std::setprecision(17);int n=argc>1?std::stoi(argv[1]):128;double r=argc>2?std::stod(argv[2]):.1;
 for(int kind=0;kind<4;++kind){Shape s(kind<2?.9:.5,kind<2?.4:0,kind<2?1.5:1.2,r,kind==1?1:(kind==2?2:0));std::cout<<"kind "<<kind<<" radius "<<r<<" nodes "<<n<<" quarter_volume "<<volume(s,n)<<std::endl;}
}
