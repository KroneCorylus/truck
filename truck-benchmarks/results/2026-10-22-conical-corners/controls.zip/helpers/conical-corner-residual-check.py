from pathlib import Path
import math,json
r=10.;k=1/3;angle=math.atan(k);rho=(270.-10.)*k-r/math.cos(angle);c=(math.sqrt(rho*rho-r*r),-r,r)
p=Path('target/conical-corner-verified-replays');out={}
for name,center in [('C2',c),('C8',(-10.,10.,120.-(math.sqrt(200.)+10./math.cos(math.atan(5/12)))/(5/12)))]:
 text=(p/name/'residual.log').read_text();directions=text.split('DIRECTION\n')[1:];values=[]
 for d in directions:
  last=[line for line in d.splitlines() if line.startswith('maximum ')][-1];v=list(map(float,last.split()[3:]));values.append(dict(point=v,sphere_residual=math.dist(v,center)-r))
 assert abs(values[0]['sphere_residual'])>.1 and abs(values[1]['sphere_residual'])<1e-7
 out[name]=dict(center=center,radius=r,native=values[0],truck=values[1])
Path('target/conical-corner-verified-residuals.json').write_text(json.dumps(out,indent=2)+'\n')
