from pathlib import Path
import subprocess,os,json,hashlib,re
out=Path('truck-benchmarks/results/2026-10-22-conical-corners');previous=Path('truck-benchmarks/results/2026-10-22-spherical-corners');prior=json.loads((previous/'validation.json').read_text());parent=json.loads((out/'parent.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for p,h in parent['test_sha256'].items():assert sha(p)==h,p
assert '1 passed; 1 failed' in (out/'parent-tests.txt').read_text()
assert '0 passed; 1 failed' in (out/'parent-replay-tests.txt').read_text()
reused={}
for crate,name in [('truck-geometry','geometry'),('truck-modeling','modeling'),('truck-meshalgo','meshalgo')]:
 sources={p:h for p,h in prior['source_sha256'].items() if p.startswith(crate+'/')};assert sources
 for p,h in sources.items():assert sha(p)==h,p
 reused[name]=prior['reused_validation'][name]
sources={str(p):sha(p) for base in ['truck-shapeops/src','truck-shapeops/tests','truck-shapeops/examples','truck-meshalgo/src','truck-meshalgo/tests','truck-geometry/src','truck-geometry/tests','truck-modeling/src','truck-modeling/tests','truck-stepio/src','truck-stepio/tests'] for p in Path(base).rglob('*.rs')};sources.update({str(p):sha(p) for p in Path('truck-shapeops/tests/fixtures/adaptive-chamfer-contacts').glob('*')})
sources.update({str(p):sha(p) for directory in ['normal-section-chamfer','tilted-cap-chamfers'] for p in Path('truck-shapeops/tests/fixtures',directory).glob('*')})
sources.update({str(p):sha(p) for p in Path('truck-stepio/tests/fixtures/spline-extrusion-pcurves').glob('*')})
sources.update({str(p):sha(p) for p in Path('audits/fillet-chamfer/capture').glob('*') if p.is_file() and p.suffix in ['.cpp','.hpp','.py','.sh','.tcl']})
sources.update({str(p):sha(p) for p in Path('truck-shapeops/tests/fixtures/curved-terminal-junctions').glob('*')})
sources.update({str(p):sha(p) for p in Path('truck-shapeops/tests/fixtures/polar-terminal-junctions').glob('*')})
sources.update({str(p):sha(p) for p in Path('truck-shapeops/tests/fixtures/cylindrical-corner-junctions').glob('*')})
sources.update({str(p):sha(p) for p in Path('truck-shapeops/tests/fixtures/chamfer-transition-orientation').glob('*')})
sources.update({str(p):sha(p) for p in Path('truck-shapeops/tests/fixtures/open-chamfer-terminals').glob('*')})
sources.update({str(p):sha(p) for p in Path('truck-shapeops/tests/fixtures/separated-fillet-components').glob('*')})
sources.update({str(p):sha(p) for directory in ['conical-corner-junctions','spherical-corner-junctions'] for p in Path('truck-shapeops/tests/fixtures',directory).glob('*')})
m=dict(parent_revision=parent['revision'],source_sha256=sources,reused_validation=reused,baseline_failure=prior['baseline_failure']);(out/'validation-start.json').write_text(json.dumps(m,indent=2)+'\n')
for name,cmd in [
 ('candidate-clean.txt',['cargo','clean','--release','-p','truck-stepio','-p','truck-shapeops']),
 ('native-plugin-build.txt',['bash','audits/fillet-chamfer/capture/build.sh','target/occt-sdk','target/occt-conical-corner-validation-plugin']),
 ('native-reference-tests.txt',['bash','audits/fillet-chamfer/capture/test_reference_sample.sh','target/occt-sdk','target/conical-corner-native-reference-check']),
 ('native-volume-tests.txt',['bash','audits/fillet-chamfer/capture/test_native_volume.sh','target/occt-sdk','target/conical-corner-native-volume-check']),
 ('native-distance-tests.txt',['bash','audits/fillet-chamfer/capture/test_native_distance.sh','target/occt-sdk','target/conical-corner-native-distance-check']),
 ('clippy.txt',['cargo','clippy','--release','-p','truck-shapeops','-p','truck-stepio','-p','truck-benchmarks','--all-targets']),
 ('shapeops-tests.txt',['cargo','test','--release','-p','truck-shapeops']),
 ('stepio-tests.txt',['cargo','test','--release','-p','truck-stepio']),
 ('replay-tests.txt',['cargo','test','--release','-p','truck-shapeops','--example','replay_occt_blend']),
 ('capture-tests.txt',['python3','-m','unittest','discover','-s','audits/fillet-chamfer/capture','-p','test_*.py']),
 ('actions-smoke.txt',['cargo','bench','-p','truck-benchmarks','--bench','actions','--','--test']),
 ('replay-build.txt',['cargo','build','--release','-p','truck-shapeops','--example','replay_occt_blend'])]:
 with (out/name).open('w') as log:
  log.write('$ '+' '.join(cmd)+'\n');log.flush();r=subprocess.run(cmd,env=dict(os.environ,CARGO_BUILD_JOBS='12',**({'RAYON_NUM_THREADS':'1'} if name=='actions-smoke.txt' else {})),stdout=log,stderr=subprocess.STDOUT);log.write(f'exit_code {r.returncode}\n')
 assert r.returncode==0,name;print(name,'passed',flush=True)
for p,h in sources.items():assert sha(p)==h,p
for name,expected in [('shapeops',[467,0,1]),('stepio',[119,0,0])]:
 counts=[tuple(map(int,c)) for c in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',(out/f'{name}-tests.txt').read_text())];m[name+'_counts']=list(map(sum,zip(*counts)));assert m[name+'_counts']==expected,m[name+'_counts']
assert '74 passed; 0 failed' in (out/'replay-tests.txt').read_text();m.update(replay_tests=74,replay_sha256=sha('target/release/examples/replay_occt_blend'))
assert '27 checks, 0 failures' in (out/'native-volume-tests.txt').read_text()
assert '24 checks, 0 failures' in (out/'native-distance-tests.txt').read_text()
assert '8 checks, 0 failures' in (out/'native-reference-tests.txt').read_text()
for p in out.glob('*.txt'):p.write_text('\n'.join(line.rstrip() for line in p.read_text().splitlines()).rstrip()+'\n')
m['log_sha256']={p.name:sha(p) for p in out.glob('*.txt')};(out/'validation.json').write_text(json.dumps(m,indent=2)+'\n');print('Validation complete',flush=True)
