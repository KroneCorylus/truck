from pathlib import Path
import json,hashlib,zipfile,re,subprocess
out=Path('truck-benchmarks/results/2026-10-22-conical-corners');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
v=json.loads((out/'validation.json').read_text());parent=json.loads((out/'parent.json').read_text())
for p,h in v['source_sha256'].items():assert sha(p)==h,p
assert parent['test_sha256']==parent['parent_test_sha256']
for p,h in parent['test_sha256'].items():assert sha(p)==h,p
files={};comparisons={};material={}
for name in ['C2','C6','C8','D1']:
 probe=Path('target/conical-corner-verified-replays')/name
 r=json.loads((probe/'001.truck.json').read_text())['result'];c=json.loads((probe/'001.comparison.json').read_text())
 assert r['status']=='operation-succeeded' and r['selected_edges']==3 and r['selection_scope']=='native-contours'
 assert all(r[k] is True for k in ['input_unchanged','geometry_consistent','mesh_closed','step_prepared'])
 assert c['native_valid'] and c['truck_step_valid'] and c['native_solids']==c['truck_solids']==1
 assert max(c['native_to_truck_max_distance'],c['truck_to_native_max_distance'])>.001
 assert max(c['truck_step_tolerances'].values())<.001
 comparisons[name]=c
 for p in probe.iterdir():
  if p.is_file():files[f'probe/{name}/{p.name}']=p
maximum=0.
for r,suffix in [(0.1,''),(.03,'-r03'),(.06,'-r06')]:
 rows={}
 for n in [128,256]:
  p=Path(f'target/conical-corner-volume-refined-{n}{suffix}.txt');values=[float(m) for m in re.findall(r'quarter_volume ([^\n]+)',p.read_text())];assert len(values)==4;rows[n]=values;files['volume/'+p.name]=p
 difference=max(abs(x-y) for x,y in zip(rows[128],rows[256]));assert difference<2e-8;maximum=max(maximum,difference);material[r]=rows
files['volume/conical-corner-volume.cpp']=Path('target/conical-corner-volume.cpp')
files['volume/controls.json']=Path('target/conical-corner-volume-controls.json')
for name in ['prove-conical-corner-parent.py','validate-conical-corners.py','verify-conical-corner-replays.py','conical-corner-residual-check.py','package-conical-corner-proof.py']:
 files['helpers/'+name]=Path('target')/name
for name in parent['test_sha256']:files['parent/'+name]=Path('target/conical-corner-parent-source')/name
subprocess.run(['python3','target/conical-corner-residual-check.py'],check=True)
for name in ['spherical-corner-residual.cpp','conical-corner-verified-residuals.json']:
 files['diagnostics/'+name]=Path('target')/name
for name in ['shape_volume.hpp','shape_tolerances.hpp']:files['diagnostics/'+name]=Path('audits/fillet-chamfer/capture')/name
commands={'volume':['g++','-O3','-std=c++17','conical-corner-volume.cpp','-o','PROGRAM'],'volume_run':'PROGRAM N RADIUS; N is 128 or 256; radii 0.03,0.06,0.1','diagnostic':json.loads(Path('target/fillet-X1-diagnostic/native-surfaces-command.json').read_text()),'note':'Replace source/output with spherical-corner-residual.cpp/program. Run native tools with LD_LIBRARY_PATH=target/occt-sdk/usr/lib64. Canonical comparison thresholds and projector remain unchanged.'};p=out/'control-commands.json';p.write_text(json.dumps(commands,indent=2)+'\n');files['helpers/control-commands.json']=p
hashes={k:sha(p) for k,p in files.items()};archive=out/'controls.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(files.items()):z.write(p,name)
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(files)
 for name,p in files.items():assert hashlib.sha256(z.read(name)).hexdigest()==hashes[name]==sha(p),name
summary=dict(procedural_operations=48,collision_rejections=8,normalized_imported_selections=8,original_scale_replays=4,independent_material=material,quadrature_maximum_difference=maximum,native_comparisons=comparisons,sphere_residuals=json.loads(Path('target/conical-corner-verified-residuals.json').read_text()),archive_sha256=sha(archive),archive_members=len(files),member_sha256=hashes)
(out/'controls-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(out/'REPORT.md').write_text(f'''# Conical support corners with planar terminations

Three selected edges on an outward cone and two planes now join an exact rolling
sphere, toroidal cap rounds and fitted cone/radial-plane blends. Offset-cone
intersections locate the sphere. Hyperbolic rolling centers use a regular lateral
parameter at axial terminals. Fitted side contacts intersect remote caps before
shared trim edges are assembled. Existing validity and trim guards remain.

Both new regressions fail on parent {parent['revision']} with identical sources
and fixtures. Clean package builds avoid shared-worktree Cargo cache reuse.
The 48 procedural operations cover truncated 90/270-degree cones, apex sectors
and meridian terminations, three radii, two placements and both selection orders.
Exact analytic radii/center, fitted radius residual below 1e-5, nine tangent joins
with normal dot greater than 1-1e-7, closed material, STEP and input immutability
are checked. Eight oversized requests reject. The initial prototype fit failed
the tangency control; the new path uses tol/100, without weakening the assertion.

Material is independently integrated by projecting onto the inward cone
intersected with two selected offset half-spaces and integrating its radius-r
dilation inside the unselected boundaries. Active-constraint projection is
independent of the builder and its surface fitter. Domain-aware 128/256-node
section quadrature differs by at most {maximum:.8g}; the 270-degree case adds a
separate analytic half-cone/cap-round integral. Eight normalized native selections
and four original-scale production replays preserve all three selected edges.

All four native comparisons remain discrepancies. C2 and C8 native corner samples
lie respectively about 0.1655 and 4.8284 away from their exact radius-10 sphere;
corresponding Truck samples lie on the sphere to numerical precision. Evidence
is retained without changing comparator statuses or claiming all discrepancies
are explained. Independent normalized volumes are 0.5102133441641101 (C2),
1.5599191504183765 (C6), 0.06486303410642758 (C8), 0.06687424247638343 (D1).
Native-reader STEP tolerances remain below 0.001. Sampled checks establish neither
a global error bound nor full native parity.

Validation: 467 release shapeops tests (one existing ignore), 119 STEP tests,
74 replay tests, 13 capture tests, all-target Clippy and single-thread actions
smoke pass. Native reference 8, volume 27 and distance 24 checks pass. Existing
redundant-borrow and sphere-literal-precision warnings are unchanged. Geometry,
modeling and meshalgo evidence is reused only with identical source hashes; the
known pcurve_derivation precision failure remains explicit. Replay is built last.
No existing assertions, thresholds or replay fitting budgets were weakened.

Proof archive: {len(files)} members; SHA256 {sha(archive)}.
Implementation is committed before a fresh full 648-operation capture.
No consumer/pin changes, push, PR or performance claim.
''')
print('Proof archive verified',len(files),sha(archive))
