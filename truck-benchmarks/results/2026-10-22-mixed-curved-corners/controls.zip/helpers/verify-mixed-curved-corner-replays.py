from pathlib import Path
import shutil,subprocess,os,json,hashlib
v=json.loads(Path('truck-benchmarks/results/2026-10-22-mixed-curved-corners/validation.json').read_text());assert hashlib.sha256(Path('target/release/examples/replay_occt_blend').read_bytes()).hexdigest()==v['replay_sha256']
env=os.environ|{'LD_LIBRARY_PATH':'target/occt-sdk/usr/lib64'}
for name in ['F1','H7']:
 p=Path('target/mixed-curved-corner-verified-replays')/name;p.mkdir(parents=True,exist_ok=True);source=Path('target/occt-capture-torus-corners/blend/simple')/name/'capture'
 for ext in ['input.step','input.json','result.brep','result.json']:shutil.copyfile(source/f'001.{ext}',p/f'001.{ext}')
 with (p/'001.truck.log').open('w') as log:subprocess.run(['target/release/examples/replay_occt_blend',str(p/'001')],stdout=log,stderr=subprocess.STDOUT,check=True)
 with (p/'001.comparison.log').open('w') as log:subprocess.run(['target/occt-distance-tree-plugin/compare_shapes',str(p/'001.result.brep'),str(p/'001.truck.step'),str(p/'001.comparison.json')],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 print(name,'complete',flush=True)
