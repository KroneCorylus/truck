from pathlib import Path
import json,hashlib,zipfile,re
out=Path('truck-benchmarks/results/2026-10-22-mixed-curved-corners');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
v=json.loads((out/'validation.json').read_text());parent=json.loads((out/'parent.json').read_text())
for p,h in v['source_sha256'].items():assert sha(p)==h,p
assert parent['test_sha256']==parent['parent_test_sha256']
for p,h in parent['test_sha256'].items():assert sha(p)==h,p
files={};comparisons={}
for name in ['F1','H7']:
 probe=Path('target/mixed-curved-corner-verified-replays')/name
 r=json.loads((probe/'001.truck.json').read_text())['result'];c=json.loads((probe/'001.comparison.json').read_text())
 assert r['status']=='operation-succeeded' and r['selected_edges']==3 and r['selection_scope']=='native-contours'
 assert all(r[k] is True for k in ['input_unchanged','geometry_consistent','mesh_closed','step_prepared'])
 assert c['native_valid'] and c['truck_step_valid'] and c['native_solids']==c['truck_solids']==1
 assert (max(c['native_to_truck_max_distance'],c['truck_to_native_max_distance'])<=.001)==(name=='F1')
 assert max(c['truck_step_tolerances'].values())<.001
 assert c==json.loads(Path(f'target/mixed-curved-original-scale/{name}/001.comparison.json').read_text())
 comparisons[name]=c
 for p in probe.iterdir():
  if p.is_file():files[f'probe/{name}/{p.name}']=p
controls={}
for case,stem in [('F1','mixed-torus'),('H7','mixed-cylinder')]:
 rows={}
 p=Path(f'target/{stem}-volume-controls.txt')
 for line in p.read_text().splitlines():
  m=re.fullmatch(r'nodes (\d+) radius (\S+) .* volume (\S+)',line);assert m,line
  count,radius,volume=m.groups();rows.setdefault(radius,{})[count]=float(volume)
 assert len(rows)==3
 maximum=max(abs(row['128']-row['256']) for row in rows.values());assert maximum<1e-13
 controls[case]=dict(rows=rows,maximum_difference=maximum)
 for suffix in ['.cpp','-method.txt','-controls.txt']:
  p=Path(f'target/{stem}-volume{suffix}');files['volume/'+p.name]=p
for name in ['prove-mixed-curved-corner-parent.py','validate-mixed-curved-corners.py','verify-mixed-curved-corner-replays.py','package-mixed-curved-corner-proof.py','mixed-curved-H7-analytic-residuals.py','spherical-corner-residual.cpp']:
 files['helpers/'+name]=Path('target')/name
for name in parent['test_sha256']:files['parent/'+name]=Path('target/mixed-curved-corner-parent-source')/name
for pattern in ['mixed-curved-H7-0.*-*.txt','mixed-curved-*-tight-*.txt','mixed-curved-tight-tests.txt','mixed-curved-final-preflight-clippy.txt','mixed-native-tests-timeout-300.txt','mixed-native-tests.txt']:
 for p in Path('target').glob(pattern):files['diagnostics/'+p.name]=p
for name in ['residual.json','residual.log','analytic-residuals.json']:
 p=Path('target/mixed-curved-original-scale/H7')/name;files['diagnostics/H7/'+name]=p
assert json.loads(Path('target/mixed-curved-original-scale/H7/residual.json').read_text())==comparisons['H7']
witnesses=json.loads(Path('target/mixed-curved-original-scale/H7/analytic-residuals.json').read_text())
assert witnesses['witnesses'][0]['mixed_sphere_envelope_radius_residual']>.001
assert abs(witnesses['witnesses'][1]['mixed_sphere_envelope_radius_residual'])<1e-6
commands=dict(volume_compile=['g++','-O3','-std=c++17','SOURCE.cpp','-o','PROGRAM'],volume_run='PROGRAM N RADIUS; N=128,256 and RADIUS=.03,.06,.1',note='Independent boundary flux F=(0,y,0), divergence1. No CAD/native/mesh dependencies. Failed coarse-fit H7 G1 controls retained; composed fits tightened without weakening assertions. Canonical native statuses and thresholds remain unchanged.')
p=out/'control-commands.json';p.write_text(json.dumps(commands,indent=2)+'\n');files['helpers/control-commands.json']=p
hashes={k:sha(p) for k,p in files.items()};archive=out/'controls.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(files.items()):z.write(p,name)
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(files)
 for name,p in files.items():assert hashlib.sha256(z.read(name)).hexdigest()==hashes[name]==sha(p),name
summary=dict(procedural_operations=12,oversized_rejections=4,normalized_imported_operations=24,original_scale_replays=2,independent_material=controls,native_comparisons=comparisons,H7_analytic_witnesses=witnesses,archive_sha256=sha(archive),archive_members=len(files),member_sha256=hashes)
(out/'controls-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(out/'REPORT.md').write_text(f'''# Mixed curved corners with a shared planar wall

A trivalent selection with one concave rim and two convex edges sharing a planar
wall rounds the rim first, then the resulting three-edge tangent chain. If the
original open-chain trim fails, internal contacts continue across the common
support. Remote terminals and final geometry/trim guards still bound the result.
Final face correspondence is computed against the original solid.

The new procedural and native regressions fail on parent {parent['revision']}
with identical sources and fixtures. The previous F1 unsupported-case assertion
was intentionally rewritten before implementation to check four generated faces,
closed independent material, STEP and unchanged input. All six oversized torus
rejections remain unchanged, and four mixed oversized rejections are added.
The revised contract also fails on the parent. Clean package builds prevent
shared-worktree Cargo cache reuse.

Twelve procedural F1 operations and24 imported F1/H7 operations cover three
radii, two placements and both orders. Four fitted faces, constant radius residual
below1e-5, ten tangent joins with normal dot greater than1-1e-7, independent volume,
closed tessellation, STEP and input immutability are checked. H7 initially failed
the strict tangency check; tightening only the two composed fits to tol/100 fixes
it without weakening the assertion. Failed and passing diagnostic logs are retained. An isolated combined native
run reached all24 radius/G1 checks but hit its300-second runner limit during
final material/STEP work; that incomplete attempt is retained separately from
the required completed full replay suite.

Independent boundary-flux quadrature computes F1 torus and H7 cylinder/cap/wall
material. It uses no CAD builder, fitted surface, native library or mesh. Sources,
derivations and128/256-node convergence at all three radii are archived.

Two original-scale production replays construct valid closed STEP with unchanged
physical selections. F1 passes the limited native comparison. H7 retains its
.001525464/.001514833 discrepancy against the .001 threshold. At the two worst
sample witnesses, analytic radius residuals are .001525552 for the native point
and approximately7.72e-7 for the Truck point. The diagnostic comparison exactly
matches the canonical comparison; these witnesses do not establish a global bound.

Validation:471 release shapeops tests (one existing ignore),119 STEP tests,
76 replay tests,13 capture tests, all-target Clippy and single-thread actions
smoke pass. Native reference8,volume27,distance24 checks pass. Existing warnings
and the known geometry precision failure remain explicit; reused dependency
validation is allowed only with identical source hashes. Replay is built last.

Proof archive:{len(files)} members; SHA256 {sha(archive)}.
Implementation is committed before a fresh full648-operation capture.
No canonical comparison thresholds, replay STEP budgets, consumer pins, push,
PR, parity guarantee or performance claim.
''')
print('Proof archive verified',len(files),sha(archive))
