from pathlib import Path
import json,math
p=Path('target/mixed-curved-original-scale/H7')
assert json.loads((p/'residual.json').read_text())==json.loads((p/'001.comparison.json').read_text())
parts=(p/'residual.log').read_text().split('DIRECTION')[1:];assert len(parts)==2
out=[]
for label,part in zip(['native_to_truck','truck_to_native'],parts):
 line=[x for x in part.splitlines() if x.startswith('maximum ')][-1]
 s=line.split();point=list(map(float,s[3:]));x,y,z=point
 def squared_distance(beta):
  rho=60+20*math.cos(beta);center=(-10,-math.sqrt(rho*rho-100),-40+20*math.sin(beta))
  return sum((a-b)**2 for a,b in zip(point,center))
 count=10000;lo=-math.pi;hi=-math.pi/2;step=(hi-lo)/count
 i=min(range(count+1),key=lambda i:squared_distance(lo+step*i))
 a=lo+max(0,i-1)*step;b=lo+min(count,i+1)*step
 for _ in range(100):
  left=a+(b-a)/3;right=b-(b-a)/3
  if squared_distance(left)<squared_distance(right):b=right
  else:a=left
 beta=(a+b)/2
 out.append(dict(direction=label,canonical_max_distance=float(s[1]),point=point,nearest_center_parameter=beta,mixed_sphere_envelope_radius_residual=math.sqrt(squared_distance(beta))-10,first_concave_torus_residual=math.hypot(math.hypot(x,y)-60,z+40)-10,cylinder_wall_residual=math.hypot(x+10,y+math.sqrt(1500))-10,cap_wall_residual=math.hypot(x+10,z+60)-10))
result=dict(method='Analytic mixed-corner center C(beta)=(-10,-sqrt((60+20*cos(beta))^2-100),-40+20*sin(beta)), beta in [-pi,-pi/2]. Grid bracketing then 100 ternary steps minimize squared distance; subtract radius 10. Diagnostic comparator JSON exactly equals canonical comparison. These two witness residuals do not establish a global error bound.',witnesses=out)
(p/'analytic-residuals.json').write_text(json.dumps(result,indent=2)+'\n')
print('Analytic witness residuals:',*[x['mixed_sphere_envelope_radius_residual'] for x in out])
