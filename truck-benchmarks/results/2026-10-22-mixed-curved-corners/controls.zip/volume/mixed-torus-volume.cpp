#include <cmath>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <vector>
#include <utility>
constexpr double pi=3.1415926535897932384626433832795;
std::vector<std::pair<double,double>> nodes(int n){
 std::vector<std::pair<double,double>> result;
 for(int i=0;i<n;i++){
  double x=std::cos(pi*(i+.75)/(n+.5)),der=0.;
  for(int k=0;k<100;k++){
   double a=1.,b=x;for(int j=2;j<=n;j++){double c=((2*j-1)*x*b-(j-1)*a)/j;a=b;b=c;}
   der=n*(x*b-a)/(x*x-1.);double next=x-b/der;if(std::abs(next-x)<1e-15){x=next;break;}x=next;
  }
  result.push_back({x,2./((1.-x*x)*der*der)});
 }
 return result;
}
template<class F>double integrate(const std::vector<std::pair<double,double>>& q,double a,double b,F f){double v=0.;for(auto [x,w]:q)v+=w*f((a+b)/2.+(b-a)*x/2.);return v*(b-a)/2.;}
int main(int argc,char**argv){
 int count=argc>1?std::atoi(argv[1]):128;double r=argc>2?std::atof(argv[2]):.1;
 auto quadrature=nodes(count);double R=2.,m=.5,end=160*pi/180.,H=m*std::sin(end);
 double theta=pi-std::asin((H+r)/(m+r));double B=R+(m+r)*std::cos(theta);
 auto flux=[&](double t,double major,double original_minor,double center_minor,double normal_sign){
  double co=std::cos(t),si=std::sin(t),rho=major+center_minor*co;
  double original_rho=major+original_minor*co,nrho=normal_sign*co;
  double x=std::sqrt(rho*rho-r*r),rp=-center_minor*si,rpp=-center_minor*co;
  double xp=rho*rp/x,xpp=rho*rpp/x-r*r*rp*rp/(x*x*x);
  double zp=center_minor*co,zpp=-center_minor*si,speed=std::hypot(xp,zp);
  double curvature=normal_sign*(xp*zpp-zp*xpp)/(speed*speed*speed);
  double phi=std::asin(r/rho),retained=pi/4.-phi/2.+std::sin(2*phi)/4.;
  double cosine=-r*nrho/rho,angle=std::acos(cosine);
  double i0=std::sin(angle)-angle/2.-std::sin(2*angle)/4.;
  double i1=-cosine*cosine/2.+cosine*cosine*cosine/3.+1./6.;
  return original_rho*original_rho*nrho*original_minor*retained-r*r*speed*(i0+r*curvature*i1);
 };
 double outer=integrate(quadrature,0,theta,[&](double t){return flux(t,R,m,m-r,1.);});
 double concave=integrate(quadrature,-pi/2.,theta-pi,[&](double t){return flux(t,B,r,2*r,-1.);});
 double cap=-r*r*std::sqrt(B*B-r*r)*(1.-pi/4.);
 std::cout<<std::setprecision(17)<<"nodes "<<count<<" radius "<<r<<" outer "<<outer<<" concave "<<concave<<" cap "<<cap<<" volume "<<outer+concave+cap<<"\n";
}
