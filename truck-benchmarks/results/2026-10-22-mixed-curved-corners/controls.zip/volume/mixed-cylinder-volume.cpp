#include <cmath>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <vector>
#include <utility>
constexpr double pi=3.1415926535897932384626433832795;
std::vector<std::pair<double,double>> nodes(int n){
 std::vector<std::pair<double,double>> result;
 for(int i=0;i<n;i++){
  double x=std::cos(pi*(i+.75)/(n+.5)),der=0.;
  for(int k=0;k<100;k++){
   double a=1.,b=x;for(int j=2;j<=n;j++){double c=((2*j-1)*x*b-(j-1)*a)/j;a=b;b=c;}
   der=n*(x*b-a)/(x*x-1.);double next=x-b/der;if(std::abs(next-x)<1e-15){x=next;break;}x=next;
  }
  result.push_back({x,2./((1.-x*x)*der*der)});
 }
 return result;
}
template<class F>double integrate(const std::vector<std::pair<double,double>>& q,double a,double b,F f){double v=0.;for(auto [x,w]:q)v+=w*f((a+b)/2.+(b-a)*x/2.);return v*(b-a)/2.;}

int main(int argc,char**argv){
 int count=argc>1?std::atoi(argv[1]):128;double r=argc>2?std::atof(argv[2]):.1;
 auto q=nodes(count);double alpha=3*pi/2.,H=-.5,B=.5+r,center_radius=.5-r;
 auto flux=[&](double t){
  double co=std::cos(t),si=std::sin(t),a=2*r,rho=B+a*co,original_rho=B+r*co,nrho=-co;
  double x=std::sqrt(rho*rho-r*r),rp=-a*si,rpp=-a*co;
  double xp=rho*rp/x,xpp=rho*rpp/x-r*r*rp*rp/(x*x*x);
  double zp=a*co,zpp=-a*si,speed=std::hypot(xp,zp),curvature=-(xp*zpp-zp*xpp)/(speed*speed*speed);
  double phi=std::asin(r/rho),retained=alpha/2.-phi/2.+std::sin(2*phi)/4.;
  double cosine=-r*nrho/rho,angle=std::acos(cosine),i0=std::sin(angle)-angle/2.-std::sin(2*angle)/4.;
  double i1=-cosine*cosine/2.+cosine*cosine*cosine/3.+1./6.;
  return original_rho*original_rho*nrho*r*retained-r*r*speed*(i0+r*curvature*i1);
 };
 double phi=std::asin(r/center_radius),angle=std::acos(-r/center_radius);
 double cylinder=(1.-r)*(.25*(alpha/2.-phi/2.+std::sin(2*phi)/4.)-r*r*(std::sin(angle)-angle/2.-std::sin(2*angle)/4.));
 double concave=integrate(q,-pi,-pi/2.,flux);
 double start=std::sqrt(B*B-r*r);
 double cap=integrate(q,0.,pi/2.,[&](double u){double y=r*(1.-std::cos(u)),z=H-r+r*std::sin(u),rho=z+2.5;double length=std::sqrt(rho*rho-y*y)-start;return -r*r*(1.-std::cos(u))*std::cos(u)*length;});
 double cone_loss=integrate(q,0.,pi/2.,[&](double u){double z=H-r+r*std::sin(u),rho=z+2.5,y=r*(1.-std::cos(u)),p=std::asin(y/rho);return rho*rho*(p/2.-std::sin(2*p)/4.)*r*std::cos(u);});
 double cones=alpha/2.*16./3.;
 std::cout<<std::setprecision(17)<<"nodes "<<count<<" radius "<<r<<" cones "<<cones<<" loss "<<cone_loss<<" cylinder "<<cylinder<<" concave "<<concave<<" cap "<<cap<<" volume "<<cones-cone_loss+cylinder+concave+cap<<"\n";
}
