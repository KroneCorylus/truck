#include <BRepAdaptor_Curve.hxx>
#include <BRepAdaptor_Surface.hxx>
#include <BRepPrimAPI_MakeCylinder.hxx>
#include <BRepAlgoAPI_Cut.hxx>
#include <BRepCheck_Analyzer.hxx>
#include <BRepGProp.hxx>
#include <GProp_GProps.hxx>
#include <BRepTools.hxx>
#include <BRep_Builder.hxx>
#include <TopExp_Explorer.hxx>
#include <TopoDS.hxx>
#include <TopoDS_Compound.hxx>
#include <cmath>
#include <stdexcept>
#include <string>
int main(int argc,char**argv) {
 if(argc!=2)return 1;
 const double pi=std::acos(-1.),theta=7*pi/12,small=3.,big=4.5,height=10.;
 for(bool stepped:{false,true}) {
  auto solid=BRepPrimAPI_MakeCylinder(small,height,theta).Shape();
  double expected=theta/2*small*small*height;
  if(stepped) {
   auto wedge=BRepPrimAPI_MakeCylinder(gp_Ax2(gp_Pnt(0,0,-1),gp_Dir(0,0,1)),6.,height+2,theta).Shape();
   auto inner=BRepPrimAPI_MakeCylinder(gp_Ax2(gp_Pnt(0,0,-2),gp_Dir(0,0,1)),small,height+4).Shape();
   auto tool=BRepAlgoAPI_Cut(wedge,inner).Shape();
   solid=BRepAlgoAPI_Cut(BRepPrimAPI_MakeCylinder(big,height).Shape(),tool).Shape();
   expected=pi*big*big*height-theta/2*(big*big-small*small)*height;
  }
  if(!BRepCheck_Analyzer(solid).IsValid())throw std::runtime_error("invalid solid");
  GProp_GProps props;BRepGProp::VolumeProperties(solid,props);
  if(std::abs(props.Mass()-expected)>1e-8)throw std::runtime_error("wrong input volume");
  TopoDS_Edge rim;TopoDS_Face cap;
  for(TopExp_Explorer it(solid,TopAbs_FACE);it.More();it.Next()) {
   auto face=TopoDS::Face(it.Current());BRepAdaptor_Surface surface(face);
   if(surface.GetType()!=GeomAbs_Plane||std::abs(std::abs(surface.Plane().Axis().Direction().Z())-1)>1e-8||std::abs(surface.Plane().Location().Z())>1e-8)continue;
   for(TopExp_Explorer edges(face,TopAbs_EDGE);edges.More();edges.Next()) {
    auto edge=TopoDS::Edge(edges.Current());BRepAdaptor_Curve curve(edge);
    if(curve.GetType()==GeomAbs_Circle&&std::abs(curve.Circle().Radius()-small)<1e-8){rim=edge;cap=face;}
   }
  }
  if(rim.IsNull()||cap.IsNull())throw std::runtime_error("missing rim");
  TopoDS_Compound bundle;BRep_Builder builder;builder.MakeCompound(bundle);builder.Add(bundle,solid);builder.Add(bundle,rim);builder.Add(bundle,cap);
  if(!BRepTools::Write(bundle,(std::string(argv[1])+(stepped?"/stepped.brep":"/convex.brep")).c_str()))return 1;
 }
}
