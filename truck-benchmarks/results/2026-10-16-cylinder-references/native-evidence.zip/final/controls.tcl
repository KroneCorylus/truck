pload ALL
pload -BlendAudit BLENDAUDIT
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
restore "/home/krone/Development/Pieza_WS/truck/target/native-cylinder-reference-final/input-0.brep" bundle0
puts [explode bundle0]
audit_blend_output before0 bundle0_1
if {[catch {chamf result0 bundle0_1 bundle0_2 bundle0_4 0.3 0.7} message]} {puts $message;exit 3}
audit_blend_output after0 bundle0_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-cylinder-reference-final/input-1.brep" bundle1
puts [explode bundle1]
audit_blend_output before1 bundle1_1
if {[catch {chamf result1 bundle1_1 bundle1_2 bundle1_4 A 0.3 60} message]} {puts $message;exit 3}
audit_blend_output after1 bundle1_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-cylinder-reference-final/input-2.brep" bundle2
puts [explode bundle2]
audit_blend_output before2 bundle2_1
if {[catch {chamf result2 bundle2_1 bundle2_2 bundle2_4 0.09 0.02} message]} {puts $message;exit 3}
audit_blend_output after2 bundle2_1
exit
