from pathlib import Path
import subprocess,os,json,hashlib,shutil
root=Path.cwd();parent=root/'target/angle-seams-parent-source';out=root/'truck-benchmarks/results/2026-10-22-angle-seams';out.mkdir(exist_ok=True)
revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=parent,text=True).strip()==revision
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
files=['truck-shapeops/tests/tilted_cap_chamfer.rs','truck-shapeops/examples/replay_occt_blend.rs']
for name in files:shutil.copyfile(root/name,parent/name)
shutil.copyfile(root/'Cargo.lock',parent/'Cargo.lock')
env=os.environ|{'CARGO_BUILD_JOBS':'12','CARGO_TARGET_DIR':str(root/'target')}
with (out/'parent-clean.txt').open('w') as f:subprocess.run(['cargo','clean','--release','-p','truck-shapeops'],cwd=parent,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
for name,cmd in [('parent-tests.txt',['cargo','test','--release','-p','truck-shapeops','--test','tilted_cap_chamfer','tilted_cap_angle_chamfer_crosses_tangent_support_seams']),('parent-replay-tests.txt',['cargo','test','--release','-p','truck-shapeops','--example','replay_occt_blend','imported_tilted_angle_contacts_join_and_preserve_material'])]:
 with (out/name).open('w') as f:
  f.write('$ '+' '.join(cmd)+'\n');f.flush();r=subprocess.run(cmd,cwd=parent,env=env,stdout=f,stderr=subprocess.STDOUT);f.write(f'exit_code {r.returncode}\n')
 assert r.returncode==101,name;assert '0 passed; 1 failed' in (out/name).read_text(),name;assert 'trim_faces' in (out/name).read_text(),name
 print(name,'expected failure confirmed',flush=True)
(out/'parent.json').write_text(json.dumps(dict(revision=revision,test_sha256={name:sha(root/name) for name in files},parent_test_sha256={name:sha(parent/name) for name in files},binding_change=None),indent=2)+'\n')
print('Parent proof complete',flush=True)
