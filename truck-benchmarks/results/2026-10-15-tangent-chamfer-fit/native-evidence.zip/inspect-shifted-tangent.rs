use truck_modeling::*;
use truck_meshalgo::prelude::*;
use truck_shapeops::fillet::*;
fn main() {
 let v=builder::vertices([[0.,0.],[6.,0.],[10.,4.],[10.,20.],[0.,20.]].map(|[x,y]|Point3::new(x,y,0.)));
 let mid=Point3::new(6.+4./2_f64.sqrt(),4.-4./2_f64.sqrt(),0.);
 let wire:Wire=vec![builder::line(&v[0],&v[1]),builder::circle_arc(&v[1],&v[2],mid),builder::line(&v[2],&v[3]),builder::line(&v[3],&v[4]),builder::line(&v[4],&v[0])].into();
 let input:Solid=builder::tsweep(&builder::try_attach_plane(&[wire]).unwrap(),Vector3::new(0.,0.,30.));
 let input=builder::transformed(&input,Matrix4::from_scale(0.025));
 let offset: f64=std::env::args().nth(1).unwrap().parse().unwrap();
 let mut seen=std::collections::HashSet::new();for edge in input.edge_iter(){if seen.insert(edge.id()){let mut curve=NurbsCurve::<Vector4>::try_from(&edge.curve()).unwrap();curve.parameter_transform(1.,offset);edge.set_curve(curve.into());}}
 assert!(input.is_geometric_consistent());
 let top=input.face_iter().find(|f|f.oriented_surface().normal(0.,0.).z>0.9).unwrap();
 let mut picked:Vec<_>=top.boundaries()[0].iter().filter(|e|{let c=e.curve();let (a,b)=c.range_tuple();let p=c.subs((a+b)/2.);p.x.abs()>1e-8&&(p.y-0.5).abs()>1e-8}).cloned().collect();
 while picked.last().unwrap().back()==picked.first().unwrap().front(){picked.rotate_left(1);}
 let mut wire:Wire=picked.into();if std::env::args().nth(2).as_deref()==Some("reverse"){wire.invert();}println!("selected {} continuous {}",wire.len(),wire.is_continuous());
 println!("solid result {:?}",try_chamfer_solid_along_wire(&input,&wire,0.025,0.025,0.001).map(|r|(r.solid.is_geometric_consistent(),r.solid.triangulation(0.001).to_polygon().volume())));
 if let Ok(shell)=try_chamfer_along_wire(&input.boundaries()[0],&wire,0.025,0.025,0.001) {
  println!("low-level shell consistent {}",shell.is_geometric_consistent());
  for (i,f) in shell.face_iter().enumerate(){for (j,e) in f.boundary_iters().into_iter().flatten().enumerate(){let c=e.curve();let s=f.surface();if !e.is_geometric_consistent()||!s.include(&c){println!("face {i} edge {j}, valid {}, included {}, endpoints {} {}",e.is_geometric_consistent(),s.include(&c),c.front().distance(e.absolute_front().point()),c.back().distance(e.absolute_back().point()));}}}
 }
}
