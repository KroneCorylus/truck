#include <BRepTools.hxx>
#include <BRep_Builder.hxx>
#include <BRepAdaptor_Curve.hxx>
#include <BRepAdaptor_Surface.hxx>
#include <GCPnts_QuasiUniformDeflection.hxx>
#include <BRepFilletAPI_MakeChamfer.hxx>
#include <TopExp.hxx>
#include <TopExp_Explorer.hxx>
#include <TopTools_IndexedDataMapOfShapeListOfShape.hxx>
#include <TopoDS.hxx>
#include <gp_Pln.hxx>
#include <iostream>
#include <iomanip>
int main(int argc, char** argv) {
  if (argc != 6) return 2;
  TopoDS_Shape s; BRep_Builder b;
  if (!BRepTools::Read(s, argv[1], b)) return 3;
  gp_Pnt target(std::atof(argv[3]), std::atof(argv[4]), std::atof(argv[5]));
  TopoDS_Edge chosen;
  for (TopExp_Explorer it(s, TopAbs_EDGE); it.More(); it.Next()) {
    auto edge=TopoDS::Edge(it.Current());
    BRepAdaptor_Curve c(edge);
    if (c.Value((c.FirstParameter()+c.LastParameter())/2).Distance(target)<1e-7) {chosen=edge;break;}
  }
  if (chosen.IsNull()) return 4;
  std::cout<<std::setprecision(17);
  BRepFilletAPI_MakeChamfer maker(s); maker.Add(std::atof(argv[2]),chosen);
  std::cout<<"contours "<<maker.NbContours()<<"\n";
  TopTools_IndexedDataMapOfShapeListOfShape adjacent;
  TopExp::MapShapesAndAncestors(s,TopAbs_EDGE,TopAbs_FACE,adjacent);
  for(int i=1;i<=maker.NbContours();++i) {
    std::cout<<"edges "<<maker.NbEdges(i)<<"\n";
    for(int j=1;j<=maker.NbEdges(i);++j) {
      auto edge=maker.Edge(i,j);BRepAdaptor_Curve c(edge);
      GCPnts_QuasiUniformDeflection samples(c,1e-5);
      std::cout<<"{\"points\":[";
      for(int k=1;k<=samples.NbPoints();++k) {auto p=samples.Value(k);if(k>1)std::cout<<",";std::cout<<"["<<p.X()<<","<<p.Y()<<","<<p.Z()<<"]";}
      std::cout<<"]}\n";
      for(double t:{c.FirstParameter(),c.LastParameter()}) {auto p=c.Value(t);std::cout<<"point "<<p.X()<<" "<<p.Y()<<" "<<p.Z()<<"\n";}
      for(TopTools_ListIteratorOfListOfShape f(adjacent.FindFromKey(edge));f.More();f.Next()) {
        auto face=TopoDS::Face(f.Value());BRepAdaptor_Surface surf(face);
        std::cout<<"surface "<<surf.GetType()<<" orientation "<<face.Orientation()<<"\n";
        if(surf.GetType()==GeomAbs_Plane) {auto p=surf.Plane();auto n=p.Axis().Direction();auto o=p.Location();std::cout<<"plane "<<o.X()<<" "<<o.Y()<<" "<<o.Z()<<" normal "<<n.X()<<" "<<n.Y()<<" "<<n.Z()<<"\n";}
      }
    }
  }
}
