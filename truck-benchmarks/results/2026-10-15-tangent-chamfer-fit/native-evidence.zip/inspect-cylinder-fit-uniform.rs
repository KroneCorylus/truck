use truck_modeling::*;
use truck_shapeops::fillet::*;
use std::result::Result;
use truck_base::cgmath64::control_point::ControlPoint;
use truck_base::diagnostics::{validate_tolerance, Code, Diagnostic};

/// Number of samples along the edge is at least this, so a cubic interpolation is always possible.
const MIN_SAMPLES: usize = 4;

/// Samples the contact curves of a chamfer along `edge`.
///
/// At each sample the in-face direction on `surface_i` is the surface tangent perpendicular to the
/// edge, pointing into the face. The contact point is the point of `surface_i` nearest to the point
/// at distance `d_i` along that direction. Returns, for each surface, the samples in parameter
/// space and in space at the supplied parameters.
#[allow(clippy::type_complexity)]
fn sample_contact_points<C, S>(
    edge: &C,
    surface0: &S,
    surface1: &S,
    (d0, d1): (f64, f64),
    params: &[f64],
) -> Option<[Vec<(Point2, Point3)>; 2]>
where
    C: FilletedCurve<S> + ParameterDivision1D<Point = Point3>,
    S: FilletedSurface<C> + SearchNearestParameter<D2, Point = Point3>,
{
    let contact = |surface: &S, distance: f64, sign: f64, hint: &mut Option<(f64, f64)>| {
        let mut samples = Vec::with_capacity(params.len());
        for &t in params {
            let p = edge.subs(t);
            let e = edge.der(t).normalize();
            let uv = surface.search_parameter(p, *hint, 100)?;
            let w = surface.normal(uv.0, uv.1).cross(e) * sign;
            let mut uv = surface.search_nearest_parameter(p + w * distance, Some(uv), 100)?;
            if let Some((u, v)) = *hint {
                if let Some(period) = surface.u_period() {
                    uv.0 += ((u - uv.0) / period).round() * period;
                }
                if let Some(period) = surface.v_period() {
                    uv.1 += ((v - uv.1) / period).round() * period;
                }
            }
            *hint = Some(uv);
            samples.push((Point2::from(uv), surface.subs(uv.0, uv.1)));
        }
        Some(samples)
    };
    let samples0 = contact(surface0, d0, 1.0, &mut None)?;
    let samples1 = contact(surface1, d1, -1.0, &mut None)?;
    Some([samples0, samples1])
}

fn interpolate<P>(params: &[f64], points: impl Iterator<Item = P>) -> BSplineCurve<P>
where P: ControlPoint<f64> + Copy {
    let (t0, t1) = (params[0], params[params.len() - 1]);
    let mut knot_vec = KnotVec::uniform_knot(3, params.len() - 3);
    knot_vec.transform(t1 - t0, t0);
    let parameter_points: Vec<_> = params.iter().copied().zip(points).collect();
    BSplineCurve::interpole(knot_vec, parameter_points)
}

#[derive(Clone, Copy)]
enum Representation {
    Analytic,
    Nurbs,
    ReparameterizedNurbs,
}

fn cylinder(representation: Representation) -> Solid {
    let solid = { let v=builder::vertex(Point3::new(0.,5.,0.));let circle=builder::rsweep(&v,Point3::new(0.,0.,0.),Vector3::unit_z(),Rad(7.),2);builder::tsweep(&builder::try_attach_plane(&[circle]).unwrap(),Vector3::new(0.,0.,8.)) };
    if matches!(representation, Representation::Analytic) {
        return solid;
    }
    solid.mapped(
        |point| *point,
        |curve| Curve::NurbsCurve(NurbsCurve::try_from(curve).unwrap()),
        |surface| match surface {
            Surface::Extruded(surface) => {
                let bottom = NurbsCurve::try_from(surface.entity_curve()).unwrap();
                let top = bottom.transformed(Matrix4::from_translation(surface.extruding_vector()));
                let mut surface = NurbsSurface::new(BSplineSurface::homotopy(
                    bottom.into_non_rationalized(),
                    top.into_non_rationalized(),
                ));
                if matches!(representation, Representation::ReparameterizedNurbs) {
                    surface
                        .elevate_udegree()
                        .elevate_vdegree()
                        .knot_translate(8., -3.);
                }
                surface.into()
            }
            other => other.clone(),
        },
    )
}

fn rim(solid: &Solid) -> Wire {
    solid
        .face_iter()
        .find(|face| face.vertex_iter().all(|vertex| vertex.point().z.near(&8.)))
        .unwrap()
        .boundaries()[0]
        .clone()
}


fn main(){for kind in [Representation::Nurbs,Representation::ReparameterizedNurbs] {
 let input=cylinder(kind);let wire=rim(&input);let edge=&wire[0];
 let mut adjacent=[None,None];for f in input.face_iter(){if let Some(e)=f.edge_iter().find(|e|e.id()==edge.id()){adjacent[usize::from(e.front()!=edge.front())]=Some(f.oriented_surface());}}
 let [Some(s0),Some(s1)]=adjacent else {panic!()};let edge=edge.oriented_curve();let (t0,t1)=edge.range_tuple();let mut count=edge.parameter_division((t0,t1),0.001).0.len().max(MIN_SAMPLES);
 for _ in 0..3 {let params:Vec<_>=(0..count).map(|i|t0+(t1-t0)*i as f64/(count-1) as f64).collect();
 let samples=sample_contact_points(&edge,&s0,&s1,(0.5,0.3),&params).unwrap();
 let pcurves:[PCurve<BSplineCurve<Point2>,Surface>;2]=std::array::from_fn(|i|PCurve::new(interpolate(&params,samples[i].iter().map(|s|s.0)),if i==0{s0.clone()}else{s1.clone()}));
 let curves:[BSplineCurve<Point3>;2]=std::array::from_fn(|i|interpolate(&params,samples[i].iter().map(|s|s.1)));
 let ruled=Surface::BSplineSurface(BSplineSurface::homotopy(curves[0].clone(),curves[1].clone()));
 for side in 0..2 {let mut max_same=0.0_f64;let mut max_near=0.0_f64;
 for pair in params.windows(2){for i in 0..=4{let t=pair[0]+(pair[1]-pair[0])*i as f64/4.;let p=pcurves[side].subs(t);max_same=max_same.max(p.distance(curves[side].subs(t)));let u=curves[side].search_nearest_parameter(p,Some(t),100).unwrap().clamp(t0,t1);max_near=max_near.max(p.distance(curves[side].subs(u)));}}
 let c:Curve=pcurves[side].to_same_geometry();println!("shifted {}, count {count} side {side}, same {max_same} near {max_near}, included {}",matches!(kind,Representation::ReparameterizedNurbs),ruled.include(&c));
 }
 count=2*count-1;
 }
}}
