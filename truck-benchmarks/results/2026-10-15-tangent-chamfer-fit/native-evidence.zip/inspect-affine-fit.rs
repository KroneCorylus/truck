use truck_modeling::*;
use truck_shapeops::fillet::*;
use std::result::Result;
use truck_base::cgmath64::control_point::ControlPoint;
use truck_base::diagnostics::{validate_tolerance, Code, Diagnostic};

/// Number of samples along the edge is at least this, so a cubic interpolation is always possible.
const MIN_SAMPLES: usize = 4;

/// Samples the contact curves of a chamfer along `edge`.
///
/// At each sample the in-face direction on `surface_i` is the surface tangent perpendicular to the
/// edge, pointing into the face. The contact point is the point of `surface_i` nearest to the point
/// at distance `d_i` along that direction. Returns, for each surface, the samples in parameter
/// space and in space at the supplied parameters.
#[allow(clippy::type_complexity)]
fn sample_contact_points<C, S>(
    edge: &C,
    surface0: &S,
    surface1: &S,
    (d0, d1): (f64, f64),
    params: &[f64],
) -> Option<[Vec<(Point2, Point3)>; 2]>
where
    C: FilletedCurve<S> + ParameterDivision1D<Point = Point3>,
    S: FilletedSurface<C> + SearchNearestParameter<D2, Point = Point3>,
{
    let contact = |surface: &S, distance: f64, sign: f64, hint: &mut Option<(f64, f64)>| {
        let mut samples = Vec::with_capacity(params.len());
        for &t in params {
            let p = edge.subs(t);
            let e = edge.der(t).normalize();
            let uv = surface.search_parameter(p, *hint, 100)?;
            let w = surface.normal(uv.0, uv.1).cross(e) * sign;
            let mut uv = surface.search_nearest_parameter(p + w * distance, Some(uv), 100)?;
            if let Some((u, v)) = *hint {
                if let Some(period) = surface.u_period() {
                    uv.0 += ((u - uv.0) / period).round() * period;
                }
                if let Some(period) = surface.v_period() {
                    uv.1 += ((v - uv.1) / period).round() * period;
                }
            }
            *hint = Some(uv);
            samples.push((Point2::from(uv), surface.subs(uv.0, uv.1)));
        }
        Some(samples)
    };
    let samples0 = contact(surface0, d0, 1.0, &mut None)?;
    let samples1 = contact(surface1, d1, -1.0, &mut None)?;
    Some([samples0, samples1])
}

fn interpolate<P>(params: &[f64], points: impl Iterator<Item = P>) -> BSplineCurve<P>
where P: ControlPoint<f64> + Copy {
    let (t0, t1) = (params[0], params[params.len() - 1]);
    let mut knot_vec = KnotVec::uniform_knot(3, params.len() - 3);
    knot_vec.transform(t1 - t0, t0);
    let parameter_points: Vec<_> = params.iter().copied().zip(points).collect();
    BSplineCurve::interpole(knot_vec, parameter_points)
}

fn main(){for count in [4,17,129,257]{let params:Vec<_>=(0..count).map(|i|2.+3.*i as f64/(count-1) as f64).collect();let value=|t|Point3::new(1.+2.*t,-3.+0.5*t,5.-4.*t);let c=interpolate(&params,params.iter().map(|&t|value(t)));let error=(0..=1024).map(|i|{let t=2.+3.*i as f64/1024.;c.subs(t).distance(value(t))}).fold(0.0_f64,f64::max);println!("count {count} max position error {error}");}}
