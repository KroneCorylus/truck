pload ALL
pload -BlendAudit BLENDAUDIT
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
proc control {name args} {
    set code [catch {uplevel 1 $args} result options]
    puts [list CONTROL $name $code $result]
    if {$code != 0} {exit 3}
}
box b 10 20 30
explode b E
control box_replaced blend box_result b 2 b_1 3 b_1
audit_blend_output box_after b
source "/home/krone/Development/Pieza_WS/investigations/sequential-holes-2026-10-10/occt/tests/chamfer/begin"
restore "/home/krone/Development/Pieza_WS/truck/target/native-fillet-contour-controls-final/A4.input.brep" tangent
explode tangent E
set seed [get_element EDGE -0.34571952701154405 0.1548338023048353 0.5]
set other [get_element EDGE 0.06204501370870732 0.70316976562354375 0.5]
if {$seed eq "" || $other eq "" || $seed eq $other} {exit 4}
puts [list TANGENT_SEEDS $seed $other]
control single blend single_result tangent 0.03 $seed
control replaced blend replaced_result tangent 0.03 $seed 0.04 $seed
control same blend same_result tangent 0.03 $seed 0.03 $other
control variable blend variable_result tangent 0.03 $seed 0.04 $other
control restored blend restored_result tangent 0.03 $seed 0.04 $other 0.04 $seed
control rational blend rational_result tangent 0.03 $seed R
control quasi blend quasi_result tangent 0.03 $seed q
control polynomial blend polynomial_result tangent 0.03 $seed P
tolblend 0.012345678912345678 0.00012345678912345678 0.000012345678912345678 0.0012345678912345678
continuityblend C2 -0.023456789123456789
tolblend
continuityblend
control configured blend configured_result tangent 0.03 $seed
tolblend 0.01 0.0001 0.00001 0.001
continuityblend C1 0.01
control zero_replaced blend zero_result tangent 0.0 $seed 0.03 $seed
audit_blend_output tangent_after tangent
exit
