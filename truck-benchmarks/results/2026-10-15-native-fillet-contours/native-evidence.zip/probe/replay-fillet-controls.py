from pathlib import Path
import json,subprocess,os,math
root=Path.cwd();out=root/'target/native-fillet-contour-controls-final';replay=root/'target/release/examples/replay_occt_blend';compare=root/'target/occt-fillet-contour-plugin/compare_shapes'
env=dict(os.environ,LD_LIBRARY_PATH=str(root/'target/occt-sdk/usr/lib64'))
results=[]
for i,p in enumerate(sorted((out/'capture').glob('*.input.json')),1):
 prefix=str(p).removesuffix('.input.json')
 with Path(prefix+'.truck.log').open('w') as log: subprocess.run([str(replay),prefix],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120,check=True)
 r=json.loads(Path(prefix+'.truck.json').read_text())['result'];assert r['selection_scope']=='native-contours',r
 if i in [5,8,9,10]:
  assert r['status']=='unhandled-intent',(i,r)
  assert not Path(prefix+'.truck.step').exists()
  comparison=None
 else:
  assert r['status']=='operation-succeeded' and all(r[k] for k in ['input_unchanged','geometry_consistent','mesh_closed','step_prepared']),(i,r)
  assert r['selected_edges']==(1 if i==1 else 3)
  with Path(prefix+'.comparison.log').open('w') as log:subprocess.run([str(compare),prefix+'.result.brep',prefix+'.truck.step',prefix+'.comparison.json'],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120,check=True)
  comparison=json.loads(Path(prefix+'.comparison.json').read_text())
  assert comparison['native_valid'] and comparison['truck_step_valid'] and comparison['native_solids']==comparison['truck_solids']==1,(i,comparison)
  assert max(comparison['native_to_truck_max_distance'],comparison['truck_to_native_max_distance'])<.001,(i,comparison)
  if i==1:
   exact=6000.-(1-math.pi/4)*9*30
   assert abs(comparison['native_volume']-exact)<1e-8 and abs(comparison['truck_volume']-exact)<1e-7
 results.append(dict(control=i,result=r,comparison=comparison))
 print(i,r['status'],None if comparison is None else max(comparison['native_to_truck_max_distance'],comparison['truck_to_native_max_distance']),flush=True)
(out/'proof.json').write_text(json.dumps(results,indent=2)+'\n')
print('7 complete constructions,4explicit unsupported intents; all native comparisons passed')
