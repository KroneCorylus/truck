from pathlib import Path
import sys,json,shutil
root=Path.cwd();sys.path.insert(0,str(root/'audits/fillet-chamfer'))
from run_occt import isolated_display,execute,tcl_word
out=root/'target/native-fillet-contour-controls-final';out.mkdir(exist_ok=False)
occt=(root/'../investigations/sequential-holes-2026-10-10/occt').resolve();plugin=root/'target/occt-fillet-contour-plugin';sdk=root/'target/occt-sdk/usr/lib64';draw=shutil.which('DRAWEXE')
fixture=root/'target/occt-capture-reference-contours-stable/chamfer/equal_dist_sequence/A4/capture/001.input.brep';shutil.copyfile(fixture,out/'A4.input.brep')
script=out/'controls.tcl'
script.write_text(f'''pload ALL
pload -BlendAudit BLENDAUDIT
source {tcl_word(root/'audits/fillet-chamfer/capture/blend_capture.tcl')}
proc control {{name args}} {{
    set code [catch {{uplevel 1 $args}} result options]
    puts [list CONTROL $name $code $result]
    if {{$code != 0}} {{exit 3}}
}}
box b 10 20 30
explode b E
control box_replaced blend box_result b 2 b_1 3 b_1
audit_blend_output box_after b
source {tcl_word(occt/'tests/chamfer/begin')}
restore {tcl_word(out/'A4.input.brep')} tangent
explode tangent E
set seed [get_element EDGE -0.34571952701154405 0.1548338023048353 0.5]
set other [get_element EDGE 0.06204501370870732 0.70316976562354375 0.5]
if {{$seed eq "" || $other eq "" || $seed eq $other}} {{exit 4}}
puts [list TANGENT_SEEDS $seed $other]
control single blend single_result tangent 0.03 $seed
control replaced blend replaced_result tangent 0.03 $seed 0.04 $seed
control same blend same_result tangent 0.03 $seed 0.03 $other
control variable blend variable_result tangent 0.03 $seed 0.04 $other
control restored blend restored_result tangent 0.03 $seed 0.04 $other 0.04 $seed
control rational blend rational_result tangent 0.03 $seed R
control quasi blend quasi_result tangent 0.03 $seed q
control polynomial blend polynomial_result tangent 0.03 $seed P
tolblend 0.012345678912345678 0.00012345678912345678 0.000012345678912345678 0.0012345678912345678
continuityblend C2 -0.023456789123456789
tolblend
continuityblend
control configured blend configured_result tangent 0.03 $seed
tolblend 0.01 0.0001 0.00001 0.001
continuityblend C1 0.01
control zero_replaced blend zero_result tangent 0.0 $seed 0.03 $seed
audit_blend_output tangent_after tangent
exit
''')
with isolated_display(out) as env:
 env.update(LD_LIBRARY_PATH=f'{plugin}:{sdk}',CASROOT=str(occt),CSF_BlendAuditDefaults=str(plugin),CSF_DrawPluginDefaults=str(occt/'src/DrawResources'),DRAWDEFAULT=str(occt/'src/DrawResources/DrawDefault'),CSF_TestScriptsPath=str(occt/'tests'),CSF_ShadersDirectory=str(occt/'src/Shaders'))
 log,code,timeout,elapsed=execute([draw,'-v','-f',str(script)],out,env,120)
 (out/'controls.log').write_text(log)
 assert code==0 and not timeout,(code,timeout,log[-4000:])
 captures=sorted((out/'capture').glob('*.input.json'));assert len(captures)==11,len(captures)
 for i,p in enumerate(captures,1):
  task=json.loads(p.read_text());assert task['schema_version']==3
  assert len(task['contours'])==1
  c=task['contours'][0];assert len(c['edges'])==(1 if i==1 else 3),(i,c)
  expected={1:3,2:.03,3:.04,4:.03,5:None,6:.04,7:.03,8:.03,9:.03,10:.03,11:.03}[i]
  assert c['constant_radius']==expected,(i,c)
  result=json.loads(p.with_name(p.name.replace('.input.','.result.')).read_text())
  assert result['native_valid'] and result['solids']==1,(i,result)
  print(i,len(task['selection']),c['constant_radius'],task['native_settings']['representation'],result['volume'])
 config=json.loads(captures[9].read_text())['native_settings']
 assert config['angular_tolerance']==0.012345678912345678 and config['continuity_angle']==0.023456789123456789 and config['continuity']=='C2',config
 assert (out/'box_after.result.brep').read_bytes()==captures[0].with_name('001.input.brep').read_bytes()
 assert (out/'tangent_after.result.brep').read_bytes()==captures[1].with_name('002.input.brep').read_bytes()
 for p in captures[1:]:assert p.with_name(p.name.replace('.json','.brep')).read_bytes()==(out/'tangent_after.result.brep').read_bytes()
 print('11 native controls passed; inputs unchanged; exact settings captured')
