#include <BRep_Builder.hxx>
#include <BRepTools.hxx>
#include <BRepFilletAPI_MakeFillet.hxx>
#include <BRepCheck_Analyzer.hxx>
#include <TopExp_Explorer.hxx>
#include <TopoDS.hxx>
#include <iostream>
#include <iomanip>

void dump(BRepFilletAPI_MakeFillet& b) {
  for (int c=1;c<=b.NbContours();++c) {
    std::cout<<" contour="<<c<<" edges="<<b.NbEdges(c)<<" constant="<<b.IsConstant(c);
    if(b.IsConstant(c)) std::cout<<" radius="<<b.Radius(c);
    for(int i=1;i<=b.NbEdges(c);++i) {
      const auto e=b.Edge(c,i);
      std::cout<<" edge"<<i<<"="<<b.IsConstant(c,e);
      if(b.IsConstant(c,e)) std::cout<<":"<<b.Radius(c,e);
    }
    std::cout<<std::endl;
  }
}
int main(int argc,char** argv) {
  if(argc!=2) return 1;
  std::cout<<std::setprecision(17);
  for(int mode=0;mode<5;++mode) {
    TopoDS_Shape shape; BRep_Builder reader;
    if(!BRepTools::Read(shape,argv[1],reader)) return 2;
    TopoDS_Edge seed;
    for(TopExp_Explorer it(shape,TopAbs_EDGE);it.More();it.Next()) {
      BRepFilletAPI_MakeFillet probe(shape);probe.Add(.03,TopoDS::Edge(it.Current()));
      if(probe.NbContours()==1 && probe.NbEdges(1)==3) {seed=TopoDS::Edge(it.Current());break;}
    }
    if(seed.IsNull()) return 3;
    BRepFilletAPI_MakeFillet b(shape);
    b.SetParams(1e-2,1e-4,1e-5,1e-4,1e-5,1e-3);b.SetContinuity(GeomAbs_C1,1e-2);
    b.Add(.03,seed);
    auto other=b.Edge(1,1);if(other.IsSame(seed)) other=b.Edge(1,3);
    if(mode==1) b.Add(.04,seed);
    if(mode==2) b.Add(.03,other);
    if(mode==3) b.Add(.04,other);
    if(mode==4) { b.Add(.04,other);b.Add(.04,seed); }
    std::cout<<"mode="<<mode<<" before"<<std::endl;dump(b);
    try {b.Build();std::cout<<"done="<<b.IsDone();if(b.IsDone()) std::cout<<" valid="<<BRepCheck_Analyzer(b.Shape()).IsValid();std::cout<<std::endl;dump(b);}
    catch(const Standard_Failure& e) {std::cout<<"exception="<<e.GetMessageString()<<std::endl;}
  }
}
