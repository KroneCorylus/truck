from pathlib import Path
import json,shutil,subprocess,os,hashlib
root=Path.cwd();source=root/'target/native-longitudinal-chamfer-controls/capture';dest=root/'target/native-longitudinal-distance-parent';dest.mkdir(exist_ok=False)
proof=root/'truck-benchmarks/results/2026-10-16-longitudinal-chamfer-distances';replay=root/'target/release/examples/replay_occt_blend';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
old=json.loads((root/'truck-benchmarks/results/2026-10-16-consumed-chamfer-neighbor/validation.json').read_text());assert sha(replay)==old['replay_sha256']
records=[]
for i in range(1,4):
 prefix=dest/f'{i:03}'
 for p in source.glob(f'{i:03}.*'):
  if '.input.' in p.name or '.result.' in p.name:shutil.copyfile(p,dest/p.name)
 with Path(str(prefix)+'.truck.log').open('w') as log:subprocess.run([str(replay),str(prefix)],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
 r=json.loads(Path(str(prefix)+'.truck.json').read_text())['result'];q=dict(capture=f'{i:03}',result=r)
 if i==1:
  assert r['status']=='operation-succeeded',r
  with Path(str(prefix)+'.comparison.log').open('w') as log:subprocess.run([str(root/'target/occt-cone-reference-plugin/compare_shapes'),str(prefix)+'.result.brep',str(prefix)+'.truck.step',str(prefix)+'.comparison.json'],env=dict(os.environ,LD_LIBRARY_PATH=str(root/'target/occt-sdk/usr/lib64')),stdout=log,stderr=subprocess.STDOUT,check=True)
  c=json.loads(Path(str(prefix)+'.comparison.json').read_text());q['comparison']=c
  assert max(c[k] for k in ['native_to_truck_max_distance','truck_to_native_max_distance'])>.001
 else:assert r['status']=='unhandled-intent',r
 records.append(q);print(i,r['status'],q.get('comparison',{}).get('native_to_truck_max_distance'))
assert sha(replay)==old['replay_sha256']
(dest/'summary.json').write_text(json.dumps(dict(replay_sha256=sha(replay),records=records),indent=2)+'\n')
