pload ALL
pload -BlendAudit BLENDAUDIT
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
restore "/home/krone/Development/Pieza_WS/truck/target/native-longitudinal-chamfer-controls/input-0.brep" bundle0
explode bundle0
audit_blend_output before0 bundle0_1
chamf result0 bundle0_1 bundle0_2 .5
audit_blend_output after0 bundle0_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-longitudinal-chamfer-controls/input-0.brep" bundle1
explode bundle1
audit_blend_output before1 bundle1_1
chamf result1 bundle1_1 bundle1_2 bundle1_3 .7 1.5
audit_blend_output after1 bundle1_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-longitudinal-chamfer-controls/input-0.brep" bundle2
explode bundle2
audit_blend_output before2 bundle2_1
chamf result2 bundle2_1 bundle2_2 bundle2_4 1.5 .7
audit_blend_output after2 bundle2_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-longitudinal-chamfer-controls/input-0.brep" bundle3
explode bundle3
audit_blend_output before3 bundle3_1
chamf result3 bundle3_1 bundle3_2 bundle3_3 A .7 30
audit_blend_output after3 bundle3_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-longitudinal-chamfer-controls/input-0.brep" bundle4
explode bundle4
audit_blend_output before4 bundle4_1
chamf result4 bundle4_1 bundle4_2 bundle4_4 A 1.5 30
audit_blend_output after4 bundle4_1
exit
