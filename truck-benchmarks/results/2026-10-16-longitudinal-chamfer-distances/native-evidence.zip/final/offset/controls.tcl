pload ALL
pload -BlendAudit BLENDAUDIT
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
restore "/home/krone/Development/Pieza_WS/truck/target/native-longitudinal-offset-controls/input-0.brep" bundle0
explode bundle0
audit_blend_output before0 bundle0_1
chamf result0 bundle0_1 bundle0_2 .5
audit_blend_output after0 bundle0_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-longitudinal-offset-controls/input-0.brep" bundle1
explode bundle1
audit_blend_output before1 bundle1_1
chamf result1 bundle1_1 bundle1_2 bundle1_3 .7 1.5
audit_blend_output after1 bundle1_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-longitudinal-offset-controls/input-0.brep" bundle2
explode bundle2
audit_blend_output before2 bundle2_1
chamf result2 bundle2_1 bundle2_2 bundle2_4 1.5 .7
audit_blend_output after2 bundle2_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-longitudinal-offset-controls/input-1.brep" bundle3
explode bundle3
audit_blend_output before3 bundle3_1
chamf result3 bundle3_1 bundle3_2 .5
audit_blend_output after3 bundle3_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-longitudinal-offset-controls/input-1.brep" bundle4
explode bundle4
audit_blend_output before4 bundle4_1
chamf result4 bundle4_1 bundle4_2 bundle4_3 .7 1.5
audit_blend_output after4 bundle4_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-longitudinal-offset-controls/input-1.brep" bundle5
explode bundle5
audit_blend_output before5 bundle5_1
chamf result5 bundle5_1 bundle5_2 bundle5_4 1.5 .7
audit_blend_output after5 bundle5_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-longitudinal-offset-controls/input-2.brep" bundle6
explode bundle6
audit_blend_output before6 bundle6_1
chamf result6 bundle6_1 bundle6_2 .5
audit_blend_output after6 bundle6_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-longitudinal-offset-controls/input-2.brep" bundle7
explode bundle7
audit_blend_output before7 bundle7_1
chamf result7 bundle7_1 bundle7_2 bundle7_3 .7 1.5
audit_blend_output after7 bundle7_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-longitudinal-offset-controls/input-2.brep" bundle8
explode bundle8
audit_blend_output before8 bundle8_1
chamf result8 bundle8_1 bundle8_2 bundle8_4 1.5 .7
audit_blend_output after8 bundle8_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-longitudinal-offset-controls/input-3.brep" bundle9
explode bundle9
audit_blend_output before9 bundle9_1
chamf result9 bundle9_1 bundle9_2 .5
audit_blend_output after9 bundle9_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-longitudinal-offset-controls/input-3.brep" bundle10
explode bundle10
audit_blend_output before10 bundle10_1
chamf result10 bundle10_1 bundle10_2 bundle10_3 .7 1.5
audit_blend_output after10 bundle10_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-longitudinal-offset-controls/input-3.brep" bundle11
explode bundle11
audit_blend_output before11 bundle11_1
chamf result11 bundle11_1 bundle11_2 bundle11_4 1.5 .7
audit_blend_output after11 bundle11_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-longitudinal-offset-controls/input-4.brep" bundle12
explode bundle12
audit_blend_output before12 bundle12_1
chamf result12 bundle12_1 bundle12_2 .5
audit_blend_output after12 bundle12_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-longitudinal-offset-controls/input-4.brep" bundle13
explode bundle13
audit_blend_output before13 bundle13_1
chamf result13 bundle13_1 bundle13_2 bundle13_3 .7 1.5
audit_blend_output after13 bundle13_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-longitudinal-offset-controls/input-4.brep" bundle14
explode bundle14
audit_blend_output before14 bundle14_1
chamf result14 bundle14_1 bundle14_2 bundle14_4 1.5 .7
audit_blend_output after14 bundle14_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-longitudinal-offset-controls/input-5.brep" bundle15
explode bundle15
audit_blend_output before15 bundle15_1
chamf result15 bundle15_1 bundle15_2 .5
audit_blend_output after15 bundle15_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-longitudinal-offset-controls/input-5.brep" bundle16
explode bundle16
audit_blend_output before16 bundle16_1
chamf result16 bundle16_1 bundle16_2 bundle16_3 .7 1.5
audit_blend_output after16 bundle16_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-longitudinal-offset-controls/input-5.brep" bundle17
explode bundle17
audit_blend_output before17 bundle17_1
chamf result17 bundle17_1 bundle17_2 bundle17_4 1.5 .7
audit_blend_output after17 bundle17_1
exit
