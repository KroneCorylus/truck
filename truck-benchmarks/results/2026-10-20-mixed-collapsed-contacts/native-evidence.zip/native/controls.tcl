pload ALL
pload -BlendAudit BLENDAUDIT
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
restore "/home/krone/Development/Pieza_WS/truck/target/native-mixed-collapsed-rims/size12-radius0.5.brep" bundle0
explode bundle0
audit_blend_output before0 bundle0_1
catch {blend result0 bundle0_1 0.5 bundle0_2} error0
audit_blend_output after0 bundle0_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-mixed-collapsed-rims/size12-radius1.brep" bundle1
explode bundle1
audit_blend_output before1 bundle1_1
catch {blend result1 bundle1_1 1.0 bundle1_2} error1
audit_blend_output after1 bundle1_1
exit
