from pathlib import Path
import json,math,os,subprocess,hashlib
root=Path('target/native-parallel-cylinder-controls');records=[]
for i,p in enumerate(sorted((root/'capture').glob('*.input.json'))):
 source=i//3;mode=['equal','first','second'][i%3];joined=source==2;r1=5.;r2=4. if source==1 else 5.;d=6.;height=10.;D1=.7 if mode=='equal' else .8;D2=.7 if mode=='equal' else .4
 x=(r1*r1-r2*r2+d*d)/(2*d);y=math.sqrt(r1*r1-x*x);sigma=1 if joined else -1
 a=2*math.asin(D1/(2*r1));b=2*math.asin(D2/(2*r2));phi1=math.atan2(y,x)+sigma*a;phi2=math.atan2(y,x-d)-sigma*b
 qa=[r1*math.cos(phi1),r1*math.sin(phi1),0.];qb=[d+r2*math.cos(phi2),r2*math.sin(phi2),0.]
 patch=abs(r1*r1*sigma*a+qa[0]*qb[1]-qa[1]*qb[0]+d*(y-qb[1])+r2*r2*sigma*b)/2
 initial=r1*r1*math.acos(x/r1)+r2*r2*math.acos((d-x)/r2)-d*y
 if joined:initial=math.pi*(r1*r1+r2*r2)-initial
 expected=(initial+(patch if joined else -patch))*height
 prefix=str(p)[:-len('.input.json')];native=json.loads(Path(prefix+'.result.json').read_text());assert native['native_valid'] and native['solids']==1
 measured=json.loads(subprocess.check_output(['target/solid-contact-oracle',prefix+'.result.brep'],env=dict(os.environ,LD_LIBRARY_PATH='target/occt-sdk/usr/lib64'),stderr=subprocess.DEVNULL))[0]
 error=max(min(math.dist(q,v) for v in measured['vertices']) for q in [qa,qb]);volume_error=native['volume']-expected
 unchanged=(root/f'before{i}.result.brep').read_bytes()==(root/f'after{i}.result.brep').read_bytes()
 record=dict(source=source,mode=mode,joined=joined,radius1=r1,radius2=r2,center_distance=d,height=height,chord1=D1,chord2=D2,expected_contacts=[qa,qb],expected_volume=expected,native_volume=native['volume'],volume_error=volume_error,contact_error=error,native_input_unchanged=unchanged,prefix=prefix)
 records.append(record);print(i,mode,'joined',joined,'contact error',error,'volume error',volume_error,'input unchanged',unchanged)
(root/'analysis.json').write_text(json.dumps(records,indent=2)+'\n')
