from pathlib import Path
import sys,json,subprocess,os,shutil,hashlib
root=Path.cwd();sys.path.insert(0,str(root/'audits/fillet-chamfer'))
from run_occt import isolated_display,execute,tcl_word
out=root/'target/native-parallel-cylinder-angles-complete';out.mkdir(exist_ok=False)
for source in range(3):shutil.copyfile(root/f'target/native-parallel-cylinder-controls/input-{source}.brep',out/f'input-{source}.brep')
occt=(root/'../investigations/sequential-holes-2026-10-10/occt').resolve();plugin=root/'target/occt-cone-reference-plugin';sdk=root/'target/occt-sdk/usr/lib64'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
lines=['pload ALL','pload -BlendAudit BLENDAUDIT',f'source {tcl_word(root/"audits/fillet-chamfer/capture/blend_capture.tcl")}'];controls=[]
for source in range(3):
 for side,angle in [(0,30.),(1,30.),(0,45.),(1,45.)]:
  i=len(controls);name=f'bundle{i}'
  request=f'{name}_{3+side} A .7 {angle}'
  lines += [f'restore {tcl_word(out/f"input-{source}.brep")} {name}',f'explode {name}',f'audit_blend_output before{i} {name}_1',f'catch {{chamf result{i} {name}_1 {name}_2 {request}}} error{i}',f'audit_blend_output after{i} {name}_1']
  controls.append(dict(source=source,joined=source==2,radius1=5.,radius2=4. if source==1 else 5.,centers_distance=6.,height=10.,reference=side,chord=.7,angle=angle))
lines.append('exit');script=out/'controls.tcl';script.write_text('\n'.join(lines)+'\n')
with isolated_display(out) as env:
 env.update(LD_LIBRARY_PATH=f'{plugin}:{sdk}',CASROOT=str(occt),CSF_BlendAuditDefaults=str(plugin),CSF_DrawPluginDefaults=str(occt/'src/DrawResources'),DRAWDEFAULT=str(occt/'src/DrawResources/DrawDefault'),CSF_TestScriptsPath=str(occt/'tests'),CSF_ShadersDirectory=str(occt/'src/Shaders'))
 log,code,timeout,elapsed=execute([shutil.which('DRAWEXE'),'-v','-f',str(script)],out,env,120);(out/'controls.log').write_text(log);assert code==0 and not timeout
captures=sorted((out/'capture').glob('*.input.json'));assert len(captures)==len(controls)
for i,(p,c) in enumerate(zip(captures,controls)):
 result_path=p.with_name(p.name.replace('.input.','.result.'));result=json.loads(result_path.read_text()) if result_path.exists() else dict(status='native-construction-failed')
 c['native_input_unchanged']=(out/f'before{i}.result.brep').read_bytes()==(out/f'after{i}.result.brep').read_bytes()
 c.update(prefix=str(p)[:-len('.input.json')],native=result)
(out/'summary.json').write_text(json.dumps(controls,indent=2)+'\n')
print(json.dumps(controls,indent=2))
