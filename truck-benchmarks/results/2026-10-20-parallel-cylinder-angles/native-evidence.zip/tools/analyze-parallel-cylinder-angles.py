from pathlib import Path
import json,math,subprocess,os
raw=Path('target/native-parallel-cylinder-angles-complete');records=json.loads((raw/'summary.json').read_text())
for q in records:
 if not q['native'].get('native_valid'):
  print(q['source'],q['reference'],q['angle'],'native failed');continue
 m=json.loads(subprocess.check_output(['target/solid-contact-oracle',q['prefix']+'.result.brep'],env=dict(os.environ,LD_LIBRARY_PATH='target/occt-sdk/usr/lib64'),stderr=subprocess.DEVNULL))[0]
 r1,r2,d=q['radius1'],q['radius2'],q['centers_distance'];x=(r1*r1-r2*r2+d*d)/(2*d);y=math.sqrt(r1*r1-x*x);radius=[r1,r2][q['reference']];center=[0.,d][q['reference']]
 contacts=[v for v in m['vertices'] if abs(v[2])<1e-8 and abs(math.hypot(v[0]-center,v[1])-radius)<1e-7 and abs(math.dist(v,[x,y,0])-.7)<1e-6]
 assert len(contacts)==1,(q,contacts,m)
 c=contacts[0];others=[v for v in m['vertices'] if abs(v[2])<1e-8 and v[1]>1e-8 and math.dist(v,c)>1e-6 and math.dist(v,[x,y,0])>1e-6];assert len(others)==1,(q,others)
 other=others[0];delta=[other[j]-c[j] for j in range(2)];length=math.hypot(*delta);n=[delta[1]/length,-delta[0]/length,0.]
 angle=math.degrees(math.acos(min(1,abs((n[0]*(c[0]-center)+n[1]*c[1])/radius))))
 q.update(measurement=m,reference_contact=c,contact_angle=angle)
 print(q['source'],q['reference'],q['angle'],'actual',angle,'native immutable',q['native_input_unchanged'])
(raw/'analysis.json').write_text(json.dumps(records,indent=2)+'\n')
