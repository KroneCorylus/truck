pload ALL
pload -BlendAudit BLENDAUDIT
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
restore "/home/krone/Development/Pieza_WS/truck/target/native-parallel-cylinder-angles-complete/input-0.brep" bundle0
explode bundle0
audit_blend_output before0 bundle0_1
catch {chamf result0 bundle0_1 bundle0_2 bundle0_3 A .7 30.0} error0
audit_blend_output after0 bundle0_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-parallel-cylinder-angles-complete/input-0.brep" bundle1
explode bundle1
audit_blend_output before1 bundle1_1
catch {chamf result1 bundle1_1 bundle1_2 bundle1_4 A .7 30.0} error1
audit_blend_output after1 bundle1_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-parallel-cylinder-angles-complete/input-0.brep" bundle2
explode bundle2
audit_blend_output before2 bundle2_1
catch {chamf result2 bundle2_1 bundle2_2 bundle2_3 A .7 45.0} error2
audit_blend_output after2 bundle2_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-parallel-cylinder-angles-complete/input-0.brep" bundle3
explode bundle3
audit_blend_output before3 bundle3_1
catch {chamf result3 bundle3_1 bundle3_2 bundle3_4 A .7 45.0} error3
audit_blend_output after3 bundle3_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-parallel-cylinder-angles-complete/input-1.brep" bundle4
explode bundle4
audit_blend_output before4 bundle4_1
catch {chamf result4 bundle4_1 bundle4_2 bundle4_3 A .7 30.0} error4
audit_blend_output after4 bundle4_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-parallel-cylinder-angles-complete/input-1.brep" bundle5
explode bundle5
audit_blend_output before5 bundle5_1
catch {chamf result5 bundle5_1 bundle5_2 bundle5_4 A .7 30.0} error5
audit_blend_output after5 bundle5_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-parallel-cylinder-angles-complete/input-1.brep" bundle6
explode bundle6
audit_blend_output before6 bundle6_1
catch {chamf result6 bundle6_1 bundle6_2 bundle6_3 A .7 45.0} error6
audit_blend_output after6 bundle6_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-parallel-cylinder-angles-complete/input-1.brep" bundle7
explode bundle7
audit_blend_output before7 bundle7_1
catch {chamf result7 bundle7_1 bundle7_2 bundle7_4 A .7 45.0} error7
audit_blend_output after7 bundle7_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-parallel-cylinder-angles-complete/input-2.brep" bundle8
explode bundle8
audit_blend_output before8 bundle8_1
catch {chamf result8 bundle8_1 bundle8_2 bundle8_3 A .7 30.0} error8
audit_blend_output after8 bundle8_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-parallel-cylinder-angles-complete/input-2.brep" bundle9
explode bundle9
audit_blend_output before9 bundle9_1
catch {chamf result9 bundle9_1 bundle9_2 bundle9_4 A .7 30.0} error9
audit_blend_output after9 bundle9_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-parallel-cylinder-angles-complete/input-2.brep" bundle10
explode bundle10
audit_blend_output before10 bundle10_1
catch {chamf result10 bundle10_1 bundle10_2 bundle10_3 A .7 45.0} error10
audit_blend_output after10 bundle10_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-parallel-cylinder-angles-complete/input-2.brep" bundle11
explode bundle11
audit_blend_output before11 bundle11_1
catch {chamf result11 bundle11_1 bundle11_2 bundle11_4 A .7 45.0} error11
audit_blend_output after11 bundle11_1
exit
