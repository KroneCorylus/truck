from math import pi,sqrt,asin,cos,sin
import json
from pathlib import Path
def volume(bottom,top,height,r,n,concave):
 k=1-pi/4;slope=(top-bottom)/height;h=height-r
 sign=-1 if concave else 1;sector=3 if concave else 1
 lower=sector*pi/4*(bottom*bottom*h+bottom*slope*h*h+slope*slope*h*h*h/3)-sign*k*r*r*h
 def section(theta):
  rho=r*cos(theta);a=r-rho;radius=bottom+slope*(h+r*sin(theta))
  area=sector*pi*radius*radius/4-radius*radius*asin(a/radius)-a*sqrt(radius*radius-a*a)+sign*a*a+(k*(r+a)**2 if concave else -k*rho*rho)
  return area*r*cos(theta)
 d=pi/2/n
 return lower+d/3*(section(0)+section(pi/2)+sum((4 if i%2 else 2)*section(i*d) for i in range(1,n)))
rows=[]
for name,b,t,h,r,native in [('B1',50,50,100,10,192228.56893742346),('B9',90,40,150,10,517493.93399782863),('B5',50,50,100,10,589069.0945904315),('C4',90,40,150,10,1568360.9536367483)]:
 values=[volume(b,t,h,r,n,name in ['B5','C4']) for n in [1024,4096,16384]]
 rows.append(dict(case=name,dimensions=[b,t,h,r],simpson=values,native=native,absolute_error=abs(values[-1]-native)))
Path('target/curved-terminal-volume.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
