#include <BRepPrimAPI_MakeCylinder.hxx>
#include <BRepFilletAPI_MakeFillet.hxx>
#include <BRepAdaptor_Curve.hxx>
#include <BRepGProp.hxx>
#include <BRepCheck_Analyzer.hxx>
#include <BRepClass3d_SolidClassifier.hxx>
#include <BRepTools.hxx>
#include <BRep_Tool.hxx>
#include <BRep_Builder.hxx>
#include <STEPControl_Reader.hxx>
#include <TopExp_Explorer.hxx>
#include <TopoDS.hxx>
#include <GProp_GProps.hxx>
#include <iostream>
#include <iomanip>
#include <cmath>
void report(const char* label,const TopoDS_Shape& shape,double z) {
 GProp_GProps g;BRepGProp::VolumeProperties(shape,g,1e-9,true,false);
 std::cout<<label<<" volume="<<g.Mass()<<" valid="<<BRepCheck_Analyzer(shape).IsValid()<<std::endl;
 double ft=0,et=0,vt=0;
 for(TopExp_Explorer it(shape,TopAbs_FACE);it.More();it.Next()) ft=std::max(ft,BRep_Tool::Tolerance(TopoDS::Face(it.Current())));
 for(TopExp_Explorer it(shape,TopAbs_EDGE);it.More();it.Next()) et=std::max(et,BRep_Tool::Tolerance(TopoDS::Edge(it.Current())));
 for(TopExp_Explorer it(shape,TopAbs_VERTEX);it.More();it.Next()) vt=std::max(vt,BRep_Tool::Tolerance(TopoDS::Vertex(it.Current())));
 std::cout<<" tolerances faces="<<ft<<" edges="<<et<<" vertices="<<vt<<std::endl;
 for(const auto& point:{gp_Pnt(0,0,z),gp_Pnt(1,-1,z),gp_Pnt(-1,-1,z),gp_Pnt(1,1,z),gp_Pnt(0,0,0)}) {
  BRepClass3d_SolidClassifier classifier(shape,point,1e-7);
  std::cout<<" point "<<point.X()<<","<<point.Y()<<","<<point.Z()<<" state="<<classifier.State()<<std::endl;
 }
}
int main(int argc,char** argv) {
 std::cout<<std::setprecision(17);
 auto shape=BRepPrimAPI_MakeCylinder(150,200,1.5*std::acos(-1.)).Shape();
 TopoDS_Edge seed;
 for(TopExp_Explorer it(shape,TopAbs_EDGE);it.More();it.Next()) {
  BRepAdaptor_Curve c(TopoDS::Edge(it.Current()));auto a=c.Value(c.FirstParameter()),b=c.Value(c.LastParameter());
  if(a.X()*a.X()+a.Y()*a.Y()<1e-12 && b.X()*b.X()+b.Y()*b.Y()<1e-12 && a.Distance(b)>199) {seed=TopoDS::Edge(it.Current());break;}
 }
 if(seed.IsNull()) return 2;
 BRepFilletAPI_MakeFillet f(shape);f.SetParams(.01,.0001,.00001,.0001,.00001,.001);f.SetContinuity(GeomAbs_C1,.01);f.Add(10,seed);f.Build();if(!f.IsDone()) return 3;
 report("sector-input",shape,199.99);report("sector-fillet",f.Shape(),199.99);
 std::cout<<"analytic input="<<.75*std::acos(-1.)*150*150*200<<" additive-result="<<.75*std::acos(-1.)*150*150*200+(1-std::acos(-1.)/4)*100*200<<std::endl;
 if(argc==4) {
  BRep_Builder b;TopoDS_Shape input,native;BRepTools::Read(input,argv[1],b);BRepTools::Read(native,argv[2],b);
  STEPControl_Reader r;r.ReadFile(argv[3]);r.TransferRoots();
  report("H4-input",input,99.99);report("H4-native",native,99.99);report("H4-Truck",r.OneShape(),99.99);
 }
}
