#include <BRepTools.hxx>
#include <BRep_Tool.hxx>
#include <BRep_Builder.hxx>
#include <TopoDS.hxx>
#include <TopExp_Explorer.hxx>
#include <iostream>
#include <iomanip>
#include <algorithm>
int main(int argc,char**argv) {
 std::cout<<std::setprecision(17);
 for(int i=1;i<argc;++i) {
  TopoDS_Shape s;BRep_Builder b;if(!BRepTools::Read(s,argv[i],b))return 1;
  double f=0,e=0,v=0;
  for(TopExp_Explorer it(s,TopAbs_FACE);it.More();it.Next())f=std::max(f,BRep_Tool::Tolerance(TopoDS::Face(it.Current())));
  for(TopExp_Explorer it(s,TopAbs_EDGE);it.More();it.Next())e=std::max(e,BRep_Tool::Tolerance(TopoDS::Edge(it.Current())));
  for(TopExp_Explorer it(s,TopAbs_VERTEX);it.More();it.Next())v=std::max(v,BRep_Tool::Tolerance(TopoDS::Vertex(it.Current())));
  std::cout<<argv[i]<<"\t"<<f<<"\t"<<e<<"\t"<<v<<"\n";
 }
}
