from pathlib import Path
import sys,json,shutil,math
root=Path.cwd();sys.path.insert(0,str(root/'audits/fillet-chamfer'))
from run_occt import isolated_display,execute,tcl_word
plugin=(root/sys.argv[1]).resolve();out=(root/sys.argv[2]).resolve();out.mkdir(exist_ok=False)
occt=(root/'../investigations/sequential-holes-2026-10-10/occt').resolve();sdk=root/'target/occt-sdk/usr/lib64';draw=shutil.which('DRAWEXE')
script=out/'control.tcl';script.write_text(f'''pload ALL
pload -BlendAudit BLENDAUDIT
box b 10 20 30
settolerance b f 0.05
settolerance b e 0.1
settolerance b v 0.2
if {{[catch {{audit_blend_output controlled b}} message]}} {{puts $message;exit 2}}
exit
''')
with isolated_display(out) as env:
 env.update(LD_LIBRARY_PATH=f'{plugin}:{sdk}',CASROOT=str(occt),CSF_BlendAuditDefaults=str(plugin),CSF_DrawPluginDefaults=str(occt/'src/DrawResources'),DRAWDEFAULT=str(occt/'src/DrawResources/DrawDefault'),CSF_TestScriptsPath=str(occt/'tests'),CSF_ShadersDirectory=str(occt/'src/Shaders'))
 log,code,timeout,_=execute([draw,'-v','-f',str(script)],out,env,120);(out/'native.log').write_text(log);assert code==0 and not timeout,(code,timeout,log)
 log,code,timeout,_=execute([str(plugin/'compare_shapes'),str(out/'controlled.result.brep'),str(out/'controlled.result.step'),str(out/'comparison.json')],out,env,120);(out/'comparison.log').write_text(log);assert code==0 and not timeout
 result=json.loads((out/'controlled.result.json').read_text());comparison=json.loads((out/'comparison.json').read_text())
 expected=dict(face=.05,edge=.1,vertex=.2)
 assert result.get('stored_tolerances')==expected,result
 assert comparison.get('native_tolerances')==expected,comparison
 assert result['native_valid'] and result['solids']==1 and abs(result['volume']-6000)<1e-9
 assert comparison['native_valid'] and comparison['truck_step_valid']
 assert comparison['native_solids']==comparison['truck_solids']==1
 assert max(comparison['native_to_truck_max_distance'],comparison['truck_to_native_max_distance'])<1e-12
 assert set(comparison['truck_step_tolerances'])==set(expected)
 assert all(math.isfinite(v) and v>=0 for v in comparison['truck_step_tolerances'].values())
 print(json.dumps(dict(result=result,comparison=comparison),indent=2))
 print('Stored tolerance budgets remain separate from validity and measured boundary difference')
