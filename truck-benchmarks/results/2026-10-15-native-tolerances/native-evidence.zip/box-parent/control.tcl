pload ALL
pload -BlendAudit BLENDAUDIT
box b 10 20 30
settolerance b f 0.05
settolerance b e 0.1
settolerance b v 0.2
if {[catch {audit_blend_output controlled b} message]} {puts $message;exit 2}
exit
