#include <BRepAdaptor_Curve.hxx>
#include <BRepAdaptor_Surface.hxx>
#include <BRepBuilderAPI_MakeEdge.hxx>
#include <BRepBuilderAPI_MakeFace.hxx>
#include <BRepBuilderAPI_MakeWire.hxx>
#include <BRepPrimAPI_MakePrism.hxx>
#include <BRepPrimAPI_MakeBox.hxx>
#include <BRepPrimAPI_MakeCylinder.hxx>
#include <BRepAlgoAPI_Cut.hxx>
#include <BRepCheck_Analyzer.hxx>
#include <BRepGProp.hxx>
#include <BRepTools.hxx>
#include <BRep_Builder.hxx>
#include <GProp_GProps.hxx>
#include <TopExp.hxx>
#include <TopExp_Explorer.hxx>
#include <TopoDS.hxx>
#include <TopoDS_Compound.hxx>
#include <gp_Circ.hxx>
#include <cmath>
#include <iostream>
#include <iomanip>
#include <stdexcept>
#include <string>
#include <BRepAlgoAPI_Common.hxx>
#include <BRepAlgoAPI_Fuse.hxx>
int main(int argc,char**argv) {
 if(argc!=2)return 1;
 auto solid=BRepPrimAPI_MakeBox(1.,1.,1.).Shape();
 TopoDS_Edge xz,xy,yz;TopoDS_Face refx,refy;
 for(TopExp_Explorer it(solid,TopAbs_FACE);it.More();it.Next()) {
  auto face=TopoDS::Face(it.Current());BRepAdaptor_Surface surface(face);auto plane=surface.Plane();auto n=plane.Axis().Direction();auto o=plane.Location();
  if(std::abs(std::abs(n.X())-1)<1e-8&&std::abs(o.X())<1e-8)refx=face;
  if(std::abs(std::abs(n.Y())-1)<1e-8&&std::abs(o.Y()-1)<1e-8)refy=face;
  for(TopExp_Explorer edges(face,TopAbs_EDGE);edges.More();edges.Next()) {
   auto edge=TopoDS::Edge(edges.Current());BRepAdaptor_Curve curve(edge);auto p=curve.Value((curve.FirstParameter()+curve.LastParameter())/2);
   if(std::abs(p.X())<1e-8&&std::abs(p.Z()-1)<1e-8)xz=edge;
   if(std::abs(p.X())<1e-8&&std::abs(p.Y()-1)<1e-8)xy=edge;
   if(std::abs(p.Y()-1)<1e-8&&std::abs(p.Z()-1)<1e-8)yz=edge;
  }
 }
 if(xz.IsNull()||xy.IsNull()||yz.IsNull()||refx.IsNull()||refy.IsNull())throw std::runtime_error("missing selection");
 TopoDS_Compound bundle;BRep_Builder builder;builder.MakeCompound(bundle);builder.Add(bundle,solid);builder.Add(bundle,xz);builder.Add(bundle,xy);builder.Add(bundle,yz);builder.Add(bundle,refx);builder.Add(bundle,refy);
 if(!BRepTools::Write(bundle,(std::string(argv[1])+"/input.brep").c_str()))return 1;
}
