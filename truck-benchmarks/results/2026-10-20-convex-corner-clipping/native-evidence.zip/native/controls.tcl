pload ALL
pload -BlendAudit BLENDAUDIT
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
restore "/home/krone/Development/Pieza_WS/truck/target/native-convex-corner-clip/input.brep" bundle0
explode bundle0
audit_blend_output before0 bundle0_1
catch {chamf result0 bundle0_1 bundle0_2 0.08 bundle0_3 0.08 bundle0_4 0.08} error0
audit_blend_output after0 bundle0_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-convex-corner-clip/input.brep" bundle1
explode bundle1
audit_blend_output before1 bundle1_1
catch {chamf result1 bundle1_1 bundle1_2 0.3 bundle1_3 0.08 bundle1_4 0.08} error1
audit_blend_output after1 bundle1_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-convex-corner-clip/input.brep" bundle2
explode bundle2
audit_blend_output before2 bundle2_1
catch {chamf result2 bundle2_1 bundle2_2 0.08 bundle2_3 0.3 bundle2_4 0.08} error2
audit_blend_output after2 bundle2_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-convex-corner-clip/input.brep" bundle3
explode bundle3
audit_blend_output before3 bundle3_1
catch {chamf result3 bundle3_1 bundle3_2 0.08 bundle3_3 0.08 bundle3_4 0.3} error3
audit_blend_output after3 bundle3_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-convex-corner-clip/input.brep" bundle4
explode bundle4
audit_blend_output before4 bundle4_1
catch {chamf result4 bundle4_1 bundle4_2 bundle4_5 A 0.08 40.0 bundle4_3 bundle4_5 A 0.2 30.0 bundle4_4 bundle4_6 A 0.1 30.0} error4
audit_blend_output after4 bundle4_1
exit
