use super::fixtures::*;
use divan::{black_box, Bencher};
use truck_meshalgo::prelude::*;

#[divan::bench(args = [0.1, 0.01, 0.001])]
fn cylinder_tolerance(bencher: Bencher, tol: f64) {
    let solid = cylinder();
    let run = || black_box(&solid).triangulation(black_box(tol));
    assert!(run().face_iter().all(|f| f.surface().is_some()));
    bencher.bench(run);
}

#[divan::bench(args = [1, 10, 30, 100])]
fn plate(bencher: Bencher, holes: usize) {
    let solid = perforated_plate(holes);
    check_volume(&solid, plate_volume(holes));
    bencher.bench(|| black_box(&solid).triangulation(TOL));
}

#[divan::bench(args = HOLES)]
fn mesh_to_polygon(bencher: Bencher, holes: usize) {
    let mesh = perforated_plate(holes).triangulation(TOL);
    assert!(mesh.face_iter().all(|f| f.surface().is_some()));
    assert!(!mesh.to_polygon().positions().is_empty());
    bencher.bench(|| black_box(&mesh).to_polygon());
}

#[divan::bench(sample_count = 3, sample_size = 1)]
fn anisotropic_fillet_cap(bencher: Bencher) {
    let shell = truck_modeling::Shell::extract(
        serde_json::from_str(include_str!(
            "../../truck-meshalgo/tests/fillet-cap-face.json"
        ))
        .unwrap(),
    )
    .unwrap();
    bencher.bench(|| black_box(&shell).triangulation(black_box(0.0003)));
}

#[divan::bench(sample_count = 7, sample_size = 1)]
fn sphere_pole_tessellation(bencher: Bencher) {
    use truck_modeling::*;
    let solid = Solid::extract(
        serde_json::from_str(include_str!(
            "../../truck-shapeops/tests/contact-revolved-sphere.json"
        ))
        .unwrap(),
    )
    .unwrap();
    assert!(solid.is_geometric_consistent());
    let tolerance = 0.001;
    let tessellation = solid.robust_triangulation(tolerance);
    for (face, tessellated) in solid.face_iter().zip(tessellation.face_iter()) {
        let mesh = tessellated.surface().unwrap();
        for triangle in mesh.tri_faces() {
            let points = triangle.map(|vertex| mesh.positions()[vertex.pos]);
            let area = (points[1] - points[0]).cross(points[2] - points[0]);
            let normal = triangle.iter().fold(Vector3::zero(), |sum, vertex| {
                let uv = mesh.uv_coords()[vertex.uv.unwrap()];
                assert!(mesh.positions()[vertex.pos].near(&face.surface().subs(uv.x, uv.y)));
                sum + mesh.normals()[vertex.nor.unwrap()]
            });
            let uv = triangle.map(|vertex| mesh.uv_coords()[vertex.uv.unwrap()]);
            assert!((uv[1] - uv[0]).perp_dot(uv[2] - uv[0]) >= 0.);
            let longest = (0..3)
                .map(|i| points[i].distance(points[(i + 1) % 3]))
                .fold(0.0, f64::max);
            // Near a collapsed pole, parameter winding is the reliable orientation.
            if area.magnitude() > TOLERANCE * longest {
                assert!(
                    area.dot(normal) >= -TOLERANCE * area.magnitude() * normal.magnitude(),
                    "nondegenerate facet opposes its surface normals: area={area:?}, normal={normal:?}, longest={longest}"
                );
            }
        }
    }
    let mut mesh = tessellation.to_polygon();
    mesh.put_together_same_attrs(TOLERANCE)
        .remove_degenerate_faces()
        .remove_unused_attrs();
    assert_eq!(mesh.shell_condition(), ShellCondition::Closed);
    assert!(
        (mesh.volume().abs() - 4. * std::f64::consts::PI / 3.).abs()
            < 4. * std::f64::consts::PI * tolerance
    );
    bencher.bench(|| black_box(&solid).robust_triangulation(black_box(tolerance)));
}

#[divan::bench(sample_count = 3, sample_size = 1)]
fn physical_extrusion_cap_accuracy(bencher: Bencher) {
    let shell = truck_modeling::Shell::extract(
        serde_json::from_str(include_str!(
            "../../truck-meshalgo/tests/extrusion-cap-balanced-003.json"
        ))
        .unwrap(),
    )
    .unwrap();
    bencher.bench(|| black_box(&shell).triangulation(black_box(0.0003)));
}

#[divan::bench(args = [0.05, 0.01, 0.001], sample_count = 7, sample_size = 1)]
fn thin_curved_loft(bencher: Bencher, tolerance: f64) {
    use truck_modeling::*;
    let wires = [(2., 0.), (2., 10.), (4., 20.)].map(|(x, z)| {
        let center = Point3::new(x, 0., z);
        let radial = Vector3::new(0.2 * 0.1_f64.cos(), 0.2 * 0.1_f64.sin(), 0.);
        builder::rsweep(
            &builder::vertex(center + radial),
            center,
            Vector3::unit_z(),
            Rad(2. * std::f64::consts::PI),
            4,
        )
    });
    let solid: Solid = builder::try_loft(&builder::align_sections(&wires)).unwrap();
    assert!(solid.is_geometric_consistent());
    for face in solid.face_iter() {
        let surface = face.surface();
        if matches!(surface, Surface::Plane(_)) {
            continue;
        }
        let (u_range, v_range) = surface.try_range_tuple();
        let ((u0, u1), (v0, v1)) = (u_range.unwrap(), v_range.unwrap());
        for u in [0.25, 0.5, 0.75] {
            for v in [0.25, 0.5, 0.75] {
                let point = surface.subs(u0 + u * (u1 - u0), v0 + v * (v1 - v0));
                assert!(loft_benchmark_radial_error(point) < 1.0e-8);
            }
        }
    }
    let before = serde_json::to_string(&solid.compress()).unwrap();
    loft_benchmark_check(
        solid.robust_triangulation(tolerance).to_polygon(),
        tolerance,
    );
    loft_benchmark_check(
        solid
            .compress()
            .robust_triangulation(tolerance)
            .to_polygon(),
        tolerance,
    );
    assert_eq!(before, serde_json::to_string(&solid.compress()).unwrap());
    bencher.bench(|| black_box(&solid).robust_triangulation(black_box(tolerance)));
}

fn loft_benchmark_check(mut mesh: PolygonMesh, tolerance: f64) {
    mesh.put_together_same_attrs(TOLERANCE)
        .remove_degenerate_faces()
        .remove_unused_attrs();
    assert_eq!(
        mesh.shell_condition(),
        ShellCondition::Closed,
        "tol={tolerance}"
    );
    assert!(
        (mesh.volume() - 0.8 * std::f64::consts::PI).abs() < 0.03,
        "{}",
        mesh.volume()
    );
    if tolerance != 0.05 {
        return;
    }
    for triangle in mesh.tri_faces() {
        let points = triangle.map(|v| mesh.positions()[v.pos]);
        let [x, y, z] = points;
        for point in [
            x + (y - x) / 2.,
            y + (z - y) / 2.,
            z + (x - z) / 2.,
            x + (y + (z - y) / 2. - x) * (2. / 3.),
        ] {
            if point.z <= TOLERANCE || point.z >= 20. - TOLERANCE {
                continue;
            }
            assert!(
                loft_benchmark_radial_error(point) <= tolerance,
                "tol={tolerance}, error={}",
                loft_benchmark_radial_error(point)
            );
        }
    }
}

// The three equally sized circles interpolate a quadratic centerline with chord parameters.
// A point at the same z and polar angle on that circle gives a distance upper bound.
fn loft_benchmark_radial_error(point: truck_modeling::Point3) -> f64 {
    let p = 10. / (10. + 104_f64.sqrt());
    let a = (20. * p - 10.) / (p - p * p);
    let b = 20. - a;
    let t = 2. * point.z / (b + (b * b + 4. * a * point.z).sqrt());
    let center = 2. + 2. * t * (t - p) / (1. - p);
    (((point.x - center).powi(2) + point.y.powi(2)).sqrt() - 0.2).abs()
}
