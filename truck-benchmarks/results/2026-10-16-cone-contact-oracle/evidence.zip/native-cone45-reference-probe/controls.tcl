pload ALL
pload -BlendAudit BLENDAUDIT
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
restore "/home/krone/Development/Pieza_WS/truck/target/native-cone45-reference-probe/input-0.brep" bundle0
explode bundle0
audit_blend_output before0 bundle0_1
chamf result0 bundle0_1 bundle0_2 bundle0_3 0.3 0.7
audit_blend_output after0 bundle0_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-cone45-reference-probe/input-0.brep" bundle1
explode bundle1
audit_blend_output before1 bundle1_1
chamf result1 bundle1_1 bundle1_2 bundle1_3 A 0.3 30
audit_blend_output after1 bundle1_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-cone45-reference-probe/input-0.brep" bundle2
explode bundle2
audit_blend_output before2 bundle2_1
chamf result2 bundle2_1 bundle2_2 bundle2_4 0.3 0.7
audit_blend_output after2 bundle2_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-cone45-reference-probe/input-0.brep" bundle3
explode bundle3
audit_blend_output before3 bundle3_1
chamf result3 bundle3_1 bundle3_2 bundle3_4 A 0.3 30
audit_blend_output after3 bundle3_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-cone45-reference-probe/input-1.brep" bundle4
explode bundle4
audit_blend_output before4 bundle4_1
chamf result4 bundle4_1 bundle4_2 bundle4_3 0.3 0.7
audit_blend_output after4 bundle4_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-cone45-reference-probe/input-1.brep" bundle5
explode bundle5
audit_blend_output before5 bundle5_1
chamf result5 bundle5_1 bundle5_2 bundle5_3 A 0.3 30
audit_blend_output after5 bundle5_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-cone45-reference-probe/input-1.brep" bundle6
explode bundle6
audit_blend_output before6 bundle6_1
chamf result6 bundle6_1 bundle6_2 bundle6_4 0.3 0.7
audit_blend_output after6 bundle6_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-cone45-reference-probe/input-1.brep" bundle7
explode bundle7
audit_blend_output before7 bundle7_1
chamf result7 bundle7_1 bundle7_2 bundle7_4 A 0.3 30
audit_blend_output after7 bundle7_1
exit
