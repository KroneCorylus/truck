from pathlib import Path
import subprocess,os,json,hashlib,re
out=Path('truck-benchmarks/results/2026-10-20-longitudinal-cylinder-angles');env=dict(os.environ,CARGO_BUILD_JOBS='12')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
parent=json.loads((out/'parent.json').read_text())
regression=Path('truck-shapeops/examples/replay_occt_blend.rs').read_text().split('mod longitudinal_plane_angle_tests',1)[1]
assert hashlib.sha256(('mod longitudinal_plane_angle_tests'+regression).encode()).hexdigest()==parent['test_module_sha256']
previous=json.loads(Path('truck-benchmarks/results/2026-10-16-conic-contact-extension/validation.json').read_text())
for p,h in previous['source_sha256'].items():
 if not p.startswith('truck-shapeops/examples/'):assert sha(p)==h,p
assert '4 passed; 3 failed' in (out/'parent-failure.txt').read_text()
assert '49 passed; 0 failed' in (out/'replay-tests.txt').read_text()
source={str(p):sha(p) for base in ['truck-shapeops/src','truck-shapeops/tests','truck-shapeops/examples','truck-meshalgo/src','truck-meshalgo/tests'] for p in Path(base).rglob('*.rs')}
m=dict(parent_revision=parent['revision'],source_sha256=source)
(out/'validation-start.json').write_text(json.dumps(m,indent=2)+'\n')
for name,cmd in [
 ('capture-tests.txt',['python3','-m','unittest','discover','-s','audits/fillet-chamfer/capture','-p','test_*.py']),
 ('clippy.txt',['cargo','clippy','--release','-p','truck-stepio','-p','truck-shapeops','-p','truck-benchmarks','--all-targets']),
 ('actions-smoke.txt',['cargo','bench','-p','truck-benchmarks','--bench','actions','--','--test']),
 ('replay-build.txt',['cargo','build','--release','-p','truck-shapeops','--example','replay_occt_blend'])]:
 with (out/name).open('w') as log:
  log.write('$ '+' '.join(cmd)+'\n');log.flush();r=subprocess.run(cmd,env=dict(env,RAYON_NUM_THREADS='1') if name=='actions-smoke.txt' else env,stdout=log,stderr=subprocess.STDOUT);log.write(f'exit_code {r.returncode}\n');assert r.returncode==0,name
 print(name,'passed',flush=True)
for p,h in source.items():assert sha(p)==h,p
counts=[tuple(previous['shapeops_counts'])]
m['meshalgo_counts']=previous['meshalgo_counts']
m['core_validation_reused_from']='2026-10-16-conic-contact-extension; production core and integration tests byte-identical'
m.update(shapeops_counts=list(map(sum,zip(*counts))),replay_tests=49,replay_sha256=sha('target/release/examples/replay_occt_blend'))
assert '49 passed; 0 failed' in (out/'replay-tests.txt').read_text()
for p in out.glob('*.txt'):p.write_text('\n'.join(line.rstrip() for line in p.read_text().splitlines()).rstrip()+'\n')
m['log_sha256']={p.name:sha(p) for p in out.glob('*.txt')}
(out/'validation.json').write_text(json.dumps(m,indent=2)+'\n')
print('Validation complete',m['shapeops_counts'],flush=True)
