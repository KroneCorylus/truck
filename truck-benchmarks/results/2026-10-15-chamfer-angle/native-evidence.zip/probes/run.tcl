pload ALL; pload -BlendAudit BLENDAUDIT
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
source "/home/krone/Development/Pieza_WS/truck/truck-benchmarks/results/2026-10-15-chamfer-angle/probes.tcl"
exit
