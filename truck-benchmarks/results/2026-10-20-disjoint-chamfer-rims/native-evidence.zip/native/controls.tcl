pload ALL
pload -BlendAudit BLENDAUDIT
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
restore "/home/krone/Development/Pieza_WS/truck/target/native-disjoint-rims/quarter.brep" bundle0
explode bundle0
audit_blend_output before0 bundle0_1
catch {chamf result0 bundle0_1 bundle0_2 0.7 bundle0_3 0.7} error0
audit_blend_output after0 bundle0_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-disjoint-rims/quarter.brep" bundle1
explode bundle1
audit_blend_output before1 bundle1_1
catch {chamf result1 bundle1_1 bundle1_2 bundle1_4 0.7 0.5 bundle1_3 bundle1_5 0.7 0.5} error1
audit_blend_output after1 bundle1_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-disjoint-rims/quarter.brep" bundle2
explode bundle2
audit_blend_output before2 bundle2_1
catch {chamf result2 bundle2_1 bundle2_2 bundle2_4 A 0.7 30 bundle2_3 bundle2_5 A 0.7 30} error2
audit_blend_output after2 bundle2_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-disjoint-rims/quarter.brep" bundle3
explode bundle3
audit_blend_output before3 bundle3_1
catch {chamf result3 bundle3_1 bundle3_2 bundle3_4 0.7 0.5 bundle3_3 bundle3_5 0.4 0.3} error3
audit_blend_output after3 bundle3_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-disjoint-rims/full.brep" bundle4
explode bundle4
audit_blend_output before4 bundle4_1
catch {chamf result4 bundle4_1 bundle4_2 0.7 bundle4_3 0.7} error4
audit_blend_output after4 bundle4_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-disjoint-rims/full.brep" bundle5
explode bundle5
audit_blend_output before5 bundle5_1
catch {chamf result5 bundle5_1 bundle5_2 bundle5_4 0.7 0.5 bundle5_3 bundle5_5 0.7 0.5} error5
audit_blend_output after5 bundle5_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-disjoint-rims/full.brep" bundle6
explode bundle6
audit_blend_output before6 bundle6_1
catch {chamf result6 bundle6_1 bundle6_2 bundle6_4 A 0.7 30 bundle6_3 bundle6_5 A 0.7 30} error6
audit_blend_output after6 bundle6_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-disjoint-rims/full.brep" bundle7
explode bundle7
audit_blend_output before7 bundle7_1
catch {chamf result7 bundle7_1 bundle7_2 bundle7_4 0.7 0.5 bundle7_3 bundle7_5 0.4 0.3} error7
audit_blend_output after7 bundle7_1
exit
