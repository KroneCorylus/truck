#include <BRepAdaptor_Curve.hxx>
#include <BRepAdaptor_Surface.hxx>
#include <BRepPrimAPI_MakeCylinder.hxx>
#include <BRepCheck_Analyzer.hxx>
#include <BRepTools.hxx>
#include <BRep_Builder.hxx>
#include <TopExp_Explorer.hxx>
#include <TopoDS.hxx>
#include <TopoDS_Compound.hxx>
#include <cmath>
#include <stdexcept>
#include <string>
int main(int argc,char**argv) {
 if(argc!=2)return 1;
 for(bool full:{false,true}) {
  auto solid=full?BRepPrimAPI_MakeCylinder(5.,10.).Shape():BRepPrimAPI_MakeCylinder(5.,10.,std::acos(-1.)/2).Shape();
  if(!BRepCheck_Analyzer(solid).IsValid())throw std::runtime_error("invalid solid");
  TopoDS_Edge top,bottom;TopoDS_Face topface,bottomface;
  for(TopExp_Explorer it(solid,TopAbs_FACE);it.More();it.Next()) {
   auto face=TopoDS::Face(it.Current());BRepAdaptor_Surface surface(face);
   if(surface.GetType()!=GeomAbs_Plane||std::abs(std::abs(surface.Plane().Axis().Direction().Z())-1)>1e-8)continue;
   bool upper=surface.Plane().Location().Z()>5;
   for(TopExp_Explorer edges(face,TopAbs_EDGE);edges.More();edges.Next()) {
    auto edge=TopoDS::Edge(edges.Current());BRepAdaptor_Curve curve(edge);
    if(curve.GetType()==GeomAbs_Circle) {if(upper){top=edge;topface=face;}else{bottom=edge;bottomface=face;}}
   }
  }
  if(top.IsNull()||bottom.IsNull())throw std::runtime_error("missing rim");
  TopoDS_Compound bundle;BRep_Builder builder;builder.MakeCompound(bundle);builder.Add(bundle,solid);builder.Add(bundle,top);builder.Add(bundle,bottom);builder.Add(bundle,topface);builder.Add(bundle,bottomface);
  if(!BRepTools::Write(bundle,(std::string(argv[1])+(full?"/full.brep":"/quarter.brep")).c_str()))return 1;
 }
}
