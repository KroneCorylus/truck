import math,json
k=.4
records=[]
for cap,wall in [(.1,.1),(.1,.06),(.06,.1)]:
 def section(l):
  r=l*wall;lo=0.;hi=k
  for _ in range(64):
   u=(lo+hi)/2
   if u/(2*k)+r*u/math.sqrt(1+u*u)<.5:lo=u
   else:hi=u
  u=(lo+hi)/2;g=math.sqrt(1+u*u)
  return 2*(r*(u*g+math.asinh(u))/(4*k)+r*r*(u+math.atan(u))/2+k*r**3*u**3/(3*g**3))
 values=[]
 for n in [128,256,512,1024]:
  integral=(section(0)+section(1)+sum((4 if i%2 else 2)*section(i/n) for i in range(1,n)))/(3*n)
  values.append(1+k/12-cap*integral)
 assert abs(values[-1]-values[-2])<1e-12
 records.append(dict(cap=cap,wall=wall,retained_volume=values[-1],convergence=values))
print(json.dumps(records,indent=2))
