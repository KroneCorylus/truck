from pathlib import Path
import json,subprocess,os,hashlib
root=Path.cwd();native=json.loads(Path('target/native-parabolic-chamfer/summary.json').read_text());expected=json.loads(Path('target/parabolic-chamfer-volume.json').read_text());rows=[]
for i,(n,e) in enumerate(zip(native,expected)):
 assert n['valid'] and n['input_unchanged'];assert abs(n['input_volume']-(1+.4/12))<1e-12;assert abs(n['volume']-e['retained_volume'])<1e-6
 row=dict(index=i,cap=e['cap'],wall=e['wall'],expected_volume=e['retained_volume'],native=n)
 for label in ['input','result']:
  output=Path(f'target/truck-parabolic-chamfer/{i}.{label}.comparison.json')
  with output.with_suffix('.log').open('w') as log:subprocess.run(['target/occt-span-volume-plugin/compare_shapes',f'target/native-parabolic-chamfer/{i}.{label}.brep',f'target/truck-parabolic-chamfer/{i}.{label}.step',str(output)],stdout=log,stderr=subprocess.STDOUT,env=dict(os.environ,LD_LIBRARY_PATH=str(root/'target/occt-sdk/usr/lib64')),check=True,timeout=120)
  q=json.loads(output.read_text());row[label]=q
  assert q['native_valid'] and q['truck_step_valid'] and q['native_solids']==q['truck_solids']==1
  assert max(q['native_to_truck_max_distance'],q['truck_to_native_max_distance'])<.001
  assert abs(q['truck_volume']-((1+.4/12) if label=='input' else e['retained_volume']))<1e-6
 rows.append(row);print(i,'distance',max(row['result'][k] for k in ['native_to_truck_max_distance','truck_to_native_max_distance']),'volume error',abs(row['result']['truck_volume']-e['retained_volume']),flush=True)
Path('target/parabolic-chamfer-comparisons.json').write_text(json.dumps(rows,indent=2)+'\n')
