from math import pi,sqrt,cos,sin,asin
from pathlib import Path
import json
R=150.;r=10.;top=R*sqrt(3)/2;k=1-pi/4
base=pi/4*(R*R*(top+R)-(top**3+R**3)/3)
def vertical(t):
 x=r*(1-cos(t));y=r*(1-sin(t));a=R*R-x*x
 height=top*y+.5*(y*sqrt(a-y*y)+a*asin(y/sqrt(a)))
 return height*r*sin(t)
def top_cut(t):
 rho=r*cos(t);a=r-rho;z=top-r+r*sin(t);outer=sqrt(R*R-z*z)
 return (outer*outer*asin(a/outer)+a*sqrt(outer*outer-a*a)-a*a-k*r*r+k*rho*rho)*r*cos(t)
values=[]
for n in [1024,4096,16384]:
 d=pi/2/n
 def integral(f):return d/3*(f(0)+f(pi/2)+sum((4 if i%2 else 2)*f(i*d) for i in range(1,n)))
 values.append(base-integral(vertical)-integral(top_cut))
native=json.loads(Path('target/occt-capture-spline-pcurves/blend/simple/E2/capture/001.result.json').read_text())['volume']
row=dict(case='E2',sphere_radius=R,top_height=top,fillet_radius=r,input_volume=base,simpson=values,native_volume=native,native_absolute_difference=abs(native-values[-1]))
Path('target/polar-terminal-volume.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row,indent=2))
