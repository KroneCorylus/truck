import math,json
from pathlib import Path
out=[]
for name,alpha in [('B3',math.pi/2),('B7',3*math.pi/2)]:
 R,H,r=50.,100.,10.;A=R-r;theta=math.asin(r/A);x=math.sqrt(A*A-r*r)
 def area(rho):
  a=r-rho;outer=A+rho
  return .5*(-a*x+x*rho*(math.sin(theta)+1)-r*rho*math.cos(theta)+rho*rho*(theta+math.pi/2)+outer*outer*(alpha-theta))
 def f(t):return area(r*math.cos(t))*r*math.cos(t)
 values=[]
 for n in [1024,4096,16384]:
  d=math.pi/2/n;values.append((H-r)*area(r)+d/3*(f(0)+f(math.pi/2)+sum((2 if i%2==0 else 4)*f(i*d) for i in range(1,n))))
 native=json.loads(Path(f'target/occt-capture-curved-terminals/blend/simple/{name}/capture/001.result.json').read_text())['volume']
 out.append(dict(case=name,outer_radius=R,height=H,fillet_radius=r,sector_angle=alpha,simpson=values,native_volume=native,absolute_error=abs(values[-1]-native)))
Path('target/cylindrical-corner-volume.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
