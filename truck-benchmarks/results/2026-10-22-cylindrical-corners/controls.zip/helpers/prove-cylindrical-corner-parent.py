from pathlib import Path
import subprocess,os,json,hashlib,shutil
root=Path.cwd();parent=root/'target/cylindrical-corner-parent-source';out=root/'truck-benchmarks/results/2026-10-22-cylindrical-corners';out.mkdir(exist_ok=True)
revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=parent,text=True).strip()==revision
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
files=['truck-shapeops/tests/cylindrical_corner_junctions.rs','truck-shapeops/examples/replay_occt_blend.rs']+[str(p) for p in Path('truck-shapeops/tests/fixtures/cylindrical-corner-junctions').glob('*')]
for name in files:
 (parent/name).parent.mkdir(exist_ok=True,parents=True);shutil.copyfile(root/name,parent/name)
shutil.copyfile(root/'Cargo.lock',parent/'Cargo.lock')
env=os.environ|{'CARGO_BUILD_JOBS':'12','CARGO_TARGET_DIR':str(root/'target')}
with (out/'parent-clean.txt').open('w') as f:subprocess.run(['cargo','clean','--release','-p','truck-shapeops'],cwd=parent,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
for name,args,expected in [('parent-tests.txt',['--test','cylindrical_corner_junctions'],'1 passed; 1 failed'),('parent-replay-tests.txt',['--example','replay_occt_blend','native_cylindrical_corners'],'0 passed; 1 failed')]:
 cmd=['cargo','test','--release','-p','truck-shapeops']+args
 with (out/name).open('w') as f:
  f.write('$ '+' '.join(cmd)+'\n');f.flush();r=subprocess.run(cmd,cwd=parent,env=env,stdout=f,stderr=subprocess.STDOUT);f.write(f'exit_code {r.returncode}\n')
 assert r.returncode==101,name;assert expected in (out/name).read_text(),name
 print(name,'expected failure confirmed',flush=True)
(out/'parent.json').write_text(json.dumps(dict(revision=revision,test_sha256={name:sha(root/name) for name in files},parent_test_sha256={name:sha(parent/name) for name in files},binding_change=None),indent=2)+'\n');print('Parent proof complete',flush=True)
