pload ALL
pload -BlendAudit BLENDAUDIT
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
restore "/home/krone/Development/Pieza_WS/truck/target/native-shared-cone-fillet/input.brep" bundle
explode bundle
audit_blend_output before bundle_1
catch {blend result bundle_1 .3 bundle_2 .3 bundle_3} error
audit_blend_output after bundle_1
exit
