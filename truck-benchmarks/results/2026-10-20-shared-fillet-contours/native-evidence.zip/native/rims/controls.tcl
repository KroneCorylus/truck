pload ALL
pload -BlendAudit BLENDAUDIT
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
restore "/home/krone/Development/Pieza_WS/truck/target/native-disjoint-fillet-rims/full.brep" bundle0
explode bundle0
audit_blend_output before0 bundle0_1
catch {blend result0 bundle0_1 .5 bundle0_2 .5 bundle0_3} error0
audit_blend_output after0 bundle0_1
restore "/home/krone/Development/Pieza_WS/truck/target/native-disjoint-fillet-rims/quarter.brep" bundle1
explode bundle1
audit_blend_output before1 bundle1_1
catch {blend result1 bundle1_1 .5 bundle1_2 .5 bundle1_3} error1
audit_blend_output after1 bundle1_1
exit
