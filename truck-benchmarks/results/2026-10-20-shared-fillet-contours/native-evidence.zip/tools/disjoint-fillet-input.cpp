#include <BRepAdaptor_Curve.hxx>
#include <BRepPrimAPI_MakeCylinder.hxx>
#include <BRepCheck_Analyzer.hxx>
#include <BRepTools.hxx>
#include <BRep_Builder.hxx>
#include <TopExp_Explorer.hxx>
#include <TopoDS.hxx>
#include <TopoDS_Compound.hxx>
#include <cmath>
#include <stdexcept>
#include <string>
int main(int argc,char**argv){
 if(argc!=3)return 1;bool full=std::string(argv[2])=="full";
 auto solid=full?BRepPrimAPI_MakeCylinder(5.,10.).Shape():BRepPrimAPI_MakeCylinder(5.,10.,std::acos(-1.)/2).Shape();
 if(!BRepCheck_Analyzer(solid).IsValid())throw std::runtime_error("invalid input");
 TopoDS_Edge top,bottom;
 for(TopExp_Explorer it(solid,TopAbs_EDGE);it.More();it.Next()){
  auto e=TopoDS::Edge(it.Current());BRepAdaptor_Curve c(e);if(c.GetType()!=GeomAbs_Circle)continue;
  auto mid=c.Value((c.FirstParameter()+c.LastParameter())/2);
  if(std::abs(mid.Z()-10)<1e-8)top=e;
  if(std::abs(mid.Z())<1e-8)bottom=e;
 }
 if(top.IsNull()||bottom.IsNull())throw std::runtime_error("missing edge");
 TopoDS_Compound bundle;BRep_Builder b;b.MakeCompound(bundle);b.Add(bundle,solid);b.Add(bundle,top);b.Add(bundle,bottom);
 return BRepTools::Write(bundle,argv[1])?0:1;
}
