from pathlib import Path
import subprocess,os,json,hashlib,re
out=Path('truck-benchmarks/results/2026-10-20-shared-fillet-contours');env=dict(os.environ,CARGO_BUILD_JOBS='12');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
parent=json.loads((out/'parent.json').read_text())
for p,h in parent['sha256'].items():
 if '/tests/' in p or p.endswith('/tests.rs'):assert sha(p)==h,p
assert '1 passed; 2 failed' in (out/'parent-disjoint_fillet_rims.txt').read_text()
assert '2 passed; 1 failed' in (out/'parent-separate_fillet_contours.txt').read_text()
source={str(p):sha(p) for base in ['truck-shapeops/src','truck-shapeops/tests','truck-shapeops/examples','truck-meshalgo/src','truck-meshalgo/tests'] for p in Path(base).rglob('*.rs')}
m=dict(parent_revision=parent['revision'],source_sha256=source)
(out/'validation-start.json').write_text(json.dumps(m,indent=2)+'\n')
for name,cmd in [
 ('shapeops-tests.txt',['cargo','test','--release','-p','truck-shapeops']),
 ('replay-tests.txt',['cargo','test','--release','-p','truck-shapeops','--example','replay_occt_blend']),
 ('capture-tests.txt',['python3','-m','unittest','discover','-s','audits/fillet-chamfer/capture','-p','test_*.py']),
 ('clippy.txt',['cargo','clippy','--release','-p','truck-stepio','-p','truck-shapeops','-p','truck-benchmarks','--all-targets']),
 ('actions-smoke.txt',['cargo','bench','-p','truck-benchmarks','--bench','actions','--','--test']),
 ('replay-build.txt',['cargo','build','--release','-p','truck-shapeops','--example','replay_occt_blend'])]:
 with (out/name).open('w') as log:
  log.write('$ '+' '.join(cmd)+'\n');log.flush();r=subprocess.run(cmd,env=dict(env,RAYON_NUM_THREADS='1') if name=='actions-smoke.txt' else env,stdout=log,stderr=subprocess.STDOUT);log.write(f'exit_code {r.returncode}\n');assert r.returncode==0,name
 print(name,'passed',flush=True)
for p,h in source.items():assert sha(p)==h,p
counts=[tuple(map(int,c)) for c in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',(out/'shapeops-tests.txt').read_text())];m['shapeops_counts']=list(map(sum,zip(*counts)))
assert m['shapeops_counts']==[431,0,1],m['shapeops_counts']
previous=json.loads(Path('truck-benchmarks/results/2026-10-20-cylindrical-terminal-fans/validation.json').read_text())
m['reused_meshalgo_evidence']='truck-benchmarks/results/2026-10-20-cylindrical-terminal-fans/validation.json'
for p,h in previous['source_sha256'].items():
 if p.startswith('truck-meshalgo/'):assert sha(p)==h,p
m.update(replay_tests=59,replay_sha256=sha('target/release/examples/replay_occt_blend'))
assert '59 passed; 0 failed' in (out/'replay-tests.txt').read_text()
for p in out.glob('*.txt'):p.write_text('\n'.join(line.rstrip() for line in p.read_text().splitlines()).rstrip()+'\n')
m['log_sha256']={p.name:sha(p) for p in out.glob('*.txt')}
(out/'validation.json').write_text(json.dumps(m,indent=2)+'\n')
print('Validation complete',m['shapeops_counts'],flush=True)
