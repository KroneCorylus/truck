#include <BRepTools.hxx>
#include <BRep_Builder.hxx>
#include <BRepGProp.hxx>
#include <GProp_GProps.hxx>
#include <TopExp_Explorer.hxx>
#include <iostream>
#include <iomanip>
#include "shape_volume.hpp"
int main(int argc,char**argv){if(argc!=2)return 1;TopoDS_Shape s;BRep_Builder b;if(!BRepTools::Read(s,argv[1],b))return 2;std::cout<<std::setprecision(17);
 std::cout<<"audit "<<blend_audit::shape_volume(s)<<'\n';
 for(double eps:{1e-6,1e-9,1e-12}){
  GProp_GProps p;double e=BRepGProp::VolumeProperties(s,p,eps,true);std::cout<<"standard "<<eps<<' '<<e<<' '<<p.Mass()<<'\n';
  for(bool spans:{false,true}){GProp_GProps q;double f=BRepGProp::VolumePropertiesGK(s,q,eps,true,spans);std::cout<<"GK "<<eps<<' '<<spans<<' '<<f<<' '<<q.Mass()<<'\n';}
 }
 int i=0;for(TopExp_Explorer it(s,TopAbs_FACE);it.More();it.Next()){
  GProp_GProps p,q;double e=BRepGProp::VolumeProperties(it.Current(),p,1e-12,false);double f=BRepGProp::VolumePropertiesGK(it.Current(),q,1e-12,false,true);
  std::cout<<"face "<<i++<<" standard "<<p.Mass()<<" GK "<<q.Mass()<<" errors "<<e<<' '<<f<<'\n';
 }
}
