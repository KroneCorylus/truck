#include <BRepTools.hxx>
#include <BRep_Builder.hxx>
#include <BRepMesh_IncrementalMesh.hxx>
#include <BRep_Tool.hxx>
#include <Poly_Triangulation.hxx>
#include <TopoDS.hxx>
#include <TopExp_Explorer.hxx>
#include <iostream>
#include <iomanip>
int main(int argc,char**argv){if(argc!=2)return 1;TopoDS_Shape s;BRep_Builder b;if(!BRepTools::Read(s,argv[1],b))return 2;std::cout<<std::setprecision(17);
 for(double defl:{.01,.001}){BRepTools::Clean(s);BRepMesh_IncrementalMesh mesh(s,defl,false,.1,true);double total=0,area=0;long triangles=0;
 for(TopExp_Explorer it(s,TopAbs_FACE);it.More();it.Next()){auto f=TopoDS::Face(it.Current());TopLoc_Location location;auto t=BRep_Tool::Triangulation(f,location);if(t.IsNull())return 3;double v=0;
 for(int i=1;i<=t->NbTriangles();++i){int a,b,c;t->Triangle(i).Get(a,b,c);if(f.Orientation()==TopAbs_REVERSED)std::swap(b,c);auto p=t->Node(a).Transformed(location.Transformation()),q=t->Node(b).Transformed(location.Transformation()),r=t->Node(c).Transformed(location.Transformation());v+=p.XYZ().Dot(q.XYZ().Crossed(r.XYZ()))/6.;area+=(q.XYZ()-p.XYZ()).Crossed(r.XYZ()-p.XYZ()).Modulus()/2.;++triangles;}total+=v;}
 std::cout<<"deflection "<<defl<<" volume "<<total<<" area "<<area<<" triangles "<<triangles<<std::endl;
 }}
