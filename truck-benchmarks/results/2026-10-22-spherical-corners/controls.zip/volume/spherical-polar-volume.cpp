#include <algorithm>
#include <array>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <vector>
using V=std::array<double,3>;
double norm2(V p){return p[0]*p[0]+p[1]*p[1]+p[2]*p[2];}
double dist2(V p,V q){for(int i=0;i<3;++i)p[i]-=q[i];return norm2(p);}
// Project onto a ball intersected with two perpendicular half-spaces, enumerating active constraints.
double distance(V p,double Q,double r,double cap){
 double best=1e100;
 auto consider=[&](V q){if(norm2(q)<=Q*Q+1e-12 && q[1]>=r-1e-12 && q[2]<=cap+1e-12)best=std::min(best,dist2(p,q));};
 consider(p);consider({p[0],r,p[2]});consider({p[0],p[1],cap});consider({p[0],r,cap});
 double n=std::sqrt(norm2(p));if(n>0)consider({p[0]*Q/n,p[1]*Q/n,p[2]*Q/n});
 double rho=std::sqrt(Q*Q-r*r),d=std::hypot(p[0],p[2]);if(d>0)consider({p[0]*rho/d,r,p[2]*rho/d});
 rho=std::sqrt(Q*Q-cap*cap);d=std::hypot(p[0],p[1]);if(d>0)consider({p[0]*rho/d,p[1]*rho/d,cap});
 double x=std::sqrt(Q*Q-r*r-cap*cap);consider({std::copysign(x,p[0]),r,cap});
 return best;
}
std::vector<std::pair<double,double>> gauss(int n){
 const double pi=std::acos(-1.);std::vector<std::pair<double,double>> nodes;
 for(int i=0;i<n;i++){
  double x=std::cos(pi*(i+.75)/(n+.5)),der=0;
  for(int j=0;j<30;j++) {double p=1,q=0;for(int k=1;k<=n;k++){double next=((2*k-1)*x*p-(k-1)*q)/k;q=p;p=next;}der=n*(x*p-q)/(x*x-1);double d=p/der;x-=d;if(std::abs(d)<2e-15)break;}
  nodes.emplace_back(x,2/((1-x*x)*der*der));
 }return nodes;
}
double volume(double R,double H,double r,int n){
 auto nodes=gauss(n);double Q=R-r,cap=-r,pi=std::acos(-1.),total=0;
 std::vector<double> zs{-R,H};for(double z:{cap,cap*R/Q})if(z>-R&&z<H)zs.push_back(z);std::sort(zs.begin(),zs.end());
 for(size_t k=1;k<zs.size();++k){double za=std::asin(zs[k-1]/R),zb=std::asin(zs[k]/R);
  for(auto [t,w]:nodes){double phi=(za+zb+(zb-za)*t)/2,z=R*std::sin(phi),Y=R*std::cos(phi),area=0;
   std::vector<double> ys{0,pi/2};for(double y:{r,r*R/Q})if(y>0&&y<Y)ys.push_back(std::asin(y/Y));std::sort(ys.begin(),ys.end());
   for(size_t j=1;j<ys.size();++j){double a=ys[j-1],b=ys[j];
    for(auto [t2,w2]:nodes){double angle=(a+b+(b-a)*t2)/2,y=Y*std::sin(angle),upper=Y*std::cos(angle),lo=0,hi=upper;
     auto d=[&](double x){return distance({z,y,-x},Q,r,cap);};
     double middle=std::min(r,upper);if(d(middle)>r*r)continue;
     lo=middle;hi=upper;
     for(int step=0;step<45;step++){double x=(lo+hi)/2;if(d(x)<=r*r)lo=x;else hi=x;}
     double right=(lo+hi)/2;
     lo=0;hi=middle;
     for(int step=0;step<45;step++){double x=(lo+hi)/2;if(d(x)<=r*r)hi=x;else lo=x;}
     double left=(lo+hi)/2;
     area+=(right-left)*upper*w2*(b-a)/2;
    }
   }
   total+=area*Y*w*(zb-za)/2;
  }
 }return total;
}
int main(){std::cout<<std::setprecision(17);double R=1.5,H=R*std::sqrt(3.)/2;
 for(double r:{.05,.1,.15})for(int n:{512,1024})std::cout<<"R "<<R<<" H "<<H<<" r "<<r<<" n "<<n<<" volume "<<volume(R,H,r,n)<<std::endl;
}
