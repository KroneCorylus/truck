from pathlib import Path
import shutil,subprocess,os,json,hashlib
v=json.loads(Path('truck-benchmarks/results/2026-10-22-spherical-corners/validation.json').read_text());assert hashlib.sha256(Path('target/release/examples/replay_occt_blend').read_bytes()).hexdigest()==v['replay_sha256']
env=os.environ|{'LD_LIBRARY_PATH':'target/occt-sdk/usr/lib64'}
for name in ['D5','D9','E4']:
 p=Path('target/spherical-corner-verified-replays')/name;p.mkdir(parents=True,exist_ok=True);source=Path('target/occt-capture-separated-fillet-components/blend/simple')/name/'capture'
 for ext in ['input.step','input.json','result.brep','result.json']:shutil.copyfile(source/f'001.{ext}',p/f'001.{ext}')
 with (p/'001.truck.log').open('w') as log:subprocess.run(['target/release/examples/replay_occt_blend',str(p/'001')],stdout=log,stderr=subprocess.STDOUT,check=True)
 with (p/'001.comparison.log').open('w') as log:subprocess.run(['target/occt-distance-tree-plugin/compare_shapes',str(p/'001.result.brep'),str(p/'001.truck.step'),str(p/'001.comparison.json')],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 if name=='E4':
  with (p/'brep-conversion.txt').open('w') as log:subprocess.run(['target/open-chamfer-terminal-E5-check/step-to-brep',str(p/'001.truck.step'),str(p/'truck.brep')],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
  for tool,suffix in [('spherical-volume-diagnostic','volume-diagnostic'),('spherical-mesh-volume','mesh-volume')]:
   with (p/(suffix+'.txt')).open('w') as log:subprocess.run(['target/'+tool,str(p/'truck.brep')],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 print(name,'complete',flush=True)
