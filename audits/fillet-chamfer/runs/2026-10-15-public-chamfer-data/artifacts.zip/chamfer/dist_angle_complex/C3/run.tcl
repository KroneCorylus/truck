if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/native-chamfer-public-data/chamfer/dist_angle_complex/C3/images"
set test_image "C3"
if {[catch {test "chamfer" "dist_angle_complex" "C3" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
