if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/native-chamfer-public-data/chamfer/dist_angle_complex/C2/images"
set test_image "C2"
if {[catch {test "chamfer" "dist_angle_complex" "C2" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
