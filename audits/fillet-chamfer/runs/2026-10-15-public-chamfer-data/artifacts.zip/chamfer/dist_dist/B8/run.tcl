if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/native-chamfer-public-data/chamfer/dist_dist/B8/images"
set test_image "B8"
if {[catch {test "chamfer" "dist_dist" "B8" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
