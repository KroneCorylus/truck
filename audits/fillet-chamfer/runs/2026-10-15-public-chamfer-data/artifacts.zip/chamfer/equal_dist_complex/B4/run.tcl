if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/native-chamfer-public-data/chamfer/equal_dist_complex/B4/images"
set test_image "B4"
if {[catch {test "chamfer" "equal_dist_complex" "B4" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
