if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/native-chamfer-public-data/chamfer/equal_dist/E8/images"
set test_image "E8"
if {[catch {test "chamfer" "equal_dist" "E8" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
