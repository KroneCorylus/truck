if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/d-nine-blend-native-retry-2026-10-24/native/blend/simple/U9/images"
set test_image "U9"
if {[catch {test "blend" "simple" "U9" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
