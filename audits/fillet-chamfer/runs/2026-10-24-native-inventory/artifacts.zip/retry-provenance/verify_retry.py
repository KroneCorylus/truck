import json,hashlib,subprocess
from pathlib import Path
ROOT=Path.cwd();RUN=ROOT/'target/d-nine-blend-native-retry-2026-10-24';OUT=ROOT/'target/d-inventory-review-2026-10-24/reconciliation';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def verify():
 m=json.loads((RUN/'provenance-final.json').read_text());n=json.loads((RUN/'native/results.json').read_text());plan=json.loads((ROOT/'target/d-inventory-review-2026-10-24/disposition.json').read_text());assert m['returncode']==0 and m['unchanged'] and m['before']==m['after'] and m['exact_case_set'] and m['data_verified'];assert n['test_data_verified'];assert sha(RUN/'native/results.json')==m['results_sha256'];assert sorted(c['id'] for c in n['cases'])==sorted(c['id'] for c in plan['ready_native_retry']);assert all(c['status']=='passed' and c['harness_verdict']=='OK' for c in n['cases'])
 checked=0
 for path,digest in m['artifacts'].items():assert sha(RUN/path)==digest,path;checked+=1
 roots={'libraries':ROOT/'target/occt-sdk/usr/lib64','data':ROOT/'target/occt-public-chamfer-data','native_sources':ROOT.parent/'investigations/sequential-holes-2026-10-10/occt/src','native_tests':ROOT.parent/'investigations/sequential-holes-2026-10-10/occt/tests'}
 for category,root in roots.items():
  current={str(p.relative_to(root)):sha(p) for p in sorted(root.rglob('*')) if p.is_file()};assert current==m['after'][category],category;checked+=len(current)
 files={'runner':ROOT/'audits/fillet-chamfer/run_occt.py','wrapper':ROOT/'target/d-inventory-review-2026-10-24/retry_native.py','plan':ROOT/'target/d-inventory-review-2026-10-24/disposition.json','draw':Path('/usr/bin/DRAWEXE')}
 for k,p in files.items():assert sha(p)==m['after'][k],k;checked+=1
 occt=roots['native_sources'].parent
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=occt,text=True).strip()==m['after']['native_revision'];assert subprocess.check_output(['git','diff','--binary','HEAD'],cwd=occt,text=True)==m['after']['native_diff']
 historical=subprocess.check_output(['git','show','5a4e3bc6:audits/fillet-chamfer/catalog.json'],cwd=ROOT)
 assert hashlib.sha256(historical).hexdigest()==m['before']['catalog']==m['after']['catalog']
 current=(ROOT/'audits/fillet-chamfer/catalog.json').read_bytes();hc=json.loads(historical);cc=json.loads(current);hcases={c['id']:c for c in hc['cases']};ccases={c['id']:c for c in cc['cases']}
 for case in n['cases']:
  key=case['id'];oldcase=hcases[key];newcase=ccases[key]
  for field in ['source','sha256','helpers','dependencies','missing_assets','unresolved_assets','dependency_status','occt_run']:
   assert oldcase[field]==newcase[field],(key,field)
  assert oldcase['occt_run']=='skipped'
 (OUT/'historical-catalog-5a4e3bc6.json').write_bytes(historical)
 return dict(historical_catalog_revision='5a4e3bc6',historical_catalog_sha256=hashlib.sha256(historical).hexdigest(),current_catalog_sha256=hashlib.sha256(current).hexdigest(),catalog_changed_after_run=current!=historical,catalog_change_context='Current catalog refreshed for exact-knot capture after retry; nine selected native definitions/statuses remain identical to historical skipped selection',verified=True,checked_files=checked,cases=[c['id'] for c in n['cases']],native_status='9 passed',results_sha256=sha(RUN/'native/results.json'),provenance_sha256=sha(RUN/'provenance-final.json'),current_snapshots_match=True,inventory_counts_before=dict(passed=534,skipped=440,known_failure=33,failed=19),inventory_counts_proposed=dict(passed=543,skipped=431,known_failure=33,failed=19),capture_baseline='396 cases/648 operations remains immutable; this native-only run adds no capture'),n
if __name__=='__main__':
 report,_=verify();(OUT/'verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
