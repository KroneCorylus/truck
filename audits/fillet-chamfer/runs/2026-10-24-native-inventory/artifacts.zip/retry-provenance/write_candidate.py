#!/usr/bin/env python3
"""Prepare a self-contained native-only archive in target; never changes catalog/capture."""
import argparse,json,zipfile,hashlib
from pathlib import Path
from verify_retry import verify,ROOT,RUN,OUT,sha

def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--write',action='store_true');args=parser.parse_args()
 if not args.write:parser.error('Prepared only: explicit --write required')
 report,manifest=verify();dest=ROOT/'target/d-nine-blend-native-inventory-candidate-2026-10-24';dest.mkdir(exist_ok=False)
 fixture_provenance=ROOT/'audits/fillet-chamfer/runs/2026-10-15-public-chamfer-data/data-provenance.json'
 members={}
 with zipfile.ZipFile(dest/'artifacts.zip','w',zipfile.ZIP_DEFLATED) as z:
  for p in sorted((RUN/'native').rglob('*')):
   if p.is_file() and p.name!='results.json':z.write(p,str(p.relative_to(RUN/'native')))
  for name in ['provenance-before.json','provenance-final.json','runner.log']:z.write(RUN/name,'retry-provenance/'+name)
  for name in ['retry_native.py','disposition.json']:z.write(ROOT/'target/d-inventory-review-2026-10-24'/name,'retry-provenance/'+name)
  z.write(ROOT/'audits/fillet-chamfer/run_occt.py','retry-provenance/run_occt.py')
  z.write(fixture_provenance,'retry-provenance/data-provenance.json')
  z.write(OUT/'historical-catalog-5a4e3bc6.json','retry-provenance/historical-catalog-5a4e3bc6.json')
  z.write(ROOT/'audits/fillet-chamfer/catalog.json','retry-provenance/current-catalog-at-packaging.json')
  for name in ['verify_retry.py','write_candidate.py']:z.write(OUT/name,'retry-provenance/'+name)
  for filename,digest in manifest['test_data']['external_files'].items():
   p=Path(filename);assert sha(p)==digest;member='external-data/'+p.name;assert member not in members.values();z.write(p,member);members[filename]=member
 manifest['test_data']['archive_members']=members;manifest['artifact_archive']='artifacts.zip';manifest['artifact_archive_sha256']=sha(dest/'artifacts.zip')
 (dest/'results.json').write_text(json.dumps(manifest,indent=2)+'\n');(dest/'verification.json').write_text(json.dumps(report,indent=2)+'\n');(dest/'data-provenance.json').write_bytes(fixture_provenance.read_bytes())
 with zipfile.ZipFile(dest/'artifacts.zip') as z:
  for c in manifest['cases']:
   for name,digest in c['artifacts'].items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
  for path,digest in manifest['test_data']['external_files'].items():assert hashlib.sha256(z.read(members[path])).hexdigest()==digest
 (dest/'REPORT.md').write_text('Nine existing public blend fixtures: native-only retry\n\nAll nine unchanged native tests passed. Proposed inventory totals: 543 passed, 431 skipped, 33 known-failure, 19 failed. This does not establish Truck parity.\n\nThe existing 396-case/648-operation capture is immutable. These tests have no new capture records. A later capture scope must be deliberately expanded and compared against its own declared key set.\n\nRuntime, source, libraries, fixtures and harness provenance verified; binary hashes do not establish that the SDK was built from the recorded modified source tree.\n')
 print(dest)
if __name__=='__main__':main()
