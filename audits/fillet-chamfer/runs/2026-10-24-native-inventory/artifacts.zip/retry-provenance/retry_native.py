#!/usr/bin/env python3
"""Explicit, separate nine-case native retry. Prepared only; no catalog reconciliation."""
import argparse, hashlib, json, subprocess, sys, datetime
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def tree(root):
 return {str(p.relative_to(root)):sha(p) for p in sorted(root.rglob('*')) if p.is_file()}
def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--output',type=Path,required=True,help='Fresh separate evidence directory; never a baseline directory')
 parser.add_argument('--execute',action='store_true',help='Required to start native harness')
 args=parser.parse_args()
 if not args.execute:parser.error('Prepared runner only. Pass --execute after coordinator releases native execution.')
 output=args.output.resolve()
 if output.exists():parser.error('Output must not exist')
 if not output.is_relative_to(ROOT/'target'):parser.error('Scratch output must remain under target')
 plan=json.loads((HERE/'disposition.json').read_text());catalog=ROOT/'audits/fillet-chamfer/catalog.json'
 assert sha(catalog)==plan['catalog_sha256'],'Catalog changed: review selection again'
 occt=ROOT.parent/'investigations/sequential-holes-2026-10-10/occt';libs=ROOT/'target/occt-sdk/usr/lib64';data=ROOT/'target/occt-public-chamfer-data';draw=Path('/usr/bin/DRAWEXE');runner=ROOT/'audits/fillet-chamfer/run_occt.py'
 for row in plan['ready_native_retry']:
  for name,expected in row['source_sha256'].items():assert sha(occt/name)==expected,name
  for fixture in row['fixtures']:assert sha(data/fixture['name'])==fixture['sha256'],fixture['name']
 def snapshot():
  return dict(catalog=sha(catalog),runner=sha(runner),wrapper=sha(__file__),plan=sha(HERE/'disposition.json'),draw=sha(draw),libraries=tree(libs),data=tree(data),native_sources=tree(occt/'src'),native_tests=tree(occt/'tests'),native_revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=occt,text=True).strip(),native_diff=subprocess.check_output(['git','diff','--binary','HEAD'],cwd=occt,text=True))
 before=snapshot();output.mkdir(parents=True)
 command=[sys.executable,str(runner),'--occt',str(occt),'--library-path',str(libs),'--output',str(output/'native'),'--catalog',str(catalog),'--include-missing','--data-path',str(data),'--draw',str(draw),'--workers','1','--timeout','120']
 for row in plan['ready_native_retry']:command+=['--case',row['id']]
 manifest=dict(started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),command=command,before=before,scope='Native harness only; separate nine-case inventory retry; no captured baseline or catalog mutation',compiled_source_caveat='Source tree and runtime bytes recorded independently; these hashes do not prove local source was used to build SDK binaries')
 (output/'provenance-before.json').write_text(json.dumps(manifest,indent=2)+'\n')
 with (output/'runner.log').open('w') as log:result=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
 after=snapshot();manifest.update(returncode=result.returncode,after=after,unchanged=before==after)
 rp=output/'native/results.json'
 if rp.exists():
  results=json.loads(rp.read_text());manifest['results_sha256']=sha(rp);manifest['observed_cases']=[{'id':r['id'],'status':r['status']} for r in results['cases']]
  manifest['exact_case_set']=sorted(r['id'] for r in results['cases'])==sorted(r['id'] for r in plan['ready_native_retry'])
  manifest['data_verified']=results.get('test_data_verified',False)
 manifest['artifacts']={str(p.relative_to(output)):sha(p) for p in sorted(output.rglob('*')) if p.is_file()}
 (output/'provenance-final.json').write_text(json.dumps(manifest,indent=2)+'\n')
 if result.returncode or not manifest['unchanged'] or not manifest.get('exact_case_set') or not manifest.get('data_verified'):raise SystemExit('Retry incomplete or provenance changed; do not reconcile')
 print(json.dumps(manifest['observed_cases'],indent=2))
if __name__=='__main__':main()
