if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-audit-missing-2026-10-11/chamfer/dist_angle/A1/images"
set test_image "A1"
if {[catch {test "chamfer" "dist_angle" "A1" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
