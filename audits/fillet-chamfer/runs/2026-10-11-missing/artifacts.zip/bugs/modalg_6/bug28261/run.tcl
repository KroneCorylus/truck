if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-audit-missing-2026-10-11/bugs/modalg_6/bug28261/images"
set test_image "bug28261"
if {[catch {test "bugs" "modalg_6" "bug28261" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
