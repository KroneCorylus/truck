if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-audit-missing-2026-10-11/bugs/modalg_6/bug26757_2/images"
set test_image "bug26757_2"
if {[catch {test "bugs" "modalg_6" "bug26757_2" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
