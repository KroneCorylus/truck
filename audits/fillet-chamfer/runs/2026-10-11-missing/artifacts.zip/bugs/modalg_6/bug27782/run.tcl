if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-audit-missing-2026-10-11/bugs/modalg_6/bug27782/images"
set test_image "bug27782"
if {[catch {test "bugs" "modalg_6" "bug27782" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
