if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-audit-missing-2026-10-11/bugs/xde/bug33183_1/images"
set test_image "bug33183_1"
if {[catch {test "bugs" "xde" "bug33183_1" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
