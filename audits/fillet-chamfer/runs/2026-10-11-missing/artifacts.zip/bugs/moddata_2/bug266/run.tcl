if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-audit-missing-2026-10-11/bugs/moddata_2/bug266/images"
set test_image "bug266"
if {[catch {test "bugs" "moddata_2" "bug266" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
