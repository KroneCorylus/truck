if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-audit-missing-2026-10-11/bugs/modalg_2/bug22727/images"
set test_image "bug22727"
if {[catch {test "bugs" "modalg_2" "bug22727" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
