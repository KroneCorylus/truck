if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-audit-missing-2026-10-11/bugs/moddata_3/bug30/images"
set test_image "bug30"
if {[catch {test "bugs" "moddata_3" "bug30" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
