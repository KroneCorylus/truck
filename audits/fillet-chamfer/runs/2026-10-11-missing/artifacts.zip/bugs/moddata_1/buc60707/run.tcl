if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-audit-missing-2026-10-11/bugs/moddata_1/buc60707/images"
set test_image "buc60707"
if {[catch {test "bugs" "moddata_1" "buc60707" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
