if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-audit-missing-2026-10-11/blend/tolblend_simple/A3/images"
set test_image "A3"
if {[catch {test "blend" "tolblend_simple" "A3" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
