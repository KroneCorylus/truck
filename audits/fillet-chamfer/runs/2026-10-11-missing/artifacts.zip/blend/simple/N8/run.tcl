if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-audit-missing-2026-10-11/blend/simple/N8/images"
set test_image "N8"
if {[catch {test "blend" "simple" "N8" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
