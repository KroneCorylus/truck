if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-audit-missing-2026-10-11/blend/simple/N4/images"
set test_image "N4"
if {[catch {test "blend" "simple" "N4" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
