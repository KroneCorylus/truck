if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-audit-missing-2026-10-11/blend/simple/L1/images"
set test_image "L1"
if {[catch {test "blend" "simple" "L1" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
