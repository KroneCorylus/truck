if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-audit-missing-2026-10-11/blend/simple/T9/images"
set test_image "T9"
if {[catch {test "blend" "simple" "T9" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
