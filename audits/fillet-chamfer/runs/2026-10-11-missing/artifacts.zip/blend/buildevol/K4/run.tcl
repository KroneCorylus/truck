if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-audit-missing-2026-10-11/blend/buildevol/K4/images"
set test_image "K4"
if {[catch {test "blend" "buildevol" "K4" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
