if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-audit-missing-2026-10-11/blend/buildevol/H4/images"
set test_image "H4"
if {[catch {test "blend" "buildevol" "H4" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
