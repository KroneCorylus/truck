if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-audit-missing-2026-10-11/blend/buildevol/H3/images"
set test_image "H3"
if {[catch {test "blend" "buildevol" "H3" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
