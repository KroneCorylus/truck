if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-audit-missing-2026-10-11/boolean/removefeatures/B2/images"
set test_image "B2"
if {[catch {test "boolean" "removefeatures" "B2" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
