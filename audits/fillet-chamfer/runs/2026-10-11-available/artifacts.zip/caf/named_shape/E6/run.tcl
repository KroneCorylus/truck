if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-audit-2026-10-11/caf/named_shape/E6/images"
set test_image "E6"
if {[catch {test "caf" "named_shape" "E6" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
