if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-audit-2026-10-11/feat/featlf/D4/images"
set test_image "D4"
if {[catch {test "feat" "featlf" "D4" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
