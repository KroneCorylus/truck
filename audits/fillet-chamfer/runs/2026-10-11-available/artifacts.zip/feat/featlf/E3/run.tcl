if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-audit-2026-10-11/feat/featlf/E3/images"
set test_image "E3"
if {[catch {test "feat" "featlf" "E3" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
