if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-audit-2026-10-11/feat/featlf/D3/images"
set test_image "D3"
if {[catch {test "feat" "featlf" "D3" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
