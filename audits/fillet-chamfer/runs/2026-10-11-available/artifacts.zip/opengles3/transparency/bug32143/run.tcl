if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-audit-2026-10-11/opengles3/transparency/bug32143/images"
set test_image "bug32143"
if {[catch {test "opengles3" "transparency" "bug32143" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
