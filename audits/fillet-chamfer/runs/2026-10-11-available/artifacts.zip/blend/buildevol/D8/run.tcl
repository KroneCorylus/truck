if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-audit-2026-10-11/blend/buildevol/D8/images"
set test_image "D8"
if {[catch {test "blend" "buildevol" "D8" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
