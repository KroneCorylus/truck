if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-audit-2026-10-11/blend/buildevol/E8/images"
set test_image "E8"
if {[catch {test "blend" "buildevol" "E8" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
