if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-audit-2026-10-11/blend/simple/G1/images"
set test_image "G1"
if {[catch {test "blend" "simple" "G1" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
