if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-audit-2026-10-11/blend/simple/A4/images"
set test_image "A4"
if {[catch {test "blend" "simple" "A4" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
