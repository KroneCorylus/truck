if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-audit-2026-10-11/blend/bfuseblend/B7/images"
set test_image "B7"
if {[catch {test "blend" "bfuseblend" "B7" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
