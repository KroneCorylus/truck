if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-audit-2026-10-11/v3d/trsf/bug27793/images"
set test_image "bug27793"
if {[catch {test "v3d" "trsf" "bug27793" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
