if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-audit-2026-10-11/fillet2d/fillet2d/A8/images"
set test_image "A8"
if {[catch {test "fillet2d" "fillet2d" "A8" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
