if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-audit-2026-10-11/bugs/modalg_7/bug29334/images"
set test_image "bug29334"
if {[catch {test "bugs" "modalg_7" "bug29334" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
