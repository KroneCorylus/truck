if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-audit-2026-10-11/bugs/modalg_7/bug28828_20/images"
set test_image "bug28828_20"
if {[catch {test "bugs" "modalg_7" "bug28828_20" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
