if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-audit-2026-10-11/bugs/modalg_7/bug30940_2/images"
set test_image "bug30940_2"
if {[catch {test "bugs" "modalg_7" "bug30940_2" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
