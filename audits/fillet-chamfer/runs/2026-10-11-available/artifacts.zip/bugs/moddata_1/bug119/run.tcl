if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-audit-2026-10-11/bugs/moddata_1/bug119/images"
set test_image "bug119"
if {[catch {test "bugs" "moddata_1" "bug119" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
