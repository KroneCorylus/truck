if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-audit-2026-10-11/bugs/heal/bug26219_gehause_rohteil/images"
set test_image "bug26219_gehause_rohteil"
if {[catch {test "bugs" "heal" "bug26219_gehause_rohteil" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
