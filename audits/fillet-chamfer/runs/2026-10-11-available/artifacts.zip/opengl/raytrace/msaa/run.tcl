if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-audit-2026-10-11/opengl/raytrace/msaa/images"
set test_image "msaa"
if {[catch {test "opengl" "raytrace" "msaa" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
