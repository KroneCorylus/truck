if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-audit-2026-10-11/opengl/raytrace/bug26070/images"
set test_image "bug26070"
if {[catch {test "opengl" "raytrace" "bug26070" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
