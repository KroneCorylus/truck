if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-audit-2026-10-11/opengl/general/stereo/images"
set test_image "stereo"
if {[catch {test "opengl" "general" "stereo" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
