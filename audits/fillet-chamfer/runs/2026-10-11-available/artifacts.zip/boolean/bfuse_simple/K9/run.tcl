if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-audit-2026-10-11/boolean/bfuse_simple/K9/images"
set test_image "K9"
if {[catch {test "boolean" "bfuse_simple" "K9" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
