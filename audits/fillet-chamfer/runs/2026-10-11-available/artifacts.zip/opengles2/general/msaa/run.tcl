if {[catch {pload ALL} message]} {puts stderr $message; exit 2}
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-audit-2026-10-11/opengles2/general/msaa/images"
set test_image "msaa"
if {[catch {test "opengles2" "general" "msaa" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
