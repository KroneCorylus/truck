from pathlib import Path
import json,hashlib,zipfile,shutil
base=Path('target');failed=base/'occt-capture-conical-corners';serial=base/'conical-corner-J3-serial-capture';evidence=base/'conical-corner-oom-evidence';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
a=json.loads((failed/'results.json').read_text());b=json.loads((serial/'results.json').read_text());old=json.loads(Path('audits/fillet-chamfer/capture/2026-10-22-spherical-corners/results.json').read_text());case=lambda m:next(c for c in m['cases'] if c['id']=='blend/simple/J3')
assert a['test_data_verified'] and b['test_data_verified'] and not a['kernel_tracked_changes'] and not b['kernel_tracked_changes']
for key in ['kernel_revision','kernel_source_sha256','source_sha256','executable_sha256','library_sha256','harness_sha256','test_data']:assert a[key]==b[key],key
failed_case=case(a);serial_case=case(b);prior_case=case(old)
assert failed_case['captures'][0]['truck']['result']==dict(status='process-failed',returncode=-9)
assert len(serial_case['captures'])==len(prior_case['captures'])==1
for key in ['truck','sampled_comparison','task','native_result']:assert serial_case['captures'][0][key]==prior_case['captures'][0][key],key
files={}
for name,p in [('failed-manifest.json',failed/'results.json'),('failed-full-capture.log',base/'conical-corner-full-capture.log'),('serial-manifest.json',serial/'results.json'),('serial-capture.log',base/'conical-corner-J3-serial-capture.log')]:files[name]=p
for root,manifest,label in [(failed,a,'failed'),(serial,b,'serial')]:
 for member,h in case(manifest)['artifacts'].items():p=root/member;assert sha(p)==h;files[label+'/'+member]=p
 files[label+'/runtime.log']=root/'runtime.log'
for p in evidence.iterdir():files['diagnosis/'+p.name]=p
files['helpers/record-conical-capture-retry.py']=Path(__file__)
hashes={name:sha(p) for name,p in files.items()};archive=base/'conical-corner-capture-retry.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(files.items()):z.write(p,name)
with zipfile.ZipFile(archive) as z:
 for name,p in files.items():assert hashlib.sha256(z.read(name)).hexdigest()==hashes[name]==sha(p)
summary=dict(reason='Kernel-confirmed global OOM killed J3 during four-worker capture',failed_case='blend/simple/J3/001',returncode=-9,failed_capture_workers=a['workers'],serial_workers=b['workers'],same_kernel_and_executables=True,serial_truck_result_exact_baseline=True,serial_native_comparison_exact_baseline=True,only_prior_success_changed=True,archive_members=len(files),archive_sha256=sha(archive),member_sha256=hashes,final_full_capture='Pending fresh complete capture with one worker')
(base/'conical-corner-capture-retry.json').write_text(json.dumps(summary,indent=2)+'\n')
assert not (base/'occt-capture-conical-corners-oom').exists();failed.rename(base/'occt-capture-conical-corners-oom');(base/'conical-corner-full-capture.log').rename(base/'conical-corner-full-capture-oom.log')
print('Verified serial J3 is exactly unchanged; retained',len(files),'retry evidence members',sha(archive))
