#include <BRepTools.hxx>
#include <BRep_Builder.hxx>
#include <BRepClass3d_SolidClassifier.hxx>
#include <BRepCheck_Analyzer.hxx>
#include <BRepBuilderAPI_Copy.hxx>
#include <BRepBuilderAPI_MakeVertex.hxx>
#include <BRepExtrema_DistShapeShape.hxx>
#include <TopExp_Explorer.hxx>
#include <TopoDS.hxx>
#include <STEPControl_Reader.hxx>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cmath>
int main(int argc,char**argv){
 if(argc!=4)return 2;TopoDS_Shape input,native,truck;BRep_Builder b;
 if(!BRepTools::Read(input,argv[1],b)||!BRepTools::Read(native,argv[2],b))return 3;
 STEPControl_Reader reader;if(reader.ReadFile(argv[3])!=IFSelect_RetDone||!reader.TransferRoots())return 4;truck=reader.OneShape();
 std::ostringstream before;BRepTools::Write(input,before);BRepTools::Write(native,before);BRepTools::Write(truck,before);
 std::cout<<std::setprecision(17)<<"valid "<<BRepCheck_Analyzer(input).IsValid()<<" "<<BRepCheck_Analyzer(native).IsValid()<<" "<<BRepCheck_Analyzer(truck).IsValid()<<"\n";
 TopoDS_Compound boundary;b.MakeCompound(boundary);auto copy=BRepBuilderAPI_Copy(native,false,false).Shape();for(TopExp_Explorer it(copy,TopAbs_FACE);it.More();it.Next())b.Add(boundary,it.Current());
 for(double z:{99.,99.9,99.99})for(auto xy:{std::pair<double,double>{-.1,.1},{1.,-1.},{-1.,-1.}}){
  gp_Pnt p(xy.first,xy.second,z);auto classify=[&](const TopoDS_Shape&s){return BRepClass3d_SolidClassifier(s,p,1e-7).State();};
  double R2=22500*(1-z*z/10000);bool disk=xy.first*xy.first+xy.second*xy.second<R2;bool inside=disk&&(!(xy.first>0&&xy.second<0)||std::hypot(xy.first-10,xy.second+10)>10);
  std::cout<<"point "<<xy.first<<" "<<xy.second<<" "<<z<<" analytic_inside "<<inside<<" input_state "<<classify(input)<<" native_state "<<classify(native)<<" truck_state "<<classify(truck)<<" native_boundary_distance "<<BRepExtrema_DistShapeShape(BRepBuilderAPI_MakeVertex(p).Vertex(),boundary).Value()<<"\n";
 }
 std::ostringstream after;BRepTools::Write(input,after);BRepTools::Write(native,after);BRepTools::Write(truck,after);if(before.str()!=after.str())return 5;std::cout<<"input_shapes_unchanged true\n";
}
