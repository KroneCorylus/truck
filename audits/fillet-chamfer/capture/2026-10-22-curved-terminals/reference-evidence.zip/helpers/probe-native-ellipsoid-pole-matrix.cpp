#include "shape_volume.hpp"
#include <BRepAdaptor_Curve.hxx>
#include <BRepBuilderAPI_MakeEdge.hxx>
#include <BRepBuilderAPI_MakeWire.hxx>
#include <BRepBuilderAPI_MakeFace.hxx>
#include <BRepBuilderAPI_MakeVertex.hxx>
#include <BRepBuilderAPI_Copy.hxx>
#include <sstream>
#include <BRepFilletAPI_MakeFillet.hxx>
#include <BRepPrimAPI_MakeRevol.hxx>
#include <BRepTools.hxx>
#include <BRep_Builder.hxx>
#include <BRepCheck_Analyzer.hxx>
#include <BRepExtrema_DistShapeShape.hxx>
#include <Geom_Ellipse.hxx>
#include <TopExp.hxx>
#include <TopoDS.hxx>
#include <TopTools_IndexedMapOfShape.hxx>
#include <cmath>
#include <iostream>
#include <iomanip>
int main(){
 std::cout<<std::setprecision(17);
 for(double scale:{.5,1.,2.,10.,100.}){
  auto ellipse=new Geom_Ellipse(gp_Ax2(gp_Pnt(0,0,0),gp_Dir(0,-1,0),gp_Dir(1,0,0)),1.5*scale,scale);
  BRepBuilderAPI_MakeWire wire;wire.Add(BRepBuilderAPI_MakeEdge(ellipse,0,M_PI/2));
  wire.Add(BRepBuilderAPI_MakeEdge(gp_Pnt(0,0,scale),gp_Pnt(0,0,-scale)));
  wire.Add(BRepBuilderAPI_MakeEdge(gp_Pnt(0,0,-scale),gp_Pnt(2.5*scale,0,-scale)));
  wire.Add(BRepBuilderAPI_MakeEdge(gp_Pnt(2.5*scale,0,-scale),gp_Pnt(1.5*scale,0,0)));
  auto input=BRepPrimAPI_MakeRevol(BRepBuilderAPI_MakeFace(wire.Wire()),gp_Ax1(gp_Pnt(0,0,0),gp_Dir(0,0,1)),1.5*M_PI).Shape();
  std::ostringstream before;BRepTools::Write(input,before);
  BRepFilletAPI_MakeFillet fillet(input,ChFi3d_Rational);fillet.SetParams(.01,1e-4,1e-5,1e-4,1e-5,.001);fillet.SetContinuity(GeomAbs_C1,.01);
  TopTools_IndexedMapOfShape edges;TopExp::MapShapes(input,TopAbs_EDGE,edges);int chosen=0;
  for(int i=1;i<=edges.Extent();++i){auto e=TopoDS::Edge(edges(i));BRepAdaptor_Curve c(e);auto a=c.Value(c.FirstParameter()),b=c.Value(c.LastParameter());
   if(c.GetType()==GeomAbs_Line && hypot(a.X(),a.Y())<1e-8 && hypot(b.X(),b.Y())<1e-8 && fabs(a.Z()-b.Z())>scale){fillet.Add(.1*scale,e);++chosen;}}
  if(chosen!=1)return 2;fillet.Build();if(!fillet.IsDone())return 3;auto result=fillet.Shape();
  TopoDS_Compound boundary;BRep_Builder builder;builder.MakeCompound(boundary);auto copy=BRepBuilderAPI_Copy(result,false,false).Shape();for(TopExp_Explorer it(copy,TopAbs_FACE);it.More();it.Next())builder.Add(boundary,it.Current());
  auto pole=BRepBuilderAPI_MakeVertex(gp_Pnt(0,0,scale)).Vertex();BRepExtrema_DistShapeShape distance(pole,boundary);
  std::ostringstream after;BRepTools::Write(input,after);if(before.str()!=after.str())return 4;
  std::cout<<"input_unchanged true scale "<<scale<<" input_valid "<<BRepCheck_Analyzer(input).IsValid()<<" valid "<<BRepCheck_Analyzer(result).IsValid()<<" input_volume "<<blend_audit::shape_volume(input)<<" result_volume "<<blend_audit::shape_volume(result)<<" pole_distance "<<distance.Value()<<"\n";
  auto tag=std::to_string(scale);BRepTools::Write(input,(std::string("target/ellipsoid-pole-matrix-")+tag+".input.brep").c_str());BRepTools::Write(result,(std::string("target/ellipsoid-pole-matrix-")+tag+".result.brep").c_str());
 }
}
