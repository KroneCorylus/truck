#include <BRepAdaptor_Surface.hxx>
#include <BRepAdaptor_Curve.hxx>
#include <BRepClass_FaceClassifier.hxx>
#include <BRepTools.hxx>
#include <BRep_Builder.hxx>
#include <STEPControl_Reader.hxx>
#include <TopExp_Explorer.hxx>
#include <TopoDS.hxx>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cmath>
int main(int argc,char**argv){
 if(argc!=3)return 2;
 TopoDS_Shape shape;
 if(std::string(argv[1])=="brep") {BRep_Builder b;if(!BRepTools::Read(shape,argv[2],b))return 3;}
 else {STEPControl_Reader r;if(r.ReadFile(argv[2])!=IFSelect_RetDone||!r.TransferRoots())return 4;shape=r.OneShape();}
 std::ostringstream before;BRepTools::Write(shape,before);
 int samples=0,faces=0;double error=0,radial=0;gp_Pnt worst;
 auto measure=[&](const gp_Pnt&p){
  double x=p.X()/1000,y=p.Y()/1000,z=p.Z()/1000;
  if(x+.8 < -1-1e-12||x+.8>1+1e-12)return;
  double gamma=acos(std::max(-1.,std::min(1.,x+.8))),lo=-2,hi=2;
  for(int i=0;i<80;++i){double q=(lo+hi)/2;double actual=q*(1-1/sqrt(26+q*q))+q/sqrt(1+q*q)*sin(gamma);if(actual<y)lo=q;else hi=q;}
  double q=(lo+hi)/2,L=sqrt(26+q*q),M=sqrt(1+q*q);
  gp_Pnt center(-.8,q*(1-1/L),q*q/2-4+26/L);
  double predicted=center.Z()-sin(gamma)/M;
  double e=1000*fabs(z-predicted);if(e>error){error=e;worst=p;}
  radial=std::max(radial,1000*fabs(gp_Pnt(x,y,z).Distance(center)-1));++samples;
 };
 for(TopExp_Explorer it(shape,TopAbs_FACE);it.More();it.Next()){
  auto f=TopoDS::Face(it.Current());BRepAdaptor_Surface s(f);
  if(s.GetType()!=GeomAbs_BSplineSurface)continue;++faces;
  double u0,u1,v0,v1;BRepTools::UVBounds(f,u0,u1,v0,v1);
  for(int i=0;i<=32;++i)for(int j=0;j<=32;++j){double u=u0+(u1-u0)*i/32,v=v0+(v1-v0)*j/32;auto state=BRepClass_FaceClassifier(f,gp_Pnt2d(u,v),1e-8).State();if(state==TopAbs_IN||state==TopAbs_ON)measure(s.Value(u,v));}
  for(TopExp_Explorer e(f,TopAbs_EDGE);e.More();e.Next()){BRepAdaptor_Curve c(TopoDS::Edge(e.Current()));for(int i=0;i<=96;++i)measure(c.Value(c.FirstParameter()+(c.LastParameter()-c.FirstParameter())*i/96));}
 }
 std::ostringstream after;BRepTools::Write(shape,after);if(before.str()!=after.str())return 5;
 std::cout<<std::setprecision(17)<<"faces "<<faces<<" samples "<<samples<<" envelope_z_error "<<error<<" rolling_radius_error "<<radial<<" worst "<<worst.X()<<" "<<worst.Y()<<" "<<worst.Z()<<" input_unchanged true\n";
 return faces&&samples?0:6;
}
