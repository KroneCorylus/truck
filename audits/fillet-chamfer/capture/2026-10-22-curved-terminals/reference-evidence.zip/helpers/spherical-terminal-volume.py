from pathlib import Path
from math import pi,sqrt,cos,sin,asin
import json
R=150.;r=10.;lo=-R*sqrt(3)/2;hi=-lo;k=1-pi/4
rows=[]
for case,concave in [('D3',False),('D7',True)]:
 sector=3 if concave else 1;sign=-1 if concave else 1;h=hi-r
 lower=sector*pi/4*(R*R*(h-lo)-(h**3-lo**3)/3)-sign*k*r*r*(h-lo)
 def f(t):
  rho=r*cos(t);a=r-rho;z=h+r*sin(t);outer=sqrt(R*R-z*z)
  corner=k*(r+a)**2 if concave else -k*rho*rho
  area=sector*pi*outer*outer/4-outer*outer*asin(a/outer)-a*sqrt(outer*outer-a*a)+sign*a*a+corner
  return area*r*cos(t)
 values=[]
 for n in [1024,4096,16384]:
  d=pi/2/n;values.append(lower+d/3*(f(0)+f(pi/2)+sum((4 if i%2 else 2)*f(i*d) for i in range(1,n))))
 native=json.loads((Path('target/occt-capture-spline-pcurves/blend/simple')/case/'capture/001.result.json').read_text())['volume']
 rows.append(dict(case=case,sphere_radius=R,cut_heights=[lo,hi],fillet_radius=r,concave=concave,simpson=values,native_volume=native,native_absolute_difference=abs(values[-1]-native)))
 assert max(values)-min(values)<1e-8
 assert abs(values[-1]-native)<1e-5
Path('target/spherical-terminal-volume.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
