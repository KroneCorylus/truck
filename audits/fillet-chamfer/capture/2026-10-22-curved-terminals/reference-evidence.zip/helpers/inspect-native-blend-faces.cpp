#include <BRepAdaptor_Surface.hxx>
#include <BRepTools.hxx>
#include <BRep_Builder.hxx>
#include <TopExp_Explorer.hxx>
#include <TopoDS.hxx>
#include <iostream>
#include <iomanip>
int main(int argc,char**argv){
 if(argc!=2)return 2;TopoDS_Shape s;BRep_Builder b;if(!BRepTools::Read(s,argv[1],b))return 3;
 int i=0;std::cout<<std::setprecision(17);
 for(TopExp_Explorer it(s,TopAbs_FACE);it.More();it.Next()){
  auto f=TopoDS::Face(it.Current());BRepAdaptor_Surface a(f);std::cout<<++i<<" type "<<a.GetType()<<" orientation "<<f.Orientation();
  if(a.GetType()==GeomAbs_Cylinder){auto c=a.Cylinder();auto p=c.Location();auto v=c.Axis().Direction();std::cout<<" cylinder R "<<c.Radius()<<" origin "<<p.X()<<" "<<p.Y()<<" "<<p.Z()<<" axis "<<v.X()<<" "<<v.Y()<<" "<<v.Z();}
  if(a.GetType()==GeomAbs_Plane){auto c=a.Plane();auto p=c.Location();auto v=c.Axis().Direction();std::cout<<" plane origin "<<p.X()<<" "<<p.Y()<<" "<<p.Z()<<" normal "<<v.X()<<" "<<v.Y()<<" "<<v.Z();}
  if(a.GetType()==GeomAbs_Sphere){auto c=a.Sphere();auto p=c.Location();std::cout<<" sphere R "<<c.Radius()<<" origin "<<p.X()<<" "<<p.Y()<<" "<<p.Z();}
  double u0,u1,v0,v1;BRepTools::UVBounds(f,u0,u1,v0,v1);std::cout<<" range "<<u0<<" "<<u1<<" "<<v0<<" "<<v1<<"\n";
 }
}
