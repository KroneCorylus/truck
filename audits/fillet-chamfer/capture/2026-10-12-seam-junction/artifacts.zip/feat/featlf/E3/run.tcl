if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-seam-junction/feat/featlf/E3/images"
set test_image "E3"
if {[catch {test "feat" "featlf" "E3" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
