if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-cylindrical-terminal-fans/boolean/bfuse_simple/K5/images"
set test_image "K5"
if {[catch {test "boolean" "bfuse_simple" "K5" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
