#include <BRepTools.hxx>
#include <BRep_Builder.hxx>
#include <BRepAdaptor_Curve.hxx>
#include <BRepBuilderAPI_MakeVertex.hxx>
#include <BRepExtrema_ExtPC.hxx>
#include <BRepExtrema_ExtPF.hxx>
#include <STEPControl_Reader.hxx>
#include <TopExp_Explorer.hxx>
#include <TopoDS.hxx>
#include <TopExp.hxx>
#include <BRep_Tool.hxx>
#include <Extrema_ExtPC.hxx>
#include <vector>
#include <Geom_BSplineCurve.hxx>
#include <BRepBuilderAPI_MakeEdge.hxx>
#include <ChFi3d_ChBuilder.hxx>
#include <ChFiDS_Spine.hxx>
#include <iomanip>
#include <iostream>
double guide_distance(const gp_Pnt& point,const TopoDS_Edge& edge){BRepExtrema_ExtPC q(BRepBuilderAPI_MakeVertex(point),edge);double d=1e99;if(q.IsDone())for(int i=1;i<=q.NbExt();++i)d=std::min(d,std::sqrt(q.SquareDistance(i)));return d;}
int main(int argc,char**argv){
 if(argc!=4)return 1;TopoDS_Shape input,native;BRep_Builder builder;if(!BRepTools::Read(input,argv[1],builder)||!BRepTools::Read(native,argv[2],builder))return 2;
 STEPControl_Reader reader;reader.ReadFile(argv[3]);reader.TransferRoots();auto truck=reader.OneShape();
 TopoDS_Face cap;int index=0;for(TopExp_Explorer it(input,TopAbs_FACE);it.More();it.Next())if(++index==6)cap=TopoDS::Face(it.Current());
 TopoDS_Edge guide;for(TopExp_Explorer it(input,TopAbs_EDGE);it.More();it.Next()){
  const auto edge=TopoDS::Edge(it.Current());TopoDS_Vertex a,b;TopExp::Vertices(edge,a,b);const auto p=BRep_Tool::Pnt(a),q=BRep_Tool::Pnt(b);gp_Pnt start(-.1183746,-.1432304,.12735195),end(.1686733,9.517733073893808e-9,.12737105);
  if((p.Distance(start)<1e-6&&q.Distance(end)<1e-6)||(p.Distance(end)<1e-6&&q.Distance(start)<1e-6))guide=edge;
 }
 if(guide.IsNull()||cap.IsNull())return 3;
 ChFi3d_ChBuilder native_builder(input);native_builder.AddDA(.01,std::acos(-1.)/6,guide,cap);native_builder.Compute();
 std::cout<<"recomputed done "<<native_builder.IsDone()<<" contours "<<native_builder.NbElements()<<'\n';
 auto spine=native_builder.Value(1);auto el=spine->ElSpine(1);
 std::vector<gp_Pnt> dense;for(int i=0;i<=20000;++i)dense.push_back(el->Value(el->FirstParameter()+(el->LastParameter()-el->FirstParameter())*i/20000.));
 auto eldistance=[&](const gp_Pnt& p){double d=1e99;for(const auto& q:dense)d=std::min(d,p.Distance(q));return d;};
 BRepTools::Write(native_builder.Shape(),"target/c1-recomputed-angle.brep");
 BRepTools::Write(BRepBuilderAPI_MakeEdge(el->BSpline(),el->FirstParameter(),el->LastParameter()).Edge(),"target/c1-computed-guide.brep");
 BRepAdaptor_Curve original(guide);double guide_max=0;for(int i=0;i<=1000;++i){auto p=original.Value(original.FirstParameter()+(original.LastParameter()-original.FirstParameter())*i/1000.);guide_max=std::max(guide_max,eldistance(p));}
 std::cout<<std::setprecision(17)<<"original guide to computed guide maximum sampled deviation "<<guide_max<<'\n';
 for(const auto& shape:{native,truck,native_builder.Shape()}){
  std::cout<<"shape\n";index=0;
  for(TopExp_Explorer it(shape,TopAbs_EDGE);it.More();it.Next()){
   ++index;const auto edge=TopoDS::Edge(it.Current());BRepAdaptor_Curve c(edge);const double a=c.FirstParameter(),b=c.LastParameter();const auto p=c.Value((a+b)/2.);
   BRepExtrema_ExtPF projection(BRepBuilderAPI_MakeVertex(p),cap,Extrema_ExtFlag_MIN,Extrema_ExtAlgo_Tree);double distance=1e99;if(projection.IsDone())for(int i=1;i<=projection.NbExt();++i)distance=std::min(distance,std::sqrt(projection.SquareDistance(i)));
   const double mid=guide_distance(p,guide);if(distance>1e-6||mid<.001||mid>.05)continue;
   double elo=1e99,ehi=0;double lo=1e99,hi=0;for(int i=1;i<16;++i){const auto point=c.Value(a+(b-a)*i/16.);const double d=guide_distance(point,guide);const double ed=eldistance(point);elo=std::min(elo,ed);ehi=std::max(ehi,ed);lo=std::min(lo,d);hi=std::max(hi,d);}
   std::cout<<std::setprecision(17)<<"edge "<<index<<" cap distance "<<distance<<" guide chord min "<<lo<<" max "<<hi<<" mid "<<mid<<" computed guide chord min "<<elo<<" max "<<ehi<<'\n';
  }
 }
}
