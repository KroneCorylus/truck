#include <BRepPrimAPI_MakeCone.hxx>
#include <BRepFilletAPI_MakeChamfer.hxx>
#include <BRepAdaptor_Surface.hxx>
#include <BRepAdaptor_Curve.hxx>
#include <BRepCheck_Analyzer.hxx>
#include <TopExp.hxx>
#include <TopExp_Explorer.hxx>
#include <TopTools_IndexedMapOfShape.hxx>
#include <TopoDS.hxx>
#include <gp_Circ.hxx>
#include <BRepTools.hxx>
#include <iostream>
#include <iomanip>
int main(){int index=0;std::cout<<std::setprecision(17);for(bool cone_reference:{false,true})for(const auto d:{std::pair<double,double>{.1,.2},{.2,.1},{.1,.1}}){auto s=BRepPrimAPI_MakeCone(1.,0.,1.).Solid();TopoDS_Face reference;for(TopExp_Explorer it(s,TopAbs_FACE);it.More();it.Next()){auto f=TopoDS::Face(it.Current());BRepAdaptor_Surface a(f);if(a.GetType()==(cone_reference?GeomAbs_Cone:GeomAbs_Plane))reference=f;}TopoDS_Edge edge;for(TopExp_Explorer it(s,TopAbs_EDGE);it.More();it.Next()){auto e=TopoDS::Edge(it.Current());BRepAdaptor_Curve c(e);if(c.GetType()==GeomAbs_Circle&&c.Circle().Radius()>.5)edge=e;}BRepFilletAPI_MakeChamfer op(s);op.Add(d.first,d.second,edge,reference);op.Build();std::cout<<"reference "<<(cone_reference?"cone":"plane")<<" distances "<<d.first<<' '<<d.second<<" done "<<op.IsDone()<<'\n';if(!op.IsDone())continue;BRepTools::Write(s,("target/native-cone-distance-controls/"+std::to_string(index)+".input.brep").c_str());BRepTools::Write(op.Shape(),("target/native-cone-distance-controls/"+std::to_string(index++)+".result.brep").c_str());std::cout<<"valid "<<BRepCheck_Analyzer(op.Shape()).IsValid()<<'\n';TopTools_IndexedMapOfShape edges;TopExp::MapShapes(op.Shape(),TopAbs_EDGE,edges);for(int i=1;i<=edges.Extent();++i){BRepAdaptor_Curve c(TopoDS::Edge(edges(i)));if(c.GetType()!=GeomAbs_Circle)continue;auto a=c.Circle();if(a.Radius()<1e-8)continue;std::cout<<"contact height "<<a.Location().Z()<<" radius "<<a.Radius()<<" guide chord "<<std::hypot(a.Location().Z(),a.Radius()-1.)<<'\n';}}}
