if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-diagonal-pcurves/blend/simple/Q1/images"
set test_image "Q1"
if {[catch {test "blend" "simple" "Q1" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
