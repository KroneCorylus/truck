if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-reference-contours-stable/opengles2/general/tiles/images"
set test_image "tiles"
if {[catch {test "opengles2" "general" "tiles" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
