if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-normal-section-chamfers/bugs/moddata_1/bug203/images"
set test_image "bug203"
if {[catch {test "bugs" "moddata_1" "bug203" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
