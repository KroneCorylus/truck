if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-normal-section-chamfers/blend/simple/F3/images"
set test_image "F3"
if {[catch {test "blend" "simple" "F3" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
