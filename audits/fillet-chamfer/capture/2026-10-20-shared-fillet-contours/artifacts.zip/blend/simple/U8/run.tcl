if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-shared-fillet-contours/blend/simple/U8/images"
set test_image "U8"
if {[catch {test "blend" "simple" "U8" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
