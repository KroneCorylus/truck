if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-cusp-contacts/feat/featlf/E2/images"
set test_image "E2"
if {[catch {test "feat" "featlf" "E2" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
