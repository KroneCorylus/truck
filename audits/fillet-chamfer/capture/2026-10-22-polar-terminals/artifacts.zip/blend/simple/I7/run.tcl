if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-polar-terminals/blend/simple/I7/images"
set test_image "I7"
if {[catch {test "blend" "simple" "I7" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
