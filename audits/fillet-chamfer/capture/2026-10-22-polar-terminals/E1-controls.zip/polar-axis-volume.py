import math,json
from pathlib import Path
R,r=150.,10.;top=R*math.sqrt(3)/2
base=math.pi/4*(R*R*(top+R)-(top**3+R**3)/3)
def f(t):
 x=r*(1-math.cos(t));y=r*(1-math.sin(t));a=R*R-x*x
 return (top*y+.5*(y*math.sqrt(a-y*y)+a*math.asin(y/math.sqrt(a))))*r*math.sin(t)
values=[]
for n in [1024,4096,16384]:
 d=math.pi/2/n;values.append(base-d/3*(f(0)+f(math.pi/2)+sum((2 if i%2==0 else 4)*f(i*d) for i in range(1,n))))
c=json.loads(Path('target/occt-capture-polar-terminals/blend/simple/E1/capture/001.comparison.json').read_text())
result=dict(case='blend/simple/E1',simpson=values,native_volume=c['native_volume'],truck_step_volume=c['truck_volume'],native_difference=c['native_volume']-values[-1],truck_difference=c['truck_volume']-values[-1])
Path('target/polar-axis-volume.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
p=Path('target/package-polar-terminals-full.py');s=p.read_text().replace("if status(prior)=='operation-succeeded':", "if status(prior)=='operation-succeeded' and key != ('blend/simple/E1', '001'):");p.write_text(s)
