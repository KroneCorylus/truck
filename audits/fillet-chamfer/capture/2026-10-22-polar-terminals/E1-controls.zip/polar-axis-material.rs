#[path = "/home/krone/Development/Pieza_WS/truck/truck-shapeops/tests/common/mod.rs"]
mod common;
use truck_modeling::*;
#[test]
fn polar_axis_material() {
    use truck_shapeops::SplitClosedEdgesAndFaces;
    use truck_stepio::r#in::Table;
    for (name, expected) in [("E1", 3482832.6629430503)] {
        let prefix =
            format!("target/occt-capture-polar-terminals/blend/simple/{name}/capture/001");
        let text = std::fs::read_to_string(format!("{prefix}.input.step")).unwrap();
        let table = Table::from_step(&text).unwrap();
        let (mut raw, skipped) = table
            .to_compressed_solid(table.manifold_solid_brep.values().next().unwrap())
            .unwrap();
        assert!(skipped.is_empty());
        raw.split_closed_edges_and_faces(0.00001);
        let solid = Solid::extract(
            raw.try_mapped(
                |p| Some(*p),
                |c| Curve::try_from(c).ok(),
                |s| Surface::try_from(s).ok(),
            )
            .unwrap(),
        )
        .unwrap();
        let task: serde_json::Value =
            serde_json::from_str(&std::fs::read_to_string(format!("{prefix}.input.json")).unwrap())
                .unwrap();
        let ids: Vec<_> = task["selection"]
            .as_array()
            .unwrap()
            .iter()
            .map(|s| {
                let points = s["points"].as_array().unwrap();
                let p = &points[points.len() / 2];
                let p: Vec<f64> = if points.len() == 2 { (0..3).map(|i| (points[0][i].as_f64().unwrap()+points[1][i].as_f64().unwrap())/2.).collect() } else { (0..3).map(|i| p[i].as_f64().unwrap()).collect() };
                common::blend::edge_through(
                    &solid.boundaries()[0],
                    Point3::new(
                        p[0],
                        p[1],
                        p[2],
                    ),
                )
                .id()
            })
            .collect();
        eprintln!("native {name}");
        let before = serde_json::to_string(&solid.compress()).unwrap();
        let result = truck_shapeops::fillet::try_fillet_solid_edges(&solid, &ids, 10., 0.001).unwrap();
        assert_eq!(before, serde_json::to_string(&solid.compress()).unwrap());
        assert_eq!(result.generated_faces.len(), 1);
        match result.generated_faces[0].surface().elementary().unwrap().0 {
            Elementary::Cylinder { radius, .. } => assert!((radius - 10.).abs() < 1e-8),
            _ => panic!("exact cylindrical round"),
        }
        let output = result.solid;
        assert!(output.is_geometric_consistent());
        common::assert_solid(&output, expected, &[0], 0.001);
        eprintln!("solid checked, checking STEP");
        common::blend::assert_step(&output, expected, 0.001);
    }
}
