if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-exact-knots-2026-10-24/feat/featrf/A8/images"
set test_image "A8"
if {[catch {test "feat" "featrf" "A8" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
