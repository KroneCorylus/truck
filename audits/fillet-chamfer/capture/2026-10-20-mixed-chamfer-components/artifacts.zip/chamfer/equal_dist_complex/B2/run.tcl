if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-mixed-chamfer-components/chamfer/equal_dist_complex/B2/images"
set test_image "B2"
if {[catch {test "chamfer" "equal_dist_complex" "B2" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
