if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-bounded-step-edges/chamfer/dist_angle_complex/B9/images"
set test_image "B9"
if {[catch {test "chamfer" "dist_angle_complex" "B9" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
