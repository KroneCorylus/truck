if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-planar-loop-order/feat/featrf/A4/images"
set test_image "A4"
if {[catch {test "feat" "featrf" "A4" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
