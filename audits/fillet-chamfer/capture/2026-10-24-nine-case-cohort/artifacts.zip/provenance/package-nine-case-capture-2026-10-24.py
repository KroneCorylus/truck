"""Coordinator-only packaging after capture completion; never updates coverage/catalog."""
from collections import Counter
from pathlib import Path
import copy
import hashlib
import html
import json
import math
import zipfile

source = Path('target/occt-capture-nine-case-cohort-2026-10-24')
dest = Path('audits/fillet-chamfer/capture/2026-10-24-nine-case-cohort')
base_path = Path('audits/fillet-chamfer/capture/2026-10-24-exact-knots/results.json')
inv_path = Path('audits/fillet-chamfer/runs/2026-10-24-native-inventory/results.json')
launch_path = Path('target/nine-case-cohort-launch-2026-10-24.json')
load = lambda p: json.loads(Path(p).read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
new, base, inv, launch = map(load, [source/'results.json', base_path, inv_path, launch_path])
expected = {'blend/complex/D2', 'blend/simple/Q9', 'blend/simple/R1', 'blend/simple/R2', 'blend/simple/R3', 'blend/simple/R5', 'blend/simple/R6', 'blend/simple/U9', 'blend/simple/V7'}
assert launch['exit_code'] == 0
assert launch['baseline_sha256'] == sha(base_path) and launch['inventory_sha256'] == sha(inv_path)
assert new['test_data_verified'] and not new['kernel_tracked_changes']
assert len(new['cases']) == len(expected) and {c['id'] for c in new['cases']} == expected
assert new['kernel_revision'] == launch['root_revision']
assert new['workers'] == 1 and new['timeout_seconds'] == 120
assert base['kernel_revision'] == launch['implementation_revision'] == '5a4e3bc666ffda4adb0ed03eeeb707c3068c1d79'
occt = Path('../investigations/sequential-holes-2026-10-10/occt')
for field in ['kernel_source_sha256', 'source_sha256', 'executable_sha256']:
    assert new[field] == base[field], field
    for p, digest in new[field].items(): assert sha(p) == digest, p
for field, folder in [('library_sha256', Path('target/occt-sdk/usr/lib64')), ('harness_sha256', occt)]:
    assert new[field] == base[field] == inv[field], field
    for p, digest in new[field].items(): assert sha(folder/p) == digest, p
assert new['test_data']['external_files'] == inv['test_data']['external_files']
for p, digest in new['test_data']['external_files'].items(): assert sha(p) == digest, p
assert sha('Cargo.lock') == launch['dependency_lock_sha256']
inv_cases = {c['id']: c for c in inv['cases']}
for c in new['cases']:
    assert c['source_sha256'] == inv_cases[c['id']]['source_sha256'], c['id']
    for p, digest in c['source_sha256'].items(): assert sha(occt/p) == digest, p
base_keys = {(c['id'], q['prefix']) for c in base['cases'] for q in c['captures']}
assert len(base['cases']) == 396 and len(base_keys) == 648
rows = [(c['id'], q['prefix'], q) for c in new['cases'] for q in c['captures']]
keys = {(c, p) for c, p, q in rows}
assert len(keys) == len(rows) and not keys.intersection(base_keys)
def summarize_selection(s):
    s = copy.deepcopy(s)
    s['point_count'] = len(s.pop('points'))
    if 'contour_edges' in s: s['contour_edges'] = [summarize_selection(e) for e in s['contour_edges']]
    return s
def status(q): return (q.get('truck') or {}).get('result', {}).get('status', q.get('status', 'missing-status'))
def checks(q):
    r = (q.get('truck') or {}).get('result', {})
    m = q.get('sampled_comparison') or {}
    ds = [m.get(k) for k in ['native_to_truck_max_distance', 'truck_to_native_max_distance']]
    return dict(constructed=status(q) == 'operation-succeeded',
                **{k:r.get(k) is True for k in ['input_unchanged','geometry_consistent','mesh_closed','step_prepared']},
                native_valid=m.get('native_valid') is True, truck_step_valid=m.get('truck_step_valid') is True,
                single_solid=m.get('native_solids') == m.get('truck_solids') == 1,
                sampled_distance=all(isinstance(d,(int,float)) and not isinstance(d,bool) and math.isfinite(d) and 0 <= d <= .001 for d in ds))
records = []
for case, prefix, q in rows:
    raw = load(source/case/'capture'/f'{prefix}.input.json')
    task = copy.deepcopy(raw)
    task['selection'] = [summarize_selection(s) for s in task['selection']]
    for contour in task.get('contours', []): contour['edges'] = [summarize_selection(e) for e in contour['edges']]
    assert task == q['task'], (case, prefix, 'raw task mismatch')
    for values in [raw['stored_tolerances'], q.get('native_result',{}).get('stored_tolerances'), (q.get('sampled_comparison') or {}).get('truck_step_tolerances')]:
        if values is not None:
            assert set(values) == {'face','edge','vertex'} and all(math.isfinite(v) and v >= 0 for v in values.values())
    r = (q.get('truck') or {}).get('result', {})
    if r: assert r.get('selection_scope') == 'native-contours', (case,prefix,r)
    positive = raw.get('solids') == 1 and q.get('native_result',{}).get('native_valid') is True and q.get('native_result',{}).get('solids') == 1
    ck = checks(q)
    passed = all(ck.values())
    assert not passed or positive
    records.append(dict(case=case,capture=prefix,status=status(q),positive_solid_reference=positive,
                        no_solid=raw.get('solids') == 0,limited_pass=passed,checks=ck,
                        raw_task_sha256=sha(source/case/'capture'/f'{prefix}.input.json'),
                        matched_native_rejection=status(q) == 'operation-failed' and q.get('native_result',{}).get('status') == 'operation-failed'))
summary = dict(scope_kind='additional-native-inventory-cohort', declared_case_ids=sorted(expected),
    kernel_revision=new['kernel_revision'], implementation_revision=base['kernel_revision'],
    baseline=dict(path=str(base_path),sha256=sha(base_path),cases=396,operations=648,unchanged=True),
    cases=len(new['cases']), captures=len(rows), operation_keys=[dict(case=c,capture=p) for c,p in sorted(keys)],
    native_statuses=dict(Counter(c['native']['status'] for c in new['cases'])),
    cases_without_captures=[c['id'] for c in new['cases'] if not c['captures']],
    statuses=dict(Counter(r['status'] for r in records)), constructions=sum(r['checks']['constructed'] for r in records),
    positive_solid_reference_count=sum(r['positive_solid_reference'] for r in records),
    limited_comparison_passes=sum(r['limited_pass'] for r in records),
    constructed_comparison_discrepancies=sum(r['checks']['constructed'] and not r['limited_pass'] for r in records),
    no_solid_inputs=sum(r['no_solid'] for r in records), matched_native_rejections=sum(r['matched_native_rejection'] for r in records),
    unresolved_positive_operations=[dict(case=r['case'],capture=r['capture'],status=r['status']) for r in records if r['positive_solid_reference'] and not r['limited_pass']],
    records=records, native_retry_comparison=dict(source_hashes_equal=True,runtime_hashes_equal=True,external_fixture_hashes_equal=True,
    geometry_comparison='Native-only retry archives scripts/logs/images, not intercepted input/result BREP/STEP; geometry byte equality to that retry cannot be asserted. This cohort preserves its own captured native inputs/results verbatim.',
    native_status_pairs=[dict(case=c['id'],retry=inv_cases[c['id']]['status'],capture=c['native']['status']) for c in new['cases']]),
    union_status='Not published as a combined complete baseline; native-intent review is still required.')
artifacts = {}
def add(member, path, digest=None):
    assert member not in artifacts, member
    digest = digest or sha(path)
    assert sha(path) == digest, path
    artifacts[member] = (Path(path), digest)
for c in new['cases']:
    for member, digest in c['artifacts'].items(): add(member,source/member,digest)
    for p,digest in c['source_sha256'].items():
        member='native-source/'+p
        if member not in artifacts: add(member,occt/p,digest)
add('runtime.log',source/'runtime.log')
new['test_data']['archive_members'] = {}
for i,(p,digest) in enumerate(sorted(new['test_data']['external_files'].items())):
    member = f'external-data/{i:03}-{Path(p).name}'
    add(member,p,digest)
    new['test_data']['archive_members'][p] = member
for p in [launch_path,Path('target/run-nine-case-capture-2026-10-24.py'),Path(__file__),Path('target/nine-case-capture-packaging-plan-2026-10-24.txt'),Path('audits/fillet-chamfer/runs/2026-10-24-native-inventory/data-provenance.json')]: add('provenance/'+p.name,p)
add('provenance/Cargo.lock','Cargo.lock',launch['dependency_lock_sha256'])
add('provenance/raw-results.json',source/'results.json')
dest.mkdir(parents=True,exist_ok=False)
archive=dest/'artifacts.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for member,(p,digest) in sorted(artifacts.items()):
        assert sha(p) == digest,p
        z.write(p,member)
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist()) == set(artifacts)
    for member,(p,digest) in artifacts.items(): assert hashlib.sha256(z.read(member)).hexdigest() == digest == sha(p)
new['artifact_archive']='artifacts.zip';new['artifact_archive_sha256']=sha(archive)
(dest/'results.json').write_text(json.dumps(new,indent=2)+'\n')
summary['archive_sha256']=sha(archive)
(dest/'cohort-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
paragraphs=[
 f"Separate nine-case instrumented cohort: {len(rows)} actual captured operations, {summary['constructions']} constructions and {summary['limited_comparison_passes']} limited comparison passes. {len(summary['unresolved_positive_operations'])} positive-solid operations remain unresolved in this cohort.",
 f"Native statuses: {summary['native_statuses']}. Truck statuses: {summary['statuses']}. Cases without intercepted operations: {summary['cases_without_captures']}. Construction alone is not a pass; the unchanged sampled-distance threshold is 0.001.",
 f"The cohort has {summary['positive_solid_reference_count']} positive-solid native reference and {summary['no_solid_inputs']} native no-solid inputs. D2 has a valid native solid but Truck rejects unsupported topology at validate_input. The other eight native inputs/results are valid zero-solid shapes and remain outside solid replay scope; they are not solid modeling successes or native rejections.",
 "The complete 396-case/648-operation exact-knot baseline remains immutable and remains the latest complete capture. This nine-case manifest does not replace it, and no combined405-case execution or complete union is claimed.",
 "Source, replay, canonical plugin, runtime, harness and dependency-lock hashes were verified against the existing D capture/launch. Native source and external fixture hashes match the native-only retry. That retry did not archive intercepted native input/result geometry, so geometry equality to it is not claimed; this archive preserves all new captured input/result artifacts and verifies every archived byte.",
 f"Root evidence revision {new['kernel_revision']}; verified implementation revision {base['kernel_revision']}. No kernel implementation changed. No global geometric-error bound, universal parity, or newly resolved previous ledger row is inferred.",
 f"Archive SHA256: {sha(archive)}."]
(dest/'REPORT.md').write_text('# Nine-case additional capture cohort\n\n'+'\n\n'.join(paragraphs)+'\n\n[Per-operation checks](cohort-summary.json) · [Complete baseline](../2026-10-24-exact-knots/REPORT.md)\n')
style='html,body{margin:0;background:transparent;color:var(--foreground,#192b35);font:16px/1.6 system-ui,sans-serif}main{margin:0;padding:0;width:100%;box-sizing:border-box}p{overflow-wrap:anywhere}a{color:var(--foreground,#075f91)}'
(dest/'report.html').write_text('<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Nine-case additional cohort</title><style>'+style+'</style><main><h1>Nine-case additional capture cohort</h1>'+''.join('<p>'+html.escape(p)+'</p>' for p in paragraphs)+'<p><a href="cohort-summary.json">Per-operation checks</a> · <a href="../2026-10-24-exact-knots/REPORT.md">Complete baseline</a></p></main></html>')
print(json.dumps({k:v for k,v in summary.items() if k not in ['records','operation_keys']},indent=2))
