"""Separate nine-case cohort. Coordinator runs only after inventory commit/release."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
CASES = ['blend/complex/D2', 'blend/simple/Q9', 'blend/simple/R1', 'blend/simple/R2',
         'blend/simple/R3', 'blend/simple/R5', 'blend/simple/R6', 'blend/simple/U9', 'blend/simple/V7']
p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--execute', action='store_true', help='Coordinator release: perform verified capture')
a = p.parse_args()
os.chdir(ROOT)
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
baseline_path = Path('audits/fillet-chamfer/capture/2026-10-24-exact-knots/results.json')
baseline = json.loads(baseline_path.read_text())
inventory_path = Path('audits/fillet-chamfer/runs/2026-10-24-native-inventory/results.json')
inventory = json.loads(inventory_path.read_text())
assert baseline['kernel_revision'] == '5a4e3bc666ffda4adb0ed03eeeb707c3068c1d79'
assert len(baseline['cases']) == 396 and sum(len(c['captures']) for c in baseline['cases']) == 648
assert set(CASES) == {c['id'] for c in inventory['cases']}
assert not set(CASES).intersection(c['id'] for c in baseline['cases'])
output = ROOT / 'target/occt-capture-nine-case-cohort-2026-10-24'
occt = ROOT.parent / 'investigations/sequential-holes-2026-10-10/occt'
plugin = ROOT / 'target/occt-distance-tree-plugin'
libraries = ROOT / 'target/occt-sdk/usr/lib64'
command = [sys.executable, str(ROOT / 'audits/fillet-chamfer/capture/run_capture.py'),
           '--occt', str(occt), '--library-path', str(libraries), '--plugin', str(plugin),
           '--replay', str(ROOT / 'target/release/examples/replay_occt_blend'),
           '--output', str(output), '--data-path', str(ROOT / 'target/occt-public-chamfer-data'),
           '--workers', '1', '--timeout', '120']
for case in CASES:
    command.extend(['--case', case])
if not a.execute:
    print(json.dumps({'not_executed': True, 'command': command, 'cases': CASES,
                      'operation_count': 'unknown until capture', 'baseline': str(baseline_path)}, indent=2))
    raise SystemExit(0)
assert not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], text=True).strip(), 'Commit inventory/catalog changes first'
assert not output.exists(), 'Do not overwrite a previous attempt'
for field in ['kernel_source_sha256', 'source_sha256', 'executable_sha256']:
    for path, digest in baseline[field].items():
        assert sha(path) == digest, (field, path)
for name, digest in baseline['library_sha256'].items():
    assert sha(libraries / name) == digest, name
for name, digest in baseline['harness_sha256'].items():
    assert sha(occt / name) == digest, name
for path, digest in inventory['test_data']['external_files'].items():
    assert sha(path) == digest, path
assert sha('Cargo.lock') == '58085733bd90cdb3ef2b8611cd443e22dae3281b715d5bdbca8707f3238d58bb'
launch = dict(command=command, cases=CASES, baseline_sha256=sha(baseline_path),
              inventory_sha256=sha(inventory_path), dependency_lock_sha256=sha('Cargo.lock'),
              root_revision=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
              implementation_revision=baseline['kernel_revision'],
              scope='Separate cohort; does not replace the 396-case/648-operation complete baseline')
launch_path = ROOT / 'target/nine-case-cohort-launch-2026-10-24.json'
assert not launch_path.exists(), 'Preserve prior launch provenance'
launch_path.write_text(json.dumps(launch, indent=2) + '\n')
with (ROOT / 'target/nine-case-cohort-capture-2026-10-24.txt').open('x') as log:
    result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
launch['exit_code'] = result.returncode
launch_path.write_text(json.dumps(launch, indent=2) + '\n')
raise SystemExit(result.returncode)
