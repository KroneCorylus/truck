if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-nine-case-cohort-2026-10-24/blend/simple/Q9/images"
set test_image "Q9"
if {[catch {test "blend" "simple" "Q9" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
