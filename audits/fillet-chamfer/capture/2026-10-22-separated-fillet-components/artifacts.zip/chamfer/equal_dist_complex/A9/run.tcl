if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-separated-fillet-components/chamfer/equal_dist_complex/A9/images"
set test_image "A9"
if {[catch {test "chamfer" "equal_dist_complex" "A9" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
