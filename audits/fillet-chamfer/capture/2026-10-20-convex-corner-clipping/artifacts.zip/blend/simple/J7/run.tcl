if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-convex-corner-clipping/blend/simple/J7/images"
set test_image "J7"
if {[catch {test "blend" "simple" "J7" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
