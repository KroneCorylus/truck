if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-mixed-curved-corners/chamfer/equal_dist_sequence/A6/images"
set test_image "A6"
if {[catch {test "chamfer" "equal_dist_sequence" "A6" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
