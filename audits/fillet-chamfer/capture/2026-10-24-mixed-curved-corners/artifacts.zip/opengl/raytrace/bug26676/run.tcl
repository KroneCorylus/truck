if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-mixed-curved-corners/opengl/raytrace/bug26676/images"
set test_image "bug26676"
if {[catch {test "opengl" "raytrace" "bug26676" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
