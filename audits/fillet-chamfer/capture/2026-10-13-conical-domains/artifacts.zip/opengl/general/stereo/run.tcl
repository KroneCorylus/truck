if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-conical-domains/opengl/general/stereo/images"
set test_image "stereo"
if {[catch {test "opengl" "general" "stereo" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
