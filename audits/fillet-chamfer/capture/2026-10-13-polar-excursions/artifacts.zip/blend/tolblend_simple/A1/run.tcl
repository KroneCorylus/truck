if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-polar-excursions/blend/tolblend_simple/A1/images"
set test_image "A1"
if {[catch {test "blend" "tolblend_simple" "A1" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
