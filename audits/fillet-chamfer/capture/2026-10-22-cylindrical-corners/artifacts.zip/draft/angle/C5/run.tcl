if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-cylindrical-corners/draft/angle/C5/images"
set test_image "C5"
if {[catch {test "draft" "angle" "C5" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
