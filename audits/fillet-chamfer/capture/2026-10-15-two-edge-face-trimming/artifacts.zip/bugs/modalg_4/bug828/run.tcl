if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-two-edge-face-trimming/bugs/modalg_4/bug828/images"
set test_image "bug828"
if {[catch {test "bugs" "modalg_4" "bug828" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
