if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-two-edge-face-trimming/chamfer/equal_dist/B4/images"
set test_image "B4"
if {[catch {test "chamfer" "equal_dist" "B4" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
