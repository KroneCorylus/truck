if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-two-edge-face-trimming/opengles2/text/bug28099_text_core/images"
set test_image "bug28099_text_core"
if {[catch {test "opengles2" "text" "bug28099_text_core" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
