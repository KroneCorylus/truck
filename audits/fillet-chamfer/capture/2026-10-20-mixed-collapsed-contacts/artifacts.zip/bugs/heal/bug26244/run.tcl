if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-mixed-collapsed-contacts/bugs/heal/bug26244/images"
set test_image "bug26244"
if {[catch {test "bugs" "heal" "bug26244" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
