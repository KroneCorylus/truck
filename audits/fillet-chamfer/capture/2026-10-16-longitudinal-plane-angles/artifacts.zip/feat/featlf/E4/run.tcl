if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-longitudinal-plane-angles/feat/featlf/E4/images"
set test_image "E4"
if {[catch {test "feat" "featlf" "E4" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
