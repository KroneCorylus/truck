if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-spline-rim/bugs/modalg_7/bug30940_6/images"
set test_image "bug30940_6"
if {[catch {test "bugs" "modalg_7" "bug30940_6" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
