if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-cubic-endpoints/bugs/modalg_5/bug25657_1/images"
set test_image "bug25657_1"
if {[catch {test "bugs" "modalg_5" "bug25657_1" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
