if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-conic-section-seams/bugs/moddata_1/bug119/images"
set test_image "bug119"
if {[catch {test "bugs" "moddata_1" "bug119" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
