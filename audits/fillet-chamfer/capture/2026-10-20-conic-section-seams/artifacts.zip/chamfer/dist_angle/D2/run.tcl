if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-conic-section-seams/chamfer/dist_angle/D2/images"
set test_image "D2"
if {[catch {test "chamfer" "dist_angle" "D2" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
