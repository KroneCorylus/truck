if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-conic-contact-extension/boolean/bfuse_simple/K6/images"
set test_image "K6"
if {[catch {test "boolean" "bfuse_simple" "K6" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
