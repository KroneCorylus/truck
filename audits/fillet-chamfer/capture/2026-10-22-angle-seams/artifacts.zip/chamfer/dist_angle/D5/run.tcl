if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-angle-seams/chamfer/dist_angle/D5/images"
set test_image "D5"
if {[catch {test "chamfer" "dist_angle" "D5" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
