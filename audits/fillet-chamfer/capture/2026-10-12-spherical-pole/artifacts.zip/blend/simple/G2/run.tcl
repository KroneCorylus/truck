if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-spherical-pole/blend/simple/G2/images"
set test_image "G2"
if {[catch {test "blend" "simple" "G2" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
