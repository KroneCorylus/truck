if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-spherical-pole/opengles2/general/msaa/images"
set test_image "msaa"
if {[catch {test "opengles2" "general" "msaa" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
