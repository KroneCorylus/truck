#include <STEPControl_Reader.hxx>
#include <BRepTools.hxx>
int main(int argc,char**argv){if(argc!=3)return 1;STEPControl_Reader r;if(r.ReadFile(argv[1])!=IFSelect_RetDone||!r.TransferRoots())return 2;return BRepTools::Write(r.OneShape(),argv[2])?0:3;}
