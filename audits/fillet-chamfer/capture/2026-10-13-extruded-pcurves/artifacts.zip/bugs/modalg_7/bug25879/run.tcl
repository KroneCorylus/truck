if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-extruded-pcurves/bugs/modalg_7/bug25879/images"
set test_image "bug25879"
if {[catch {test "bugs" "modalg_7" "bug25879" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
