if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-public-chamfer-data/chamfer/dist_angle/B3/images"
set test_image "B3"
if {[catch {test "chamfer" "dist_angle" "B3" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
