if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-collapsed-fillet-contacts/blend/tolblend_simple/D3/images"
set test_image "D3"
if {[catch {test "blend" "tolblend_simple" "D3" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
