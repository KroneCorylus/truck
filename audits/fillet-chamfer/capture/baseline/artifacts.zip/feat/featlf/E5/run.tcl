if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-compared-2026-10-11/feat/featlf/E5/images"
set test_image "E5"
if {[catch {test "feat" "featlf" "E5" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
