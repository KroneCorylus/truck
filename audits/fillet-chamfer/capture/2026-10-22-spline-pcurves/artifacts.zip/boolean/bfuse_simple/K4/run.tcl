if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-spline-pcurves/boolean/bfuse_simple/K4/images"
set test_image "K4"
if {[catch {test "boolean" "bfuse_simple" "K4" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
