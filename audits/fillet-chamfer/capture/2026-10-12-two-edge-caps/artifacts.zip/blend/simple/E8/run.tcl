if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-two-edge-caps/blend/simple/E8/images"
set test_image "E8"
if {[catch {test "blend" "simple" "E8" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
