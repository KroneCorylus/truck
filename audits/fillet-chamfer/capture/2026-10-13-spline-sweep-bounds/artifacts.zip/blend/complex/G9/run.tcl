if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-spline-sweep-bounds/blend/complex/G9/images"
set test_image "G9"
if {[catch {test "blend" "complex" "G9" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
