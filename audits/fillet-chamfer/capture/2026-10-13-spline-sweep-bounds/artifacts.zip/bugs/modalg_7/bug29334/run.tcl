if {[catch {pload ALL; pload -BlendAudit BLENDAUDIT} message]} {puts stderr $message; exit 2}
source "/home/krone/Development/Pieza_WS/truck/audits/fillet-chamfer/capture/blend_capture.tcl"
set imagedir "/home/krone/Development/Pieza_WS/truck/target/occt-capture-spline-sweep-bounds/bugs/modalg_7/bug29334/images"
set test_image "bug29334"
if {[catch {test "bugs" "modalg_7" "bug29334" -outfile draw.log -errors} message]} {puts stderr $message; exit 2}
exit
